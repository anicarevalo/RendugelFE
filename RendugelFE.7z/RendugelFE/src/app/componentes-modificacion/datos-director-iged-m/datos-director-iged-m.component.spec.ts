import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DatosDirectorIgedMComponent } from './datos-director-iged-m.component';

describe('DatosDirectorIgedMComponent', () => {
  let component: DatosDirectorIgedMComponent;
  let fixture: ComponentFixture<DatosDirectorIgedMComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DatosDirectorIgedMComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DatosDirectorIgedMComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
