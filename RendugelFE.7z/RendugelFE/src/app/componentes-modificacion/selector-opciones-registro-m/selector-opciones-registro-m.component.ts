import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-selector-opciones-registro-m',
  templateUrl: './selector-opciones-registro-m.component.html',
  styleUrls: ['./selector-opciones-registro-m.component.scss']
})
export class SelectorOpcionesRegistroMComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
