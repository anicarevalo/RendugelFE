import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectorOpcionesRegistroMComponent } from './selector-opciones-registro-m.component';

describe('SelectorOpcionesRegistroMComponent', () => {
  let component: SelectorOpcionesRegistroMComponent;
  let fixture: ComponentFixture<SelectorOpcionesRegistroMComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SelectorOpcionesRegistroMComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectorOpcionesRegistroMComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
