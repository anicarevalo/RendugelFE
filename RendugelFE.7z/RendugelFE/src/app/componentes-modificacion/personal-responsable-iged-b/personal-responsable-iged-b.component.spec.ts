import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalResponsableIgedBComponent } from './personal-responsable-iged-b.component';

describe('PersonalResponsableIgedBComponent', () => {
  let component: PersonalResponsableIgedBComponent;
  let fixture: ComponentFixture<PersonalResponsableIgedBComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ PersonalResponsableIgedBComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalResponsableIgedBComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
