import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-personal-responsable-iged-b',
  templateUrl: './personal-responsable-iged-b.component.html',
  styleUrls: ['./personal-responsable-iged-b.component.scss']
})
export class PersonalResponsableIgedBComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
