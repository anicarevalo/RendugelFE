import {Component, OnInit, Input, Output, ViewChild, EventEmitter} from '@angular/core';
import {FormControl, Validators, FormBuilder, FormGroup} from '@angular/forms';
import {Observable} from 'rxjs';
import {OpcionesUbigeo} from '../../interfaces/opciones-ubigeo';
import {ComunService} from '../../servicios/comun.service';
import {DataInternaService} from '../../servicios/data-interna.service';
import {Ugel} from 'src/app/interfaces/ugel';

@Component({
  selector: 'app-motivo-cierre',
  templateUrl: './motivo-cierre.component.html',
  styleUrls: ['./motivo-cierre.component.scss']
})
export class MotivoCierreComponent implements OnInit {
  @Input() etiqueta: string;
  dataOpcionesUbigeo : OpcionesUbigeo;  
  motivo='';
  motivoControl = new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(500)]);

  constructor(private comunService: ComunService, private dataService: DataInternaService, 
              public fb: FormBuilder) { 
    
  }

  ngOnInit(): void {
  }
}