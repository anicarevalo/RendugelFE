import { Component, OnInit, ViewChild, ElementRef, Input, Output, EventEmitter } from '@angular/core';
import { HttpEventType, HttpErrorResponse } from '@angular/common/http';
import { trigger, state, style, animate, transition } from '@angular/animations';
import { of } from 'rxjs';  
import { catchError, map, last } from 'rxjs/operators';  
import { UploadService } from  '../../servicios/upload.service';
import { FileUploadModel} from '../../interfaces/File-upload-model';
import { HttpClient, HttpResponse, HttpRequest, HttpHeaders} from '@angular/common/http';
import { Message } from '@angular/compiler/src/i18n/i18n_ast';
import { Documento } from 'src/app/interfaces/documento';

@Component({
  selector: 'app-file-upload-self-m',
  templateUrl: './file-upload-self-m.component.html',
  styleUrls: ['./file-upload-self-m.component.scss'],
  animations: [
    trigger('fadeInOut', [
      state('in', style({ opacity: 100 })),
      transition('* => void', [
        animate(300, style({ opacity: 0 }))
      ])
    ])
  ]
})
export class FileUploadSelfMComponent implements OnInit {
  @ViewChild("fileUpload", {static: false}) fileUpload: ElementRef
  ;files  = [];  

  @Input() text ='Upload';
  @Input() param ='file';
  @Input() target = '/restStream/Upload'; //'https://file.io'; //'/restComun/Upload'; //'
  @Input() acccept ='application/pdf';
  @Input() usuario: string = '10406158379';
  @Input() finalidad: string = 'DeCreacion';
  idDocumento: number = 0;
  documento:Documento;

  @Output() complete = new EventEmitter<string>();
  fileInformation: any;
  private file: Array<FileUploadModel>=[];
 
  constructor(private uploadService: UploadService, private _http: HttpClient) {   }

  headers : HttpHeaders = new HttpHeaders(
    {
      "Conten-Type": "application/pdf",
      //Authorization: this.authService.getToken();
    }
  )

  ngOnInit(): void {
  }

 /* uploadFile(file) {  
    const formData = new FormData();  
    formData.append('file', file.data);  
    file.inProgress = true;  
    this.uploadService.upload(formData).pipe(  
      map(event => {  
        switch (event.type) {  
          case HttpEventType.UploadProgress:  
            file.progress = Math.round(event.loaded * 100 / event.total);  
            break;  
          case HttpEventType.Response:  
            return event;  
        }  
      }),  
      catchError((error: HttpErrorResponse) => {  
        file.inProgress = false;  
        return of(`${file.data.name} upload failed.`);  
      })).subscribe((event: any) => {  
        if (typeof (event) === 'object') {  
          console.log(event.body);  
        }  
      });  
  }
  */

 uploadFile(file: FileUploadModel) {  
  const formData = new FormData();    
  formData.append(this.param, file.data);
  formData.append('usuario', this.usuario);
  formData.append('finalidad', this.finalidad);  
  formData.append('idDocumento', this.idDocumento.toString());

  console.log("IdDocumentoal enviar")
  console.log(this.idDocumento.toString());
  //return this.http.post<OpcionesJurisdiccion>(this.registroUrl, seleccionOpcionesRegistro, {headers: this.headers});
  const req = new HttpRequest('POST', this.target, formData, {
    //headers: this.headers,
    reportProgress: true
  })

  //console.log(req);
  file.inProgress = true; 
  //file.state = this._http.request(req)
  file.sub = this._http.request(req)
  //this.uploadService.upload(formData)  
  .pipe(  
    map(event => {  
      switch (event.type) {  
        case HttpEventType.UploadProgress:  
          file.progress = Math.round(event.loaded * 100 / event.total);  
          break;  
        case HttpEventType.Response:  
          return event;  
      }  
    }),  
    //tap(Message => {}),
    last(),
    catchError((error: HttpErrorResponse) => {  
      file.inProgress = false;  
      file.canRetry = true;
      return of(`${file.data.name} upload failed.`);  
    })
    )
    .subscribe(
      (event: any) => {  
      if (typeof (event) === 'object') { 
        //this.removeFileFromArray(file);
        //this.complete.emit(event.body); 
        console.log("Si es correcto-body");  
        console.log(event.body);   
        this.documento = event.body.data;  
        console.log("this.documento");
        console.log(this.documento);
        if (this.documento != undefined && this.documento!= null){
          this.idDocumento=this.documento.IdDocumento;          
        }
        console.log("IdDocumento")
        console.log(this.idDocumento);
        console.log(this.idDocumento.toString())
      }  
    });  
  }

  private uploadFiles() {  
    this.fileUpload.nativeElement.value = '';  

    this.files.forEach(file => {  
      this.uploadFile(file);  
    });  
  }

  onClick() {  
    const fileUpload = this.fileUpload.nativeElement;
    
    fileUpload.onchange = () => {  
      this.files  = [];
    for (let index = 0; index < fileUpload.files.length; index++)  
    {  
     const file = fileUpload.files[index];  
     this.files.push({ 
       data: file, 
       state: 'in',
       inProgress: false, 
       progress: 0,
       canRetry:false,
       canCancel: true
      });  
    }  
      this.uploadFiles();  
    };  
    fileUpload.click();  
  }

  cancelFile(file: FileUploadModel) {
    file.sub.unsubscribe();
    this.removeFileFromArray(file);
    this.documento=null;
  }

  retryFile(file: FileUploadModel) {
    this.uploadFile(file);
    file.canRetry = false;
  }

  private removeFileFromArray(file: FileUploadModel) {
    const index = this.files.indexOf(file);
    if (index > -1) {
      this.files.splice(index, 1);
    }
  }

}
