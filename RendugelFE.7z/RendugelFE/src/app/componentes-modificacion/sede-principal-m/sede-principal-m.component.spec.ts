import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SedePrincipalMComponent } from './sede-principal-m.component';

describe('SedePrincipalMComponent', () => {
  let component: SedePrincipalMComponent;
  let fixture: ComponentFixture<SedePrincipalMComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SedePrincipalMComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SedePrincipalMComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
