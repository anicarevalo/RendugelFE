import {Component, OnInit, Input, Output, ViewChild, EventEmitter} from '@angular/core';
import {FormControl, Validators, FormBuilder, FormGroup} from '@angular/forms';
import {Observable} from 'rxjs';
import {Region} from '../../interfaces/region';
import {Provincia} from '../../interfaces/provincia';
import {Distrito} from '../../interfaces/distrito';
import {CentroPoblado} from '../../interfaces/centro-poblado';
import {OpcionesUbigeo} from '../../interfaces/opciones-ubigeo';
import {OpcionesUbigeoService} from '../../servicios/opciones-ubigeo.service';
import {ComunService} from '../../servicios/comun.service';
import {DataInternaService} from '../../servicios/data-interna.service';
import {CDK_CONNECTED_OVERLAY_SCROLL_STRATEGY } from '@angular/cdk/overlay/overlay-directives';
import {Ugel} from 'src/app/interfaces/ugel';
import {TipoLocal} from '../../interfaces/tipo-local';
import {TipoPropiedad} from '../../interfaces/tipo-propiedad';
import {LocalIged} from '../../interfaces/local-iged'

@Component({
  selector: 'app-sede-principal-m',
  templateUrl: './sede-principal-m.component.html',
  styleUrls: ['./sede-principal-m.component.scss']
})
export class SedePrincipalMComponent implements OnInit {
  dataOpcionesUbigeo : OpcionesUbigeo;
  ugel: Ugel;

  selectedTipoPropiedad: TipoPropiedad;
  selectedTipoLocal: TipoLocal;
  direccionLocal: string;
  
  @Input() listaTipoPropiedad: TipoPropiedad[]; //tiposPersonal;  
  @Input() listaTipoLocal: TipoLocal[]; //tiposPersonal; 

  @Input() listaRegion: Region[];
  @Input() listaProvincia: Provincia[];
  @Input() listaProvinciaPorRegion: Provincia[];
  @Input() listaDistrito: Distrito[];
  @Input() listaDistritoPorProvincia: Distrito[];
  
  @ViewChild("regionChild") regionChild;
  @ViewChild("provinciaChild") provinciaChild;
  @ViewChild("distritoChild") distritoChild;
  
  nombreUgel='';
  codigoUgel='';
  @Input() selectedRegion: Region;
  @Input() selectedProvincia: Provincia;
  @Input() selectedDistrito: Distrito;
  selectedCCPP: CentroPoblado;  

  textoProvincia: string = "";

  regionControl = new FormControl('', [Validators.required]);
  provinciaControl = new FormControl('', [Validators.required]);
  distritoControl = new FormControl('', [Validators.required]);
  ccppControl = new FormControl();
  nombre = new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]);
  codigo = new FormControl('', [Validators.required, Validators.minLength(2), Validators.maxLength(2)]);
   
  tipoPropiedadControl = new FormControl('', [Validators.required]);
  tipoLocalControl = new FormControl('', [Validators.required]);
  direccionControl = new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]);
  
  disabled:boolean = false;
  disableCasilla:boolean = false;  
  
  constructor(private comunService: ComunService, private dataService: DataInternaService, 
              public fb: FormBuilder) { 
      if (this.dataService.detalleRegistroRequest != null){
      this.ugel = this.dataService.detalleRegistroRequest[0].Ugel; 
      this.nombreUgel = this.ugel.NomIged;
      this.codigoUgel = this.ugel.CodIged.substr(4,2);       
      }
      
      console.log("*** dentro this.listaDistrito");
      console.log(this.listaDistrito);
      console.log("*** dentro this.listaProvincias");
      console.log(this.listaProvincia);
      console.log("*** dentro this.listaRegion");       
      console.log(this.listaRegion);
  }

  ngOnInit(): void {
    console.log("Region en Init ****");
      console.log(this.selectedRegion);
    //this.regionControl = new FormControl(this.selectedRegion, [Validators.required]);
  }

  onSelectCasilla(e:Event){
    console.log(e);
    console.log(this.disabled);
    console.log(this.selectedDistrito);

    if (this.disabled && this.selectedDistrito != undefined && this.selectedDistrito != null){
    //this.obtenerCCPPPorDistrito(this.selectedDistrito);
    this.ccppControl = new FormControl('', [Validators.required]);
    }
  }

  onSelectedCCPP(centroPoblado: CentroPoblado){
    console.log(centroPoblado); 
  }

  onSelectDistrito(distrito: Distrito){
    if(this.selectedDistrito != undefined && this.selectedDistrito != null && this.selectedDistrito.CodUbigeo != undefined)
      {this.disableCasilla = true;
        console.log("si")  }        
    else{
        this.disableCasilla = false;
        this.disabled = false;
        console.log("no") 
      }
      console.log(this.disableCasilla)  
  }

  onSelectedProvincia() {
    let provincia = this.provinciaControl.value;
    this.textoProvincia = provincia.CodUbigeo + '-' + provincia.Nombre;
    console.log("this.provinciaControl.value");
    console.log(this.provinciaControl.value);
    //console.log(this.provinciaChild)
    this.filtrarDistrito(provincia);
  }

  onSelectedRegion() {
    let region = this.regionControl.value;
    console.log("this.regionControl.value");
    console.log(region);
    this.filtrarProvincia(region);
    this.provinciaControl.setValue("-1");
    this.onSelectedProvincia();
  }

  private filtrarDistrito(provincia: Provincia): Distrito[] {
    this.listaDistritoPorProvincia= this.listaDistrito.filter(option => option.Provincia.CodUbigeo==provincia.CodUbigeo);
  return this.listaDistrito;
  }

  private filtrarProvincia(region: Region): Provincia[] {
    this.listaProvinciaPorRegion= this.listaProvincia.filter(option => option.Region.CodUbigeo==region.CodUbigeo);
    return this.listaProvinciaPorRegion;
  }

  /*obtenerCCPPPorDistrito(distrito: Distrito):void {
    this.comunService.obtenerCCPPPorDistrito(distrito)
      .subscribe(res => this.listaCentroPoblado = res);    
  }*/

}
