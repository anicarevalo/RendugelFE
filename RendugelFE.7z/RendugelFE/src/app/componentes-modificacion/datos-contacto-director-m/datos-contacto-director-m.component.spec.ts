import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DatosContactoDirectorMComponent } from './datos-contacto-director-m.component';

describe('DatosContactoDirectorMComponent', () => {
  let component: DatosContactoDirectorMComponent;
  let fixture: ComponentFixture<DatosContactoDirectorMComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DatosContactoDirectorMComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DatosContactoDirectorMComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
