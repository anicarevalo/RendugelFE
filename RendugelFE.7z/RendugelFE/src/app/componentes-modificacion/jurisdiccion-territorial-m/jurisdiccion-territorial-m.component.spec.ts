import { ComponentFixture, TestBed } from '@angular/core/testing';

import { JurisdiccionTerritorialMComponent } from './jurisdiccion-territorial-m.component';

describe('JurisdiccionTerritorialMComponent', () => {
  let component: JurisdiccionTerritorialMComponent;
  let fixture: ComponentFixture<JurisdiccionTerritorialMComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ JurisdiccionTerritorialMComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(JurisdiccionTerritorialMComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
