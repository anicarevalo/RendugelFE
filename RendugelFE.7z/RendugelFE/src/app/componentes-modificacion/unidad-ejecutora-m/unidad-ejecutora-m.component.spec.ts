import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UnidadEjecutoraMComponent } from './unidad-ejecutora-m.component';

describe('UnidadEjecutoraMComponent', () => {
  let component: UnidadEjecutoraMComponent;
  let fixture: ComponentFixture<UnidadEjecutoraMComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ UnidadEjecutoraMComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(UnidadEjecutoraMComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
