import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentoResolutivoMComponent } from './documento-resolutivo-m.component';

describe('DocumentoResolutivoMComponent', () => {
  let component: DocumentoResolutivoMComponent;
  let fixture: ComponentFixture<DocumentoResolutivoMComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DocumentoResolutivoMComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentoResolutivoMComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
