import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DatosIgedMComponent } from './datos-iged-m.component';

describe('DatosIgedMComponent', () => {
  let component: DatosIgedMComponent;
  let fixture: ComponentFixture<DatosIgedMComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DatosIgedMComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DatosIgedMComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
