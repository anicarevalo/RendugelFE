import { Component, OnInit, Input, Output, EventEmitter, ViewChild, ɵConsole} from '@angular/core';
import {Tipoiged} from '../../interfaces/tipo-Iged';
import {Iged} from '../../interfaces/iged';
import {Naturaleza} from '../../interfaces/naturaleza';
import {EventoRegistral} from '../../interfaces/evento-registral';
import {configObjModificacion} from '../../interfaces/configObjModificacion';
import {TipoRegistro} from '../../interfaces/tipo-registro';
import {SeleccionOpcionesRegistro} from '../../interfaces/seleccion-Opciones-Registro';
import {FormControl, Validators} from '@angular/forms';

@Component({
  selector: 'app-cabecera-registro-m',
  templateUrl: './cabecera-registro-m.component.html',
  styleUrls: ['./cabecera-registro-m.component.scss']
})
export class CabeceraRegistroMComponent implements OnInit {

  @Input() seleccionOpcionesRegistro: SeleccionOpcionesRegistro;
  @Input() eventosRegistrales: EventoRegistral[];
  eventosControl = new FormControl();

  @Output() seleccionarEventos = new EventEmitter<configObjModificacion>();
  @ViewChild("selectEventos") selectEventos; 

  configObj: configObjModificacion = 
    {
      denominacion: false,
      director: false,
      jurisdiccion: false,
      sede: false,
      ejecutora: false
    }
   
    disabled: boolean= false; 

  constructor() {    
   }

  ngOnInit(): void {
    console.log("this.eventosRegistrales");
    console.log(this.eventosRegistrales);
    if (this.eventosRegistrales.length == 1){
      console.log(this.eventosRegistrales);
      //this.eventosControl.reset();
      this.eventosControl = new FormControl(this.eventosRegistrales);   
      this.disabled =true;
    }
  }

  enviarSeleccion(e:any){
    console.log("PROBANDO EL SELECT DE EVENTOS.");
    console.log(this.eventosControl.value);
 
    this.configObj.denominacion= false,
    this.configObj.director= false,
    this.configObj.jurisdiccion= false,
    this.configObj.sede= false,
    this.configObj.ejecutora= false

    for (let e of this.eventosControl.value){
        switch(e.CodEvento) { 
          case 2: {  
             //Cambio de denominación; 
             this.configObj.denominacion = true;
             break; 
          } 
          case 3: { 
             //Cambio de director; 
             this.configObj.director = true;
             break; 
          } 
          case 4: { 
            //Modificación de jurisdicción; 
            this.configObj.jurisdiccion = true;
            break; 
          } 
          case 5: { 
          //Conversion /cambio de unidad ejecutora; 
            this.configObj.sede = true;
            break; 
          } 
          case 6: { 
            //Conversion /cambio de unidad ejecutora; 
              this.configObj.ejecutora = true;
              break; 
          }
          default: { 
             //statements; 
             break; 
          } 
       }   
    }   
    console.log("this.configObj")
    console.log(this.configObj);
    this.seleccionarEventos.emit(this.configObj);
    //console.log(e);
  }
}


//this.ugelInvolucradas = [];
 //   this.ugelInvolucradas = this.ugeles.value;