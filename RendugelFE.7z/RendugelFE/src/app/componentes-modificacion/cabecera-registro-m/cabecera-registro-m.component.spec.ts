import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CabeceraRegistroMComponent } from './cabecera-registro-m.component';

describe('CabeceraRegistroMComponent', () => {
  let component: CabeceraRegistroMComponent;
  let fixture: ComponentFixture<CabeceraRegistroMComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CabeceraRegistroMComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CabeceraRegistroMComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
