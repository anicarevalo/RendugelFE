import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DatosContactoIgedMComponent } from './datos-contacto-iged-m.component';

describe('DatosContactoIgedMComponent', () => {
  let component: DatosContactoIgedMComponent;
  let fixture: ComponentFixture<DatosContactoIgedMComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DatosContactoIgedMComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(DatosContactoIgedMComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
