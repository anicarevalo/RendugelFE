import { Component, OnInit, Input } from '@angular/core';

@Component({
  selector: 'app-etiquetas-izq',
  templateUrl: './etiquetas-izq.component.html',
  styleUrls: ['./etiquetas-izq.component.scss']
})
export class EtiquetasIzqComponent implements OnInit {
  @Input() etiqueta: String;

  constructor() { }

  ngOnInit(): void {
  }

}
