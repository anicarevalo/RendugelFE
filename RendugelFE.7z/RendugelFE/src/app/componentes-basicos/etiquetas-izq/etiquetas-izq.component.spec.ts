import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { EtiquetasIzqComponent } from './etiquetas-izq.component';

describe('EtiquetasIzqComponent', () => {
  let component: EtiquetasIzqComponent;
  let fixture: ComponentFixture<EtiquetasIzqComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ EtiquetasIzqComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(EtiquetasIzqComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
