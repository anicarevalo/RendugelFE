import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'app-btn-cancelar',
  templateUrl: './btn-cancelar.component.html',
  styleUrls: ['./btn-cancelar.component.scss']
})
export class BtnCancelarComponent implements OnInit {
  @Output() cancelevent = new EventEmitter<string>();
  constructor() { }

  ngOnInit(): void {
  }

  enviarCancel() {
    this.cancelevent.emit("CANCEL");
  }

}
