import { Component, OnInit, Input, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-btn-enunciado',
  templateUrl: './btn-enunciado.component.html',
  styleUrls: ['./btn-enunciado.component.scss']
})
export class BtnEnunciadoComponent implements OnInit {
  @Input() texto: string;
  @Input() imgIcon: string;
  //@Input() routerLink: string; 
  @Output() okevent = new EventEmitter<string>();
  constructor() { }

  ngOnInit(): void {
  }

  enviarOk() {
    this.okevent.emit("OK");
  }

}
