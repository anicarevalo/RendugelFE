import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BtnEnunciadoComponent } from './btn-enunciado.component';

describe('BtnEnunciadoComponent', () => {
  let component: BtnEnunciadoComponent;
  let fixture: ComponentFixture<BtnEnunciadoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BtnEnunciadoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BtnEnunciadoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
