import { Component, OnInit, Output, EventEmitter } from '@angular/core';

@Component({
  selector: 'app-btn-agregar',
  templateUrl: './btn-agregar.component.html',
  styleUrls: ['./btn-agregar.component.scss']
})
export class BtnAgregarComponent implements OnInit {
  @Output() okevent = new EventEmitter<string>();
  constructor() { }

  ngOnInit(): void {
  }

  enviarOk() {
    this.okevent.emit("OK");
  }

}
