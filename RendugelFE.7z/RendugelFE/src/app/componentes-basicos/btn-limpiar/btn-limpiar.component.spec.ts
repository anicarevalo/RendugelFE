import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BtnLimpiarComponent } from './btn-limpiar.component';

describe('BtnLimpiarComponent', () => {
  let component: BtnLimpiarComponent;
  let fixture: ComponentFixture<BtnLimpiarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BtnLimpiarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BtnLimpiarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
