import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-btn-limpiar',
  templateUrl: './btn-limpiar.component.html',
  styleUrls: ['./btn-limpiar.component.scss']
})
export class BtnLimpiarComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
