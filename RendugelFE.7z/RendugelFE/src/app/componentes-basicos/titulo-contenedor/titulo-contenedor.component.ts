import { Component, OnInit, Input  } from '@angular/core';

@Component({
  selector: 'app-titulo-contenedor',
  templateUrl: './titulo-contenedor.component.html',
  styleUrls: ['./titulo-contenedor.component.scss']
})
export class TituloContenedorComponent implements OnInit {
  @Input() titulo: string;

  constructor() { }

  ngOnInit(): void {
  }

}
