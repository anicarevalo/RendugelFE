import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TituloContenedorComponent } from './titulo-contenedor.component';

describe('TituloContenedorComponent', () => {
  let component: TituloContenedorComponent;
  let fixture: ComponentFixture<TituloContenedorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TituloContenedorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TituloContenedorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
