import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { TituloCardCabeceraRegistroComponent } from './titulo-card-cabecera-registro.component';

describe('TituloCardCabeceraRegistroComponent', () => {
  let component: TituloCardCabeceraRegistroComponent;
  let fixture: ComponentFixture<TituloCardCabeceraRegistroComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ TituloCardCabeceraRegistroComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(TituloCardCabeceraRegistroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
