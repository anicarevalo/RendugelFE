import { Component, OnInit, Input  } from '@angular/core';

@Component({
  selector: 'app-titulo-card-cabecera-registro',
  templateUrl: './titulo-card-cabecera-registro.component.html',
  styleUrls: ['./titulo-card-cabecera-registro.component.scss']
})
export class TituloCardCabeceraRegistroComponent implements OnInit {
  @Input() titulo: string;
  constructor() { }

  ngOnInit(): void {
  }

}
