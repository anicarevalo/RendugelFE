import { Component, OnInit, Input, Output, EventEmitter} from '@angular/core';


@Component({
  selector: 'app-btn-aceptar',
  templateUrl: './btn-aceptar.component.html',
  styleUrls: ['./btn-aceptar.component.scss']
})
export class BtnAceptarComponent implements OnInit {
  //@Input() routerLink: string; 
  @Output() okevent = new EventEmitter<string>();
  constructor() { }

  ngOnInit(): void {
  }

  enviarOk() {
    this.okevent.emit("OK");
  }

}
