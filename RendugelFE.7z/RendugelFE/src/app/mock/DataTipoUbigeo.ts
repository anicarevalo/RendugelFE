import {TipoUbigeo} from '../interfaces/tipo-ubigeo';
export const DataTipoubigeo : TipoUbigeo[]= [      
      {DescTipoUbigeo: "PROVINCIA", CodTipoUbigeo: 2, IdTipoUbigeo: 2},
      {DescTipoUbigeo: "DISTRITO", CodTipoUbigeo: 3, IdTipoUbigeo: 3},
      {DescTipoUbigeo: "CENTRO POBLADO", CodTipoUbigeo: 4, IdTipoUbigeo: 4},
  ];  
