import {TipoDocumento} from "../interfaces/tipo-documento"

export const DataTipoDocumento: TipoDocumento[] = [  

    { IdTipoDoc:  1, CodTipoDoc: 1, DescTipoDoc: "Ordenanza Regional"}

]


