import {TipoMedioContacto} from '../interfaces/tipo-medio-contacto';
export const tiposMedioContacto: TipoMedioContacto[] = [
    {
      IdTipoMedioContacto: 1,
      CodTipo: 1,
      DescTipo: "Celular",
      icono: "settings_cell",
      labelIconbtn: "Agregar nro de teléfono celular",
      labelMedio: "Nro de celular:"
    },
    {
      IdTipoMedioContacto: 2,
      CodTipo: 2,
      DescTipo: "Telefono",
      icono: "settings_phone",
      labelIconbtn: "Agregar correos electrónicos",
      labelMedio: "Nro de teléfono:"
    },
    {
      IdTipoMedioContacto: 3,
      CodTipo: 3,
      DescTipo: "Email",
      icono: "alternate_email",
      labelIconbtn: "Agregar nro de teléfonos",
      labelMedio: "e-mail:"
    },
    {
      IdTipoMedioContacto: 4,
      CodTipo: 4,
      DescTipo: "Web",
      icono: "language",
      labelIconbtn: "Agregar página de web",
      labelMedio: "url:"
    }
  ]