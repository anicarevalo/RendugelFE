import {TipoPersonal} from '../interfaces/tipo-personal';
export const tiposPersonal: TipoPersonal[] = [
    {
        CodTipoPersonal: 1,
        DescTipoPersonal: "Director",
        IdTipoPersonal: 1,
    },
    {
        CodTipoPersonal: 2,
        DescTipoPersonal: "Asistente",
        IdTipoPersonal: 2, 
    },
    {
        CodTipoPersonal: 3,
        DescTipoPersonal: "Especialista Estadistico",
        IdTipoPersonal: 3,
    },
    {
        CodTipoPersonal: 4,
        DescTipoPersonal: "Especialista SIAGIE",
        IdTipoPersonal: 4, 
    }
  ]