import {Naturaleza} from '../interfaces/naturaleza';
import {EventoRegistral} from '../interfaces/evento-registral';
import {Tipoiged} from '../interfaces/tipo-Iged';
import {TipoRegistro} from '../interfaces/tipo-registro';
import {Iged} from '../interfaces/iged';
import {EntidadOpcionesRegistro} from '../interfaces/entidad-opciones-registro';

const naturaleza: Naturaleza = {
    CodNaturaleza :1,  IdNaturaleza : 1, DescNaturaleza : "Creación"
}
const _listaNaturales : Naturaleza[] = [
    naturaleza
];

const _listaEventoRegistral: EventoRegistral[] = [
    {CodEvento: 1, DescEvento: "Creación", IdEventoRegistral: 1, Naturaleza: naturaleza}
];

const _listaTipoiged: Tipoiged[]= [
 {CodTipoIged: 2 , DescTipoIged:"UGEL", IdTipoIged: 2 }
];

const _listaTipoRegistro: TipoRegistro[] = [
    {CodTipoRegistro: 1, DescTipoRegistro: "Provisional", IdTipoRegistro: 1}
];

const _listaDre : Iged[]= [
  //  {CodIged: "010000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 1, IdTipoIged: 1, NomIged: "DRE AMAZONAS"},
  //  {CodIged: "020000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 2, IdTipoIged: 1, NomIged: "DRE ANCASH"},
  //  {CodIged: "030000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 3, IdTipoIged: 1, NomIged: "DRE APURÍMAC"},
  //  {CodIged: "040000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 4, IdTipoIged: 1, NomIged: "DRE AREQUIPA"},
  //  {CodIged: "050000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 5, IdTipoIged: 1, NomIged: "DRE AYACUCHO"},
  //  {CodIged: "060000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 6, IdTipoIged: 1, NomIged: "DRE CAJAMARCA"},
  //  {CodIged: "070000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 7, IdTipoIged: 1, NomIged: "DRE CALLAO"},
  //  {CodIged: "080000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 8, IdTipoIged: 1, NomIged: "DRE CUSCO"},
  //  {CodIged: "090000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 9, IdTipoIged: 1, NomIged: "DRE HUANCAVELICA"},
  //  {CodIged: "100000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 10, IdTipoIged: 1, NomIged: "DRE HUÁNUCO"},
  //  {CodIged: "110000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 11, IdTipoIged: 1, NomIged: "DRE ICA"},
  //  {CodIged: "120000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 12, IdTipoIged: 1, NomIged: "DRE JUNÍN"},
  //  {CodIged: "130000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 13, IdTipoIged: 1, NomIged: "DRE LA LIBERTAD"},
  //  {CodIged: "140000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 14, IdTipoIged: 1, NomIged: "DRE LAMBAYEQUE"},
  //  {CodIged: "150101", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 15, IdTipoIged: 1, NomIged: "DRE LIMA METROPOLITANA"},
  //  {CodIged: "150200", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 16, IdTipoIged: 1, NomIged: "DRE LIMA PROVINCIAS"},
  //  {CodIged: "160000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 17, IdTipoIged: 1, NomIged: "DRE LORETO"},
  //  {CodIged: "170000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 18, IdTipoIged: 1, NomIged: "DRE MADRE DE DIOS"},
  //  {CodIged: "180000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 19, IdTipoIged: 1, NomIged: "DRE MOQUEGUA"},
  //  {CodIged: "190000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 20, IdTipoIged: 1, NomIged: "DRE PASCO"},
  //  {CodIged: "200000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 21, IdTipoIged: 1, NomIged: "DRE PIURA"},
  //  {CodIged: "210000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 22, IdTipoIged: 1, NomIged: "DRE PUNO"},
  //  {CodIged: "220000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 23, IdTipoIged: 1, NomIged: "DRE SAN MARTÍN"},
  //  {CodIged: "230000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 24, IdTipoIged: 1, NomIged: "DRE TACNA"},
  //  {CodIged: "240000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 25, IdTipoIged: 1, NomIged: "DRE TUMBES"},
    {CodIged: "250000", CodTipoIged: 1, DescTipoIged: "DRE", IdIged: 26, IdTipoIged: 1, NomIged: "DRE UCAYALI"}
];

export const DataOpcionesRegistro: EntidadOpcionesRegistro = {
    ListaDRE: _listaDre,
    //ListaUGEL: null,
    ListaTipoIged: _listaTipoiged,
    ListaNaturaleza: _listaNaturales,
    ListaEventoRegistral: _listaEventoRegistral,
    ListaTipoRegistro: _listaTipoRegistro    
}


