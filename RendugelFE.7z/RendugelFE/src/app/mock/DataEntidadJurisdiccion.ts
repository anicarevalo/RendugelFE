interface EntidadJurisdiccion {
    item: number;
    termino: string;
    centroPoblado: string;
    distrito: string;
    provincia: string;
    region: string;
    accion: string;
  }
  
  export const DATA_JURISDICCION: EntidadJurisdiccion[] = [
    {item: 1, termino: "COMPRENDE", centroPoblado: "", distrito: "TODOS", provincia: "CONDORCANQUI", region: "AMAZONAS", accion: "delete_outline"},
    {item: 2, termino: "EXCLUYENDO", centroPoblado: "", distrito: "CENEPA", provincia: "CONDORCANQUI", region: "AMAZONAS", accion: "delete_outline"},
    {item: 3, termino: "COMPRENDE", centroPoblado: "", distrito: "TODOS", provincia: "CONDORCANQUI", region: "AMAZONAS", accion: "delete_outline"}
  ];