import {Naturaleza} from '../interfaces/naturaleza';
import {EventoRegistral} from '../interfaces/evento-registral';
import {Tipoiged} from '../interfaces/tipo-Iged';
import {TipoRegistro} from '../interfaces/tipo-registro';
//import {Iged} from '../interfaces/iged';
import {ConfiguracionOpcionesRegistro} from '../interfaces/configuracion-opciones-registro';

let tipoIged: Tipoiged = {
    CodTipoIged: 2,
    DescTipoIged: "UGEL",
    IdTipoIged: 2
}

let tipoRegistroP: TipoRegistro = {
    CodTipoRegistro: 1,
    DescTipoRegistro: "Provisional",
    IdTipoRegistro: 1
}

let tipoRegistroD: TipoRegistro = {
    CodTipoRegistro: 2,
    DescTipoRegistro: "Definitivo",
    IdTipoRegistro: 2
}

let naturaleza: Naturaleza = {
    CodNaturaleza: 1,
    DescNaturaleza: "Creacion",
    IdNaturaleza: 1 
}

let eventoRegistral: EventoRegistral = {
    CodEvento: 1,
    DescEvento: "Creacion",
    IdEventoRegistral: 1,
    Naturaleza: naturaleza
}

const provicionalCreacion: ConfiguracionOpcionesRegistro =
    {configDre: {visible: true, habilitado: true, requerido: true, default: -1 } ,
    configEventoRegistral: {visible: true, habilitado: false, requerido: true, default: eventoRegistral } ,
    configNaturaleza: {visible: true, habilitado: false, requerido: true, default: naturaleza } ,
    configTipoiged: {visible: true, habilitado: false, requerido: true, default: tipoIged } ,
    configTipoRegistro: {visible: true, habilitado: false, requerido: true, default: tipoRegistroP } ,
    configUgel: {visible: false, habilitado: true, requerido: true, default: -1 } 
    };

const definitivoCreacion: ConfiguracionOpcionesRegistro =
    {configDre: {visible: true, habilitado: true, requerido: true, default: -1 } ,
    configEventoRegistral: {visible: true, habilitado: true, requerido: true, default: -1 } ,
    configNaturaleza: {visible: true, habilitado: true, requerido: true, default: -1} ,
    configTipoiged: {visible: true, habilitado: false, requerido: true, default: tipoIged } ,
    configTipoRegistro: {visible: true, habilitado: false, requerido: true, default: tipoRegistroD } ,
    configUgel: {visible: false, habilitado: true, requerido: true, default: -1 } 
    };

const definitivoModificacion: ConfiguracionOpcionesRegistro =
    {configDre: {visible: true, habilitado: true, requerido: true, default: -1 } ,
    configEventoRegistral: {visible: false, habilitado: true, requerido: false, default: -1 } ,
    configNaturaleza: {visible: true, habilitado: true, requerido: true,  default: -1} ,
    configTipoiged: {visible: true, habilitado: false, requerido: true, default: tipoIged } ,
    configTipoRegistro: {visible: true, habilitado: false, requerido: true, default: tipoRegistroD } ,
    configUgel: {visible: false, habilitado: true, requerido: true, default: -1 } 
    };

export const DataConfiguracionOpcionesRegistro  = {
    provicionalCreacion: provicionalCreacion,
    definitivoCreacion:  definitivoCreacion,
    definitivoModificacion:  definitivoModificacion,
}


