import {Region} from '../interfaces/region';
import {Provincia} from '../interfaces/provincia';
import {Distrito} from '../interfaces/distrito';
import {OpcionesUbigeo} from '../interfaces/opciones-ubigeo';

const region: Region = {
    IdUbigeo :1,  CodUbigeo : "01", Nombre : "AMAZONAS"
}

const _listaProvincias : Provincia[] = [
    {IdUbigeo:26, CodUbigeo:'0101', Nombre: "CHACHAPOYAS", Region:region},
    {IdUbigeo:27, CodUbigeo:'0102', Nombre: "BAGUA", Region:region},
    {IdUbigeo:28, CodUbigeo:'0103', Nombre: "BONGARÁ", Region:region},
    {IdUbigeo:29, CodUbigeo:'0104', Nombre: "CONDORCANQUI", Region:region},
    {IdUbigeo:30, CodUbigeo:'0105', Nombre: "LUYA", Region:region},
    {IdUbigeo:31, CodUbigeo:'0106', Nombre: "RODRÍGUEZ DE MENDOZA", Region:region},
    {IdUbigeo:32, CodUbigeo:'0107', Nombre: "UTCUBAMBA", Region:region}    
];

const _listaDistrito : Distrito[] = [
    {IdUbigeo:26, CodUbigeo:'010101', Nombre: "CHACHAPOYAS", Provincia:{IdUbigeo:26, CodUbigeo:'0101', Nombre: "CHACHAPOYAS", Region:region}},
    {IdUbigeo:27, CodUbigeo:'010102', Nombre: "ASUNCIÓN", Provincia:{IdUbigeo:26, CodUbigeo:'0101', Nombre: "CHACHAPOYAS", Region:region}},
    {IdUbigeo:28, CodUbigeo:'010103', Nombre: "BALSAS", Provincia:{IdUbigeo:26, CodUbigeo:'0101', Nombre: "CHACHAPOYAS", Region:region}},
    {IdUbigeo:29, CodUbigeo:'010104', Nombre: "CHETO", Provincia:{IdUbigeo:26, CodUbigeo:'0101', Nombre: "CHACHAPOYAS", Region:region}},
    {IdUbigeo:30, CodUbigeo:'010105', Nombre: "CHILIQUIN", Provincia:{IdUbigeo:26, CodUbigeo:'0101', Nombre: "CHACHAPOYAS", Region:region}},
    {IdUbigeo:31, CodUbigeo:'010106', Nombre: "CHUQUIBAMBA", Provincia:{IdUbigeo:26, CodUbigeo:'0101', Nombre: "CHACHAPOYAS", Region:region}},
    {IdUbigeo:32, CodUbigeo:'010107', Nombre: "GRANADA", Provincia:{IdUbigeo:26, CodUbigeo:'0101', Nombre: "CHACHAPOYAS", Region:region}},    

    {IdUbigeo:26, CodUbigeo:'010201', Nombre: "BAGUA", Provincia:{IdUbigeo:27, CodUbigeo:'0102', Nombre: "BAGUA", Region:region}},
    {IdUbigeo:27, CodUbigeo:'010202', Nombre: "IMAZA", Provincia:{IdUbigeo:27, CodUbigeo:'0102', Nombre: "BAGUA", Region:region}},
    {IdUbigeo:28, CodUbigeo:'010203', Nombre: "ARAMANGO", Provincia:{IdUbigeo:27, CodUbigeo:'0102', Nombre: "BAGUA", Region:region}},
    {IdUbigeo:29, CodUbigeo:'010204', Nombre: "COPALLIN", Provincia:{IdUbigeo:27, CodUbigeo:'0102', Nombre: "BAGUA", Region:region}},
    {IdUbigeo:30, CodUbigeo:'010205', Nombre: "EL PARCO", Provincia:{IdUbigeo:27, CodUbigeo:'0102', Nombre: "BAGUA", Region:region}},
    {IdUbigeo:31, CodUbigeo:'010206', Nombre: "LA PECA", Provincia:{IdUbigeo:27, CodUbigeo:'0102', Nombre: "BAGUA", Region:region}},
];

export const DataOpcionesUbigeo: OpcionesUbigeo = {
    Region: region,
    ListaProvincias: _listaProvincias,
    ListaDistrito: _listaDistrito
}


