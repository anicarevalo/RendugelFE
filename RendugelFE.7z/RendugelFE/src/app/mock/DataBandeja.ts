import {ItemBandejaRegistros} from "../interfaces/ItemBandejaRegistros"

export const DataBandeja: ItemBandejaRegistros[] = [  

    { item:  "1", codRegion: "1", region: "xxxxx", estado: "1", fechaRegistro: "xx", fechaActualizacion: "xxx",
    fechaSuspension:"xxx", fechaCancelacion:"xx", fechaVencimiento:"xx",  docResolutivo:"xxx", 
    fechaDocumento:"xxx", fechaPublicacion:"xxx", acciones:"xx"},

    { item:  "2", codRegion: "1", region: "xxxxx", estado: "1", fechaRegistro: "xx", fechaActualizacion: "xxx",
    fechaSuspension:"xxx", fechaCancelacion:"xx", fechaVencimiento:"xx",  docResolutivo:"xxx", 
    fechaDocumento:"xxx", fechaPublicacion:"xxx", acciones:"xx"},

    { item:  "3", codRegion: "1", region: "xxxxx", estado: "1", fechaRegistro: "xx", fechaActualizacion: "xxx",
    fechaSuspension:"xxx", fechaCancelacion:"xx", fechaVencimiento:"xx",  docResolutivo:"xxx", 
    fechaDocumento:"xxx", fechaPublicacion:"xxx", acciones:"xx"},

    { item:  "4", codRegion: "1", region: "xxxxx", estado: "1", fechaRegistro: "xx", fechaActualizacion: "xxx",
    fechaSuspension:"xxx", fechaCancelacion:"xx", fechaVencimiento:"xx",  docResolutivo:"xxx", 
    fechaDocumento:"xxx", fechaPublicacion:"xxx", acciones:"xx"},

    { item:  "5", codRegion: "1", region: "xxxxx", estado: "1", fechaRegistro: "xx", fechaActualizacion: "xxx",
    fechaSuspension:"xxx", fechaCancelacion:"xx", fechaVencimiento:"xx",  docResolutivo:"xxx", 
    fechaDocumento:"xxx", fechaPublicacion:"xxx", acciones:"xx"},

    { item:  "6", codRegion: "1", region: "xxxxx", estado: "1", fechaRegistro: "xx", fechaActualizacion: "xxx",
    fechaSuspension:"xxx", fechaCancelacion:"xx", fechaVencimiento:"xx",  docResolutivo:"xxx", 
    fechaDocumento:"xxx", fechaPublicacion:"xxx", acciones:"xx"},

    { item:  "7", codRegion: "1", region: "xxxxx", estado: "1", fechaRegistro: "xx", fechaActualizacion: "xxx",
    fechaSuspension:"xxx", fechaCancelacion:"xx", fechaVencimiento:"xx",  docResolutivo:"xxx", 
    fechaDocumento:"xxx", fechaPublicacion:"xxx", acciones:"xx"},

    { item:  "8", codRegion: "1", region: "xxxxx", estado: "1", fechaRegistro: "xx", fechaActualizacion: "xxx",
    fechaSuspension:"xxx", fechaCancelacion:"xx", fechaVencimiento:"xx",  docResolutivo:"xxx", 
    fechaDocumento:"xxx", fechaPublicacion:"xxx", acciones:"xx"},

    { item:  "9", codRegion: "1", region: "xxxxx", estado: "1", fechaRegistro: "xx", fechaActualizacion: "xxx",
    fechaSuspension:"xxx", fechaCancelacion:"xx", fechaVencimiento:"xx",  docResolutivo:"xxx", 
    fechaDocumento:"xxx", fechaPublicacion:"xxx", acciones:"xx"},

    { item:  "10", codRegion: "1", region: "xxxxx", estado: "1", fechaRegistro: "xx", fechaActualizacion: "xxx",
    fechaSuspension:"xxx", fechaCancelacion:"xx", fechaVencimiento:"xx",  docResolutivo:"xxx", 
    fechaDocumento:"xxx", fechaPublicacion:"xxx", acciones:"xx"},

    { item:  "11", codRegion: "1", region: "xxxxx", estado: "1", fechaRegistro: "xx", fechaActualizacion: "xxx",
    fechaSuspension:"xxx", fechaCancelacion:"xx", fechaVencimiento:"xx",  docResolutivo:"xxx", 
    fechaDocumento:"xxx", fechaPublicacion:"xxx", acciones:"xx"},

    { item:  "12", codRegion: "1", region: "xxxxx", estado: "1", fechaRegistro: "xx", fechaActualizacion: "xxx",
    fechaSuspension:"xxx", fechaCancelacion:"xx", fechaVencimiento:"xx",  docResolutivo:"xxx", 
    fechaDocumento:"xxx", fechaPublicacion:"xxx", acciones:"xx"},

    { item:  "13", codRegion: "1", region: "xxxxx", estado: "1", fechaRegistro: "xx", fechaActualizacion: "xxx",
    fechaSuspension:"xxx", fechaCancelacion:"xx", fechaVencimiento:"xx",  docResolutivo:"xxx", 
    fechaDocumento:"xxx", fechaPublicacion:"xxx", acciones:"xx"},

    { item:  "14", codRegion: "1", region: "xxxxx", estado: "1", fechaRegistro: "xx", fechaActualizacion: "xxx",
    fechaSuspension:"xxx", fechaCancelacion:"xx", fechaVencimiento:"xx",  docResolutivo:"xxx", 
    fechaDocumento:"xxx", fechaPublicacion:"xxx", acciones:"xx"},

]


