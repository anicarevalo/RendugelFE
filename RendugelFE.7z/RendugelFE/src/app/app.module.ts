import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule } from '@angular/common/http';
import {MAT_FORM_FIELD_DEFAULT_OPTIONS} from '@angular/material/form-field';
import {MAT_DIALOG_DEFAULT_OPTIONS} from '@angular/material/dialog';

//MODULOS DE MATERIAL
import {MaterialModule} from './material/material.module';

//SERVICIOS
import { SidenavService } from './servicios/sidenav.service';

//COMPONENTES PROPIOS
   //Básicos
import { BtnAceptarComponent } from './componentes-basicos/btn-aceptar/btn-aceptar.component';
import { BtnCancelarComponent } from './componentes-basicos/btn-cancelar/btn-cancelar.component';
import { BtnLimpiarComponent } from './componentes-basicos/btn-limpiar/btn-limpiar.component';
import { BtnEnunciadoComponent } from './componentes-basicos/btn-enunciado/btn-enunciado.component';
import { EtiquetasIzqComponent } from './componentes-basicos/etiquetas-izq/etiquetas-izq.component';
import { TituloCardCabeceraRegistroComponent } from './componentes-basicos/titulo-card-cabecera-registro/titulo-card-cabecera-registro.component';
import { TituloContenedorComponent } from './componentes-basicos/titulo-contenedor/titulo-contenedor.component';

  //Principales
import { BarraBtnInferiorComponent } from './componentes/barra-btn-inferior/barra-btn-inferior.component';
import { BtnCrearRegProvisionalComponent } from './componentes/btn-crear-reg-provisional/btn-crear-reg-provisional.component';
import { BtnCrearRegDefinitivoComponent } from './componentes/btn-crear-reg-definitivo/btn-crear-reg-definitivo.component';
import { CabeceraComponent } from './componentes/cabecera/cabecera.component';
import { CabeceraRegistroComponent } from './componentes/cabecera-registro/cabecera-registro.component';
import { ContenidoComponent } from './componentes/contenido/contenido.component';
import { DatosIgedComponent } from './componentes/datos-iged/datos-iged.component';
import { DocumentoResolutivoComponent } from './componentes/documento-resolutivo/documento-resolutivo.component';
import { FileUploadSelfComponent } from './componentes/file-upload-self/file-upload-self.component';
import { GrillaBandejaComponent } from './componentes/grilla-bandeja/grilla-bandeja.component';
import { GrillaJurisdiccionEnunciadosComponent } from './componentes/grilla-jurisdiccion-enunciados/grilla-jurisdiccion-enunciados.component';
import { HeaderComponent } from './componentes/header/header.component';
import { JurisdiccionTerritorialComponent } from './componentes/jurisdiccion-territorial/jurisdiccion-territorial.component';
import { LeftMenuComponent } from './componentes/left-menu/left-menu.component';
import { MenuPrincipalComponent } from './componentes/menu-principal/menu-principal.component';
import { PiePaginaComponent } from './componentes/pie-pagina/pie-pagina.component';
import { SeleccionBandejaComponent } from './componentes/seleccion-bandeja/seleccion-bandeja.component';
import { SelectorOpcionesRegistroComponent } from './componentes/selector-opciones-registro/selector-opciones-registro.component';

  //Paginas
import { BandejasComponent } from './paginas/bandejas/bandejas.component';
import { NuevoRegistroDefinitivoComponent } from './paginas/nuevo-registro-definitivo/nuevo-registro-definitivo.component';
import { NuevoRegistroProvisionalComponent } from './paginas/nuevo-registro-provisional/nuevo-registro-provisional.component';
import { OpcionesRegistroComponent } from './paginas/opciones-registro/opciones-registro.component';
import { RegistroProvisionalComponent } from './paginas/registro-provisional/registro-provisional.component';
import { DatosContactoIgedComponent} from './componentes/datos-contacto-iged/datos-contacto-iged.component';
import { ModalDatosContactoIgedComponent } from './componentes/modal/modal-datos-contacto-iged/modal-datos-contacto-iged.component';
import { BtnAgregarComponent } from './componentes-basicos/btn-agregar/btn-agregar.component';
import { DatosDirectorIgedComponent } from './componentes/datos-director-iged/datos-director-iged.component';
import { PersonalResponsableIgedComponent } from './componentes/personal-responsable-iged/personal-responsable-iged.component';
import { LocalIgedComponent } from './componentes/local-iged/local-iged.component';
import { ModalMsnAceptarComponent } from './componentes/modal/modal-msn-aceptar/modal-msn-aceptar.component';
import { DatosIgedViewComponent } from './componentes/datos-iged-view/datos-iged-view.component';
import { DocumentoResolutivoViewComponent } from './componentes/documento-resolutivo-view/documento-resolutivo-view.component';
import { ModalComprendeComponent } from './componentes/modal/modal-comprende/modal-comprende.component';
import { ModalIncluyeComponent } from './componentes/modal/modal-incluye/modal-incluye.component';
import { ModalExcluyeComponent } from './componentes/modal/modal-excluye/modal-excluye.component';
import { GrillaJurisdiccionOrigenComponent } from './componentes/grilla-jurisdiccion-origen/grilla-jurisdiccion-origen.component';
import { UnidadEjecutoraComponent } from './componentes/unidad-ejecutora/unidad-ejecutora.component';
import { ModificacionSignificativaComponent } from './paginas/modificacion-significativa/modificacion-significativa.component';
import { ModificacionComplementariaComponent } from './paginas/modificacion-complementaria/modificacion-complementaria.component';
import { CierreDefinitivoComponent } from './paginas/cierre-definitivo/cierre-definitivo.component';
import { CabeceraRegistroMComponent } from './componentes-modificacion/cabecera-registro-m/cabecera-registro-m.component';
import { DatosIgedMComponent } from './componentes-modificacion/datos-iged-m/datos-iged-m.component';
import { DocumentoResolutivoMComponent } from './componentes-modificacion/documento-resolutivo-m/documento-resolutivo-m.component';
import { DatosContactoIgedMComponent } from './componentes-modificacion/datos-contacto-iged-m/datos-contacto-iged-m.component';
import { DatosDirectorIgedMComponent } from './componentes-modificacion/datos-director-iged-m/datos-director-iged-m.component';
import { PersonalResponsableIgedBComponent } from './componentes-modificacion/personal-responsable-iged-b/personal-responsable-iged-b.component';
import { SelectorOpcionesRegistroMComponent } from './componentes-modificacion/selector-opciones-registro-m/selector-opciones-registro-m.component';
import { UnidadEjecutoraMComponent } from './componentes-modificacion/unidad-ejecutora-m/unidad-ejecutora-m.component';
import { FileUploadSelfMComponent } from './componentes-modificacion/file-upload-self-m/file-upload-self-m.component';
import { SedePrincipalMComponent } from './componentes-modificacion/sede-principal-m/sede-principal-m.component';
import { JurisdiccionTerritorialMComponent } from './componentes-modificacion/jurisdiccion-territorial-m/jurisdiccion-territorial-m.component';
import { DatosContactoDirectorMComponent } from './componentes-modificacion/datos-contacto-director-m/datos-contacto-director-m.component';
import { MotivoCierreComponent } from './componentes-modificacion/motivo-cierre/motivo-cierre.component';
import { SuspensionRegistroComponent } from './paginas/suspension-registro/suspension-registro.component';
import { CancelacionRegistroComponent } from './paginas/cancelacion-registro/cancelacion-registro.component';

@NgModule({
  declarations: [
    AppComponent,

    //COMPONENTES PROPIOS
    //Básicos
    BtnAceptarComponent,
    BtnCancelarComponent,
    BtnLimpiarComponent,
    BtnEnunciadoComponent,
    EtiquetasIzqComponent,
    TituloCardCabeceraRegistroComponent,
    TituloContenedorComponent,

    //Principales
    BarraBtnInferiorComponent,
    BtnCrearRegProvisionalComponent,
    BtnCrearRegDefinitivoComponent,
    CabeceraComponent,
    CabeceraRegistroComponent,
    ContenidoComponent,
    DatosIgedComponent,
    DocumentoResolutivoComponent,
    FileUploadSelfComponent,
    GrillaBandejaComponent,
    GrillaJurisdiccionEnunciadosComponent,
    HeaderComponent,
    JurisdiccionTerritorialComponent,
    LeftMenuComponent,
    MenuPrincipalComponent,
    PiePaginaComponent,
    SeleccionBandejaComponent,
    SelectorOpcionesRegistroComponent,

    //Páginas
    BandejasComponent,
    NuevoRegistroDefinitivoComponent,
    NuevoRegistroProvisionalComponent,
    OpcionesRegistroComponent,
    RegistroProvisionalComponent,
    DatosContactoIgedComponent,    
    ModalDatosContactoIgedComponent, 
    BtnAgregarComponent, 
    DatosDirectorIgedComponent, 
    PersonalResponsableIgedComponent, 
    LocalIgedComponent, 
    ModalMsnAceptarComponent, DatosIgedViewComponent, DocumentoResolutivoViewComponent, ModalComprendeComponent, ModalIncluyeComponent, ModalExcluyeComponent, GrillaJurisdiccionOrigenComponent, UnidadEjecutoraComponent, ModificacionSignificativaComponent, ModificacionComplementariaComponent, CierreDefinitivoComponent, CabeceraRegistroMComponent, DatosIgedMComponent, DocumentoResolutivoMComponent, DatosContactoIgedMComponent, DatosDirectorIgedMComponent, PersonalResponsableIgedBComponent, SelectorOpcionesRegistroMComponent, UnidadEjecutoraMComponent, FileUploadSelfMComponent, SedePrincipalMComponent, JurisdiccionTerritorialMComponent, DatosContactoDirectorMComponent, MotivoCierreComponent, SuspensionRegistroComponent, CancelacionRegistroComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    BrowserAnimationsModule,
    MaterialModule,
    HttpClientModule,
    ReactiveFormsModule,
    FormsModule,
  ],
  entryComponents: [ModalDatosContactoIgedComponent, 
                    ModalMsnAceptarComponent, 
                    ModalComprendeComponent,
                    ModalExcluyeComponent,
                    ModalIncluyeComponent
                  ],
  providers: [SidenavService, 
    { provide: MAT_FORM_FIELD_DEFAULT_OPTIONS, useValue: { appearance: 'fill' } }
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
