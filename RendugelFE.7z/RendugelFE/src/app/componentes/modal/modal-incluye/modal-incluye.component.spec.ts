import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalIncluyeComponent } from './modal-incluye.component';

describe('ModalIncluyeComponent', () => {
  let component: ModalIncluyeComponent;
  let fixture: ComponentFixture<ModalIncluyeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ModalIncluyeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalIncluyeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
