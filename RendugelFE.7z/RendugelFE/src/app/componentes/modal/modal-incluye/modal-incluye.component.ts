import {Component, OnInit, Inject } from '@angular/core';
import {FormControl} from '@angular/forms';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
import {Region} from '../../../interfaces/region';
import {Provincia} from '../../../interfaces/provincia';
import {Distrito} from '../../../interfaces/distrito';
import {CentroPoblado} from '../../../interfaces/centro-poblado';
import {TipoUbigeo} from '../../../interfaces/tipo-ubigeo';
import {Ubigeo_} from '../../../interfaces/ubigeo_';
import {Jurisdiccion} from '../../../interfaces/jurisdiccion';
import {ComunService} from '../../../servicios/comun.service';
import {DataTipoubigeo} from '../../../mock/DataTipoUbigeo'; 
import { FormStyle } from '@angular/common';

export interface ResDatosModel{
  //listaProvincia: Provincia[],
  //listaDistrito:  Distrito[],
  jurisdiccionUgel: Jurisdiccion
}

@Component({
  selector: 'app-modal-incluye',
  templateUrl: './modal-incluye.component.html',
  styleUrls: ['./modal-incluye.component.scss']
})
export class ModalIncluyeComponent implements OnInit {
  region: Region;
  listaProvincia: Provincia[];
  listaProvinciaPorRegion: Provincia[];
  listaDistrito: Distrito[];
  listaDistritoPorProvincia: Distrito[];
  listaCentroPoblado: CentroPoblado[];
  listaTipoUbigeo: TipoUbigeo[] = DataTipoubigeo;

  tipoUbigeoControl = new FormControl();
  regionControl = new FormControl();
  provinciaControl = new FormControl();
  distritoControl = new FormControl();
  ccppControl = new FormControl();

  selectedTipoUbigeo: TipoUbigeo;
  selectedRegion: Region;
  selectedProvincia: Provincia;
  selectedDistrito: Distrito;
  selectedCCPP: CentroPoblado;

  verRegion: boolean= false;
  verProvincia:boolean= false;
  verDistrito:boolean=false;
  verCcpp:boolean=false;

  jurisdiccionUgel:Jurisdiccion = {
                                    IdJurisdiccion: 0,
                                    Ubigeo: null,
                                    CodTerminoCantidad: 2,
                                    CodTerminoPertenencia: 2,
                                    TerminoCantidadJurisdiccion: {IdTerminoCantidad:1, CodTerminoCantidad:1, DescTerminoCantidad:"TODOS"},
                                    TerminoPertenenciaJurisdiccion: {IdTerminoPertenencia:2, CodTerminoPertenencia:2, DescTerminoPertenencia:"INCLUYE"},
                                    nivel: 0,  
                                    terminoPertenencia: "INCLUYE",
                                    enCCPP: "",
                                    enDistrito: "",
                                    enProvincia: "",
                                    enRegion: "",
                                    enunciado: ""
                                  };
  resDatosModel: ResDatosModel;

  probar: any;

  constructor(private comunService: ComunService, private dialogRef: MatDialogRef<ModalIncluyeComponent>,
    @Inject (MAT_DIALOG_DATA) data) {     
      this.region = data.region;   
      this.listaProvinciaPorRegion = data.listaProvincia;
      this.listaDistrito = data.listaDistrito;
      this.resDatosModel= {jurisdiccionUgel: this.jurisdiccionUgel}
      console.log("data de comprende");
      console.log(data);
     }

  ngOnInit(): void {
  }
  onSelectedCCPP(centroPoblado: CentroPoblado){
    if(this.selectedTipoUbigeo.CodTipoUbigeo==4){
       
      const _ubigeo: Ubigeo_= {
          IdUbigeo: centroPoblado.IdUbigeo,
          CodUbigeo: centroPoblado.CodUbigeo,
          Nombre: centroPoblado.Nombre,
          TipoUbigeo: this.selectedTipoUbigeo,
          CodRegion: this.region.CodUbigeo,  
          NomRegion: this.region.Nombre,
          CodProvincia: this.selectedProvincia.CodUbigeo,   
          NomProvincia: this.selectedProvincia.Nombre,
          CodDistrito: this.selectedDistrito.CodUbigeo,    
          NomDistrito: this.selectedDistrito.Nombre,
          CodCcpp: centroPoblado.CodUbigeo,  
          NomCcpp: centroPoblado.Nombre
      }
        this.jurisdiccionUgel.Ubigeo =_ubigeo;
        this.GenerarEnunciadoJurisdiccion(this.jurisdiccionUgel);
        
    }
    //console.log(centroPoblado); 
  }

  onSelectDistrito(distrito: Distrito){
    //if(this.tipoUbigeoControl.value.CodTipoUbigeo==3){
    if(this.selectedTipoUbigeo.CodTipoUbigeo==3){   
      const _ubigeo: Ubigeo_= {
          IdUbigeo: distrito.IdUbigeo,
          CodUbigeo: distrito.CodUbigeo,
          Nombre: distrito.Nombre,
          TipoUbigeo: this.selectedTipoUbigeo,
          CodRegion: this.region.CodUbigeo,  
          NomRegion: this.region.Nombre,
          CodProvincia: this.selectedProvincia.CodUbigeo,   
          NomProvincia: this.selectedProvincia.Nombre,
          CodDistrito: distrito.CodUbigeo,    
          NomDistrito: distrito.Nombre,
          CodCcpp: "",  
          NomCcpp: "",
      }
        this.jurisdiccionUgel.Ubigeo =_ubigeo;
        this.GenerarEnunciadoJurisdiccion(this.jurisdiccionUgel);
        
    }else{
        if (this.selectedDistrito != undefined && this.selectedDistrito != null){
          //this.onSelectCCPP.emit(this.selectedDistrito);
          //llamamos al metodo que devuelve los datos del servicio
          this.obtenerCCPPPorDistrito(this.selectedDistrito);
          this.ccppControl = new FormControl('');
          }
    }
  }

  onSelectedProvincia(provincia: Provincia) {
    //console.log(this.selectedProvincia);
    //console.log(this.provinciaControl.value);
    console.log("Provincia");
    console.log(provincia);
    console.log("codigo de ubigeo");
    console.log(this.selectedTipoUbigeo);
    //console.log(this.tipoUbigeoControl.value.CodTipoUbigeo);

    if(this.selectedTipoUbigeo.CodTipoUbigeo==2){       
      const _ubigeo: Ubigeo_= {
          IdUbigeo: provincia.IdUbigeo,
          CodUbigeo: provincia.CodUbigeo,
          Nombre: provincia.Nombre,
          TipoUbigeo: this.selectedTipoUbigeo,
          CodRegion: this.region.CodUbigeo,  
          NomRegion: this.region.Nombre,
          CodProvincia: provincia.CodUbigeo,  
          NomProvincia: provincia.Nombre,
          CodDistrito: "",    
          NomDistrito: "",
          CodCcpp: "",  
          NomCcpp: "",
      }
        this.jurisdiccionUgel.Ubigeo =_ubigeo;
        this.GenerarEnunciadoJurisdiccion(this.jurisdiccionUgel);
        
    }else{
      if (this.selectedProvincia != undefined && this.selectedProvincia != null){
        this.filtrarDistrito(provincia);
      }
    }
    //console.log(this.provinciaChild)    
  }

  /*onSelectedRegion(region: Region) {
    this.filtrarProvincia(region);
  }*/

  private filtrarDistrito(provincia: Provincia): Distrito[] {
    this.listaDistritoPorProvincia= this.listaDistrito.filter(option => option.Provincia.CodUbigeo==provincia.CodUbigeo);
  return this.listaDistrito;
}

onSelectedTipoUbigeo(tipoUbigeo: TipoUbigeo){

  this.tipoUbigeoControl.reset();
  this.regionControl.reset();
  this.provinciaControl.reset();
  this.distritoControl.reset();
  this.ccppControl.reset();

  switch(tipoUbigeo.CodTipoUbigeo) { 
    case 2: { 
      this.verRegion = true;
      this.verProvincia= true;
      this.verDistrito=false;
      this.verCcpp=false;
       break; 
    } 
    case 3: { 
      this.verRegion = true;
      this.verProvincia= true;
      this.verDistrito=true;
      this.verCcpp=false; 
       break; 
    } 
    case 4: { 
      this.verRegion = true;
      this.verProvincia= true;
      this.verDistrito=true;
      this.verCcpp=true;
      break; 
   } 
    default: { 
      this.verRegion = false;
      this.verProvincia= false;
      this.verDistrito=false;
      this.verCcpp=false;
       break; 
    } ;
  }
  
}

GenerarEnunciadoJurisdiccion(jurisdiccionUgel:Jurisdiccion){
            const espacio: string = " ";
            const articulo1: string = "el";
            const articulo2: string = "la";
            const predicadoDistrito: string = "del distrito";
            const predicadoProvincia: string = "de la provincia";
            const predicadoRegión: string = "del departamento";
            const sujetoCcpp: string = "los centros poblados del distrito";
            const sujetoDistrito: string = "los distritos de la provincia";
            const sujetosProvincia: string = "las provincias del departamento";

            switch (jurisdiccionUgel.Ubigeo.TipoUbigeo.CodTipoUbigeo)
              {
                case 4: //ccpp
                jurisdiccionUgel.terminoPertenencia = jurisdiccionUgel.TerminoPertenenciaJurisdiccion.DescTerminoPertenencia;
                jurisdiccionUgel.enCCPP = jurisdiccionUgel.Ubigeo.Nombre;
                jurisdiccionUgel.enDistrito = jurisdiccionUgel.Ubigeo.NomDistrito;
                jurisdiccionUgel.enProvincia = jurisdiccionUgel.Ubigeo.NomProvincia;
                jurisdiccionUgel.enRegion = jurisdiccionUgel.Ubigeo.NomRegion;
                jurisdiccionUgel.enunciado = jurisdiccionUgel.terminoPertenencia + espacio +
                                          articulo1 + espacio + jurisdiccionUgel.Ubigeo.TipoUbigeo.DescTipoUbigeo +
                                          espacio + jurisdiccionUgel.enCCPP + espacio + predicadoDistrito +
                                          espacio + jurisdiccionUgel.enDistrito + espacio + predicadoProvincia +
                                          espacio + jurisdiccionUgel.enProvincia + espacio + predicadoRegión +
                                          espacio + jurisdiccionUgel.enRegion;
                break;
                case 3: //distrito
                jurisdiccionUgel.terminoPertenencia = jurisdiccionUgel.TerminoPertenenciaJurisdiccion.DescTerminoPertenencia;
                jurisdiccionUgel.enDistrito = jurisdiccionUgel.Ubigeo.NomDistrito;
                jurisdiccionUgel.enProvincia = jurisdiccionUgel.Ubigeo.NomProvincia;
                jurisdiccionUgel.enRegion = jurisdiccionUgel.Ubigeo.NomRegion;
                jurisdiccionUgel.enunciado = jurisdiccionUgel.terminoPertenencia + espacio + 
                                            articulo1 + espacio + jurisdiccionUgel.Ubigeo.TipoUbigeo.DescTipoUbigeo +
                                            espacio + jurisdiccionUgel.enDistrito + espacio + predicadoProvincia +
                                            espacio + jurisdiccionUgel.enProvincia + espacio + predicadoRegión +
                                            espacio + jurisdiccionUgel.enRegion;
                break;
                case 2: //provincia
                jurisdiccionUgel.terminoPertenencia = jurisdiccionUgel.TerminoPertenenciaJurisdiccion.DescTerminoPertenencia;
                jurisdiccionUgel.enProvincia = jurisdiccionUgel.Ubigeo.NomProvincia;
                jurisdiccionUgel.enRegion = jurisdiccionUgel.Ubigeo.NomRegion;
                jurisdiccionUgel.enunciado = jurisdiccionUgel.terminoPertenencia + espacio +
                                              articulo2 + espacio + jurisdiccionUgel.Ubigeo.TipoUbigeo.DescTipoUbigeo +
                                              espacio + jurisdiccionUgel.enProvincia + espacio + predicadoRegión +
                                              espacio + jurisdiccionUgel.enRegion;
                break;
                case 1: // departamento (región)
                jurisdiccionUgel.terminoPertenencia = jurisdiccionUgel.TerminoPertenenciaJurisdiccion.DescTerminoPertenencia;
                jurisdiccionUgel.enRegion = jurisdiccionUgel.Ubigeo.NomRegion;
                jurisdiccionUgel.enunciado = jurisdiccionUgel.terminoPertenencia + espacio +
                                              articulo1 + espacio + jurisdiccionUgel.Ubigeo.TipoUbigeo.DescTipoUbigeo +
                                              espacio + jurisdiccionUgel.enRegion;
                break;
                }
}

/*private filtrarProvincia(region: Region): Provincia[] {
  this.listaProvinciaPorRegion= this.listaProvincia.filter(option => option.Region.CodUbigeo==region.CodUbigeo);
  return this.listaProvinciaPorRegion;
}*/

obtenerCCPPPorDistrito(distrito: Distrito):void {
  this.comunService.obtenerCCPPPorDistrito(distrito)
    .subscribe(res => this.listaCentroPoblado = res);    
}

close(val:string):void{
  if (val="CANCEL")
    {this.dialogRef.close();
    }
}

save(val:string):void{
  if (val="OK")
    {
      this.dialogRef.close(this.resDatosModel);
    } 
  }

}
