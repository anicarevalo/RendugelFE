import { Component, OnInit, Inject } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';

export interface ResDatosModel{
  titulo: string,
  mensaje: string
}

@Component({
  selector: 'app-modal-msn-aceptar',
  templateUrl: './modal-msn-aceptar.component.html',
  styleUrls: ['./modal-msn-aceptar.component.scss']
})
export class ModalMsnAceptarComponent implements OnInit {
  titulo: string = "Crear registro";
  mensaje: string = "Los datos se guardaron correctamente";
  resp:string="";
  resDatosModel: ResDatosModel

  constructor(private dialogRef: MatDialogRef<ModalMsnAceptarComponent>,
    @Inject (MAT_DIALOG_DATA) data) {
            //this.resDatosModel= {titulo: this.titulo, mensaje: this.mensaje}
            this.mensaje=data.mensaje;
            this.titulo=data.titulo;
            console.log(data);
     }

  ngOnInit(): void {
  }

  Aceptar(val:string):void{
    if (val="OK")
      {
        this.dialogRef.close("OK");
      } 
    }

}
