import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalMsnAceptarComponent } from './modal-msn-aceptar.component';

describe('ModalMsnAceptarComponent', () => {
  let component: ModalMsnAceptarComponent;
  let fixture: ComponentFixture<ModalMsnAceptarComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalMsnAceptarComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalMsnAceptarComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
