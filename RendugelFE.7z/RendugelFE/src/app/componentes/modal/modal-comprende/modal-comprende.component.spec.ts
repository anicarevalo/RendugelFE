import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalComprendeComponent } from './modal-comprende.component';

describe('ModalComprendeComponent', () => {
  let component: ModalComprendeComponent;
  let fixture: ComponentFixture<ModalComprendeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ModalComprendeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalComprendeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
