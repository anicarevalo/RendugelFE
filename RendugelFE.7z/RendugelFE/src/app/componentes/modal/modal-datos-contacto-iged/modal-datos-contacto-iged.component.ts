import { Component, OnInit, Inject } from '@angular/core';
import {MatDialogRef, MAT_DIALOG_DATA} from '@angular/material/dialog';
//import {IgedMedioContacto} from '../../../interfaces/iged-medio-contacto';
import {TipoMedioContacto} from '../../../interfaces/tipo-medio-contacto';
import {MedioContacto} from '../../../interfaces/medio-contacto';
import {FormControl, Validators} from '@angular/forms';

export interface ResDatosModel{
  tipoMedioContacto: TipoMedioContacto,
  medioContacto: MedioContacto
}

@Component({
  selector: 'app-modal-datos-contacto-iged',
  templateUrl: './modal-datos-contacto-iged.component.html',
  styleUrls: ['./modal-datos-contacto-iged.component.scss']
})
export class ModalDatosContactoIgedComponent implements OnInit {
  medioContacto: MedioContacto;
  tipoMedioContacto: TipoMedioContacto;
  resDatosModel: ResDatosModel;
  descripcion: string;
  Medio:string;
  descripcionForm= new FormControl;
  medionForm = new FormControl;
  valido: boolean= true;
  submitted = false;

  constructor(private dialogRef: MatDialogRef<ModalDatosContactoIgedComponent>,
    @Inject (MAT_DIALOG_DATA) data) {
      this.tipoMedioContacto = data.tipoMedioContacto;
      this.medioContacto = data.medioContacto;
      this.resDatosModel= {tipoMedioContacto: this.tipoMedioContacto, medioContacto: this.medioContacto}
      console.log(data);

      /*if (data.tipoMedioContacto.CodTipo == 3){        
        this.medionForm = new FormControl('', Validators.compose([
                                    Validators.required,
                                    Validators.pattern('^[a-zA-Z0-9_.+-]+@[a-zA-Z0-9-]+.[a-zA-Z0-9-.]+$')
                                  ]));
      }*/

      switch(data.tipoMedioContacto.CodTipo) { 
        case 1: { 
           //statements; 
           this.medionForm = new FormControl('', Validators.compose([
            Validators.required,
            Validators.pattern('^(?=.{6,50}$)(?:[0-9]+([0-9-])([0-9])+)$')
          ])); 
          break; 
        } 
        case 2: { 
           //statements; 
           this.medionForm = new FormControl('', Validators.compose([
            Validators.required,
            Validators.pattern('^(?=.{6,50}$)(?:[0-9]+([0-9-])(?:[0-9]){4,25})$')
          ]));
          break;   
        } 
        case 3: { 
          this.medionForm = new FormControl('', Validators.compose([
            Validators.required,
            Validators.pattern('^(?=.{1,64}$)(?:[a-zA-Z0-9_-]+(?:\.[a-zA-Z0-9_-]+)+)@(?=.{3,253}$)(?:[a-zA-Z0-9-]{2,63}(?:\.[a-zA-Z0-9-]{2,63})+)$')
          ])); 
          break; 
       }
       case 4: { 
        this.medionForm = new FormControl('', Validators.compose([
          Validators.required,
          Validators.pattern('^(www|http(s?):\/\/[0-9a-zA-Z])(.*\.(gob$|com$|pe$))')
        ]));
        break; 
       } 
        default: { 
           //statements; 
           break; 
        } 
     } 
     }

  ngOnInit(): void {
  }
  /*
  save() {
    this.dialogRef.close(this.descripcion);
  } 
  close() {
    this.dialogRef.close();
  }*/

  save(val:string):void{
    //this.tipoMedioContacto1.DescTipo=this.descripcion;
    this.submitted = true;
    if ((this.medionForm.invalid) && (this.medionForm.dirty || this.medionForm.touched))
    {this.valido = false; }

    if ((val="OK") && (this.valido))
      {        
        this.dialogRef.close(this.resDatosModel);
        //this.dialogRef.close(this.descripcion);
      } 
    else {this.valido = true;}
  }

  close(val:string):void{  
    console.log("this.submitted");
    console.log(this.submitted);
    console.log("val");
    console.log(val);
    this.submitted = false;
    if (val="CANCEL")
      {
        console.log("this.submitted2");
        console.log(this.submitted);
        console.log("val2");
        console.log(val);

        this.dialogRef.close();
      }
  }
}
