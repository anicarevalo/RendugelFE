import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ModalDatosContactoIgedComponent } from './modal-datos-contacto-iged.component';

describe('ModalDatosContactoIgedComponent', () => {
  let component: ModalDatosContactoIgedComponent;
  let fixture: ComponentFixture<ModalDatosContactoIgedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ModalDatosContactoIgedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ModalDatosContactoIgedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
