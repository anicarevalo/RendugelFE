import {Component, Inject, OnInit, Input, Output, ViewChild, EventEmitter} from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig} from '@angular/material/dialog';
import {ModalDatosContactoIgedComponent} from '../modal/modal-datos-contacto-iged/modal-datos-contacto-iged.component';
import {TipoMedioContacto} from '../../interfaces/tipo-medio-contacto';
import {MedioContacto} from '../../interfaces/medio-contacto';
import {TipoMedioContactoB} from '../../interfaces/tipo-medio-contacto-b'
//import {tiposMedioContacto} from '../../mock/DataTipoMedioContacto';

export interface DatosModel{
  tipoMedioContacto: TipoMedioContacto,
  medioContacto: MedioContacto
}

@Component({
  selector: 'app-datos-contacto-iged',
  templateUrl: './datos-contacto-iged.component.html',
  styleUrls: ['./datos-contacto-iged.component.scss']
})
export class DatosContactoIgedComponent{  

  @ViewChild("tablaMedios") tablaMedios;
  //medioContacto: IgedMedioContacto;
  @Input() tiposMedio: TipoMedioContacto[]; //= tiposMedioContacto;
  medioContacto: MedioContacto = 
      {
        IdMedioContactoIGED: 0,  
        IdIGEDRegistro: 0,  
        Medio: "",
        Descripcion: "", //Agregar esto en la tabla de la Base de datos (figura en el prototipo pero olvidé colocarlo en la BD)
        TipoMedioContacto: null  
      };
  datosModel: DatosModel;  

  //Para la tabla
  public datosTabla: MedioContacto[]=[];
    /*  { IdMedioContactoIGED: 0,  IdIGEDRegistro: 0,  Medio: "95682852", Descripcion: "Celu 1", 
        TipoMedioContacto: {IdTipoMedioContacto: 3,
                            CodTipoMedio: 3,
                            DescTipoMedio: "Email"}
        },
      { IdMedioContactoIGED: 0,  IdIGEDRegistro: 0,  Medio: "85966596", Descripcion: "Telf 1", 
        TipoMedioContacto: {IdTipoMedioContacto: 3,
                            CodTipoMedio: 3,
                            DescTipoMedio: "Email"}
        }
    ];*/

  displayedColumns: string[] =['Medio', 'Descripcion'];
  columnsToDisplay: string[] =['TipoMedioContacto', 'Medio', 'Descripcion', 'Eliminar'];

  constructor(public dialog: MatDialog) {
   }

  openDialog(_tipoMedio: TipoMedioContacto): void {
    //this.medioContacto.Descripcion = "";
    this.medioContacto = 
      {
        IdMedioContactoIGED: 0,  
        IdIGEDRegistro: 0,  
        Medio: "",
        Descripcion: "", //Agregar esto en la tabla de la Base de datos (figura en el prototipo pero olvidé colocarlo en la BD)
        TipoMedioContacto: null 
      };

    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose= true;
    dialogConfig.autoFocus = true;
    dialogConfig.hasBackdrop =true;
    dialogConfig.width= '420px';
    dialogConfig.data = this.datosModel ={tipoMedioContacto:_tipoMedio, medioContacto:this.medioContacto}

    const dialogRef = this.dialog.open(ModalDatosContactoIgedComponent, dialogConfig);    

    dialogRef.afterClosed().subscribe(
      res => {
        /*console.log(res),
      this.medioContacto= res.igedMedioContacto,
      console.log(this.medioContacto),*/        
        if (res!= undefined){
          this.addItemTabla(res.medioContacto, res.tipoMedioContacto);
        }
          
        });
      //this.datosTabla.push(this.medioContacto)
    }   
      //res => {this.medioContacto.Descripcion= res}
      addItemTabla(item:MedioContacto, tipo:TipoMedioContacto){
        console.log("hola:");
        console.log(item);
        
        const tipoMedioContactoB: TipoMedioContactoB = {IdTipoMedioContacto: tipo.IdTipoMedioContacto,
                                                        CodTipoMedio : tipo.CodTipo,
                                                        DescTipoMedio : tipo.DescTipo}
        item.TipoMedioContacto = tipoMedioContactoB ;

        this.datosTabla.push(item);
        console.log(this.datosTabla);
        this.tablaMedios.renderRows();
      }

      deleteItemTabla(indice:number){     
        if (confirm("¿Desea quitarlo de la lista?")) {   
          this.datosTabla.splice(indice,1);
          this.tablaMedios.renderRows();
        }
      }
    
  }

 

