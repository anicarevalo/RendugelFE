import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatosContactoIgedComponent } from './datos-contacto-iged.component';

describe('DatosContactoIgedComponent', () => {
  let component: DatosContactoIgedComponent;
  let fixture: ComponentFixture<DatosContactoIgedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatosContactoIgedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatosContactoIgedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
