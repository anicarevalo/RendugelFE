import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-btn-crear-reg-definitivo',
  templateUrl: './btn-crear-reg-definitivo.component.html',
  styleUrls: ['./btn-crear-reg-definitivo.component.scss']
})
export class BtnCrearRegDefinitivoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
