import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BtnCrearRegDefinitivoComponent } from './btn-crear-reg-definitivo.component';

describe('BtnCrearRegDefinitivoComponent', () => {
  let component: BtnCrearRegDefinitivoComponent;
  let fixture: ComponentFixture<BtnCrearRegDefinitivoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BtnCrearRegDefinitivoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BtnCrearRegDefinitivoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
