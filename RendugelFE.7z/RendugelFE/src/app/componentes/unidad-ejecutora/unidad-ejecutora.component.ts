import { Component, OnInit, Input } from '@angular/core';
import {FormControl} from '@angular/forms';
import {PliegoUnidadEjecutora} from '../../interfaces/pliego-unidad-ejecutora';

@Component({
  selector: 'app-unidad-ejecutora',
  templateUrl: './unidad-ejecutora.component.html',
  styleUrls: ['./unidad-ejecutora.component.scss']
})
export class UnidadEjecutoraComponent implements OnInit {
  @Input() listaPliegoUE: PliegoUnidadEjecutora[];
  @Input() titulo: string;
  selectPliegoUE: PliegoUnidadEjecutora;
  codUnidadEjecutora:string;
  descUnidadEjecutora:string;
  esUEAutonoma: number;
  ver:boolean;
  pliegoUEControl = new FormControl();
  

  constructor() { }

  ngOnInit(): void {
  }

  onSelectCasilla(e: any){
    console.log(e);
    if (e==0){
      this.ver=false;
    }
    if (e==1){this.ver=true;}
  }

}
