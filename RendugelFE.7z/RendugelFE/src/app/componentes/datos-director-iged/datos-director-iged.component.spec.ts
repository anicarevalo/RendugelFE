import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatosDirectorIgedComponent } from './datos-director-iged.component';

describe('DatosDirectorIgedComponent', () => {
  let component: DatosDirectorIgedComponent;
  let fixture: ComponentFixture<DatosDirectorIgedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatosDirectorIgedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatosDirectorIgedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
