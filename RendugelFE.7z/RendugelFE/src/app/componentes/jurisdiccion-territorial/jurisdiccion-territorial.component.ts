import { Component, OnInit, Input, Output,ViewChild, ElementRef, EventEmitter } from '@angular/core';
import {FormControl} from '@angular/forms';
import {DATA_JURISDICCION} from '../../mock/DataEntidadJurisdiccion';
import {Iged} from '../../interfaces/iged';
import {Naturaleza} from '../../interfaces/naturaleza';
import {EventoRegistral} from '../../interfaces/evento-registral';
import {IgedJurisdiccionResponse} from '../../interfaces/iged-jurisdiccion-response';
import {ParametrosRegistro} from '../../interfaces/parametros-registro';
import {ComunService} from '../../servicios/comun.service';
import {DataInternaService} from '../../servicios/data-interna.service';
import {Distrito}from '../../interfaces/distrito';
import {Provincia}from '../../interfaces/provincia';
import {Region}from '../../interfaces/region';
import {Ugel} from '../../interfaces/ugel';
import {IgedRegistroDefinitivoDetalle} from '../../interfaces/iged-registro-definitivo-detalle';
import {CentroPoblado}from '../../interfaces/centro-poblado';
import { Jurisdiccion } from 'src/app/interfaces/jurisdiccion';

//const cdisplayedColumns : string[] = ['item', 'termino', 'centroPoblado', 'distrito', 'provincia', 'region', 'accion'];
const cdisplayedColumns : string[] = ['item', 'enunciado', 'eliminar'];
const cdisplayedColumnsCierre: string[] = ['item', 'ugel', 'enunciado', 'eliminar'];


@Component({
  selector: 'app-jurisdiccion-territorial',
  templateUrl: './jurisdiccion-territorial.component.html',
  styleUrls: ['./jurisdiccion-territorial.component.scss']
})
export class JurisdiccionTerritorialComponent implements OnInit {
  ugeles = new FormControl();
  ugelesCierre = new FormControl();
  mostrarCierre: boolean = false;
  //@Input() 
  listaUgel: Iged[];
  listaUgelCierre: Iged[];
  @Input() parametrosRegistro: ParametrosRegistro;
  @Input() idDRE: string;
  @Input() ugel: Ugel;
  //@Input() 
  listaEventoRegistral: EventoRegistral[];
  //@Input() listaEventoRegistralPorNaturaleza: EventoRegistral[];
  //@Input() listaNaturaleza: Naturaleza[];
  listaIgedJurisdiccionResponse: IgedJurisdiccionResponse[];
  listaIgedJurisdiccionCierreResponse: IgedJurisdiccionResponse[];

  listaDistrito : Distrito[];
  listaProvincias : Provincia[];
  listaRegion : Region[];
  region : Region;

  @ViewChild("selectUgeles") selectUgeles;  
  @ViewChild("selectUgelesCierre") selectUgelesCierre;  
  @ViewChild("tablaCierre") tablaCierre;
  @ViewChild("jurisdiccionEnunciados") jurisdiccionEnunciados;
  @ViewChild("jurisdiccionUgelOrigen") jurisdiccionUgelOrigen;  
  //selectedNaturaleza: Naturaleza;
  //selectedEventoResgistral: EventoRegistral;
  displayedColumns:  string[] = cdisplayedColumns;
  displayedColumnsCierre: string[] = cdisplayedColumnsCierre;
  eventoModificacionJurisdiccion: EventoRegistral = {IdEventoRegistral:0, CodEvento:0, DescEvento:"", Naturaleza:null};
  eventoCierre: EventoRegistral = {IdEventoRegistral:0, CodEvento:0, DescEvento:"", Naturaleza:null};
  //element_data: EntidadJurisdiccion[] = DATA_JURISDICCION;

  public jurisdiccionUgelOriginal: Jurisdiccion[];
  public ugelInvolucradas: Iged[] ;
  public ugelInvolucradasCierre: Iged[] ;
  public count: any;
  visible: boolean= true;

  constructor(private comunService: ComunService, private dataInternaService: DataInternaService) {         
  }

  ngOnInit(): void {    
    //console.log("Parametros registro")
    //console.log(this.parametrosRegistro)     
    console.log("this.idDRE");
    console.log(this.idDRE);
    console.log("ugel para mi jurisdiccion");
    console.log(this.ugel)
    this.obtenerOpcionesJurisdiccion(this.parametrosRegistro);  
    this.obtenerOpcionesUbigeo(this.idDRE);
  }

  /*onSelectedEventoRegistral(naturaleza: Naturaleza) {
    this.filtrarEventoRegistral(naturaleza);
  }*/

  ver(e:any){
    console.log(this.selectUgeles);
    console.log(e);
  }

  obtenerOpcionesJurisdiccion (parametrosRegistro: ParametrosRegistro):void {
    this.comunService.obtenerOpcionesJurisdiccion(parametrosRegistro)
    .subscribe(res => {
      //console.log("res lista eventos registral")
      //console.log(res);
      if(res!=undefined)
      {
      this.listaUgel = res['ListaUgel'];
      this.listaUgelCierre = res['ListaUgel'];
      this.listaEventoRegistral = res['ListaEventoRegistralC'];  

      this.eventoModificacionJurisdiccion = this.listaEventoRegistral.find(element => element.CodEvento == 4)
      this.eventoCierre = this.listaEventoRegistral.find(element => element.CodEvento == 8)

      //console.log("ListaEventosRegistrales");
      //console.log(this.listaEventoRegistral); 
      }
      //this.listaNaturaleza = res['ListaNaturalezaC']
      });
    }

    obtenerOpcionesUbigeo(IdDre:string):void{
    
      this.comunService.obtenerOpcionesUbigeo(IdDre)
      .subscribe(res => {
        this.listaDistrito = res['ListaDistritos'],
        this.listaProvincias = res['ListaProvincias'],           
        this.listaRegion= [this.region  = res['Region']];

        console.log("ver res de obtener ubigeos");
        console.log(res);

        console.log("this.listaProvincias");
        console.log(this.listaProvincias);

        console.log("this.listaDistrito");
        console.log(this.listaDistrito);
      });
  
      //.subscribe(res => console.log(res));
      //.subscribe(res => this.opcionesUbigeo = res);
    }

  crearGrillasJurisdiccion(): void {
    this.visible = true;
    this.ugelInvolucradas = [];
    this.ugelInvolucradas = this.ugeles.value;
    this.count = this.ugelInvolucradas[0].NomIged; //ugelInvolucradas.length; para probar    
    //this.ugeles.reset();
    this.comunService.ObtenerJurisdiccionUgelPorListaUgeles(this.ugelInvolucradas)
    .subscribe(res => {
          this.listaIgedJurisdiccionResponse = res;
          console.log("Ver jurisdicción por Ugel");
          console.log(res)
          })
  }

  crearGrillasJurisdiccionCierre(): void {
    this.visible = true;
    this.ugelInvolucradasCierre = [];
    this.ugelInvolucradasCierre = this.ugelesCierre.value;
    //this.count = this.ugelInvolucradasCierre[0].NomIged; //ugelInvolucradas.length; para probar    
    //this.ugeles.reset();
    this.comunService.ObtenerJurisdiccionUgelPorListaUgeles(this.ugelInvolucradasCierre)
    .subscribe(res => {
      this.listaIgedJurisdiccionCierreResponse = res;
      if(this.listaIgedJurisdiccionCierreResponse!=undefined && this.listaIgedJurisdiccionCierreResponse.length>0)
          {
            this.mostrarCierre= true;

            const _eventoRegistral: EventoRegistral= {
              IdEventoRegistral: 8,
              CodEvento: 8,
              DescEvento: "Cierre definitivo",
              Naturaleza: {
                IdNaturaleza:4,
                CodNaturaleza: 4,
                DescNaturaleza: "Cierre definitivo"
              }
            };

            this.listaIgedJurisdiccionCierreResponse.forEach(element => {
              this.dataInternaService.guardarTempDefinitivoDetalle(element.Ugel,element.JurisdiccionUgel, _eventoRegistral, false )
            });
             
            console.log("Ver jurisdicción Cierre por Ugel");
            console.log(res)  
          }        
      })
          //this.listaIgedJurisdiccionCierreResponse[0].Ugel.NomIged
          //this.listaIgedJurisdiccionCierreResponse[0].JurisdiccionUgel[0].enunciado
  }

 eliminarGrilla(iged: Iged){       
    this.removeItemFromArr(this.ugelInvolucradas, iged);
    this.ugeles.reset();
    this.ugeles = new FormControl(this.ugelInvolucradas);     
   }  
  
  removeItemFromArr ( arr, item ) {
    var i = arr.indexOf( item ); 
    if ( i !== -1 ) {
        arr.splice( i, 1 );
    }
    return arr;
  }

  deleteItemTabla(indice:number){     
    if (confirm("¿Desea quitarlo de la lista?")) {  

      const _eliminado: IgedJurisdiccionResponse = {
        JurisdiccionUgel:this.listaIgedJurisdiccionCierreResponse[indice].JurisdiccionUgel,
        Ugel: this.listaIgedJurisdiccionCierreResponse[indice].Ugel
      }      
      console.log("eliminado");
      console.log(_eliminado);

      this.listaIgedJurisdiccionCierreResponse.splice(indice,1);
      if(this.listaIgedJurisdiccionCierreResponse!=undefined && this.listaIgedJurisdiccionCierreResponse.length>0)
          {
            this.mostrarCierre= true;
          }
      else {
        this.mostrarCierre=false        
      }
      this.tablaCierre.renderRows();

      //Quitar de storage.
      let  _definitivoDetalle: IgedRegistroDefinitivoDetalle[]=[];
        const _esOrigen = false
        const _eventoRegistral: EventoRegistral= {
          IdEventoRegistral: 8,
          CodEvento: 8,
          DescEvento: "Cierre definitivo",
          Naturaleza: {
            IdNaturaleza:4,
            CodNaturaleza: 4,
            DescNaturaleza: "Cierre definitivo"
          }
        };       

        //Quitar elemento del storage
        if (!(localStorage.getItem('definitivoDetalle')===null)){          
          _definitivoDetalle = JSON.parse(localStorage.getItem('definitivoDetalle'));        
          const indice:number =  _definitivoDetalle.findIndex(e => (e.EventoRegistral.CodEvento== _eventoRegistral.CodEvento
                                                                    && e.Ugel.CodIged ==_eliminado.Ugel.CodIged
                                                                    && e.EsOrigen == false))
            
          if (indice != undefined && indice >=0){
           _definitivoDetalle.splice(indice,1);
            localStorage.setItem('definitivoDetalle', JSON.stringify(_definitivoDetalle));
          }  
        }
    }
  }

/*guardarTempDefinitivoDetalle(_ugel: Iged, JurisdiccionIged: Jurisdiccion[], _eventoRegistral:EventoRegistral, _esOrigen: boolean){
  let  _definitivoDetalle: IgedRegistroDefinitivoDetalle[]=[];

  const _IgedRegistroDefinitivoDetalle: IgedRegistroDefinitivoDetalle=
      {
        IdIgedRegistro: 0,
        EsOrigen: _esOrigen,
        Ugel: _ugel,
        EventoRegistral: _eventoRegistral,        
        JurisdiccionIged: JurisdiccionIged//this.dataSource
      }     
      if (localStorage.getItem('definitivoDetalle')===null){
        _definitivoDetalle.push(_IgedRegistroDefinitivoDetalle)
        localStorage.setItem('definitivoDetalle', JSON.stringify(_definitivoDetalle));
      }
      else{
        //let _IgedRegistroDefinitivoDetalle1: IgedRegistroDefinitivoDetalle;
        _definitivoDetalle = JSON.parse(localStorage.getItem('definitivoDetalle'));        
        const indice:number =  _definitivoDetalle.findIndex(e => (e.Ugel.CodIged== this.ugel.CodIged 
                                                                  && e.EventoRegistral.CodEvento== _eventoRegistral.CodEvento))

        if (indice != undefined && indice >=0){
         _definitivoDetalle[indice].JurisdiccionIged = JurisdiccionIged //this.dataSource
          localStorage.setItem('definitivoDetalle', JSON.stringify(_definitivoDetalle));
        }
        else{
          _definitivoDetalle.push(_IgedRegistroDefinitivoDetalle)
          localStorage.setItem('definitivoDetalle', JSON.stringify(_definitivoDetalle));
        }        
      } 
  }*/


}




























