import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { JurisdiccionTerritorialComponent } from './jurisdiccion-territorial.component';

describe('JurisdiccionTerritorialComponent', () => {
  let component: JurisdiccionTerritorialComponent;
  let fixture: ComponentFixture<JurisdiccionTerritorialComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ JurisdiccionTerritorialComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(JurisdiccionTerritorialComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
