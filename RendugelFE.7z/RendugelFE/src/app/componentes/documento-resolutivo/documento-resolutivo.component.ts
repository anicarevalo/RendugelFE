import { Component, OnInit, Input, ViewChild } from '@angular/core';
import {MatDatepickerInputEvent} from '@angular/material/datepicker';
import {FormControl, Validators} from '@angular/forms';
import {TipoDocumento} from '../../interfaces/tipo-documento';
import {OpcionesDocumentoResolutivoService} from '../../servicios/opciones-documento-resolutivo.service';
import { dateInputsHaveChanged } from '@angular/material/datepicker/datepicker-input-base';
import { Documento } from 'src/app/interfaces/documento';
import {DataInternaService} from '../../servicios/data-interna.service';
import {ComunService} from '../../servicios/comun.service';

@Component({
  selector: 'app-documento-resolutivo',
  templateUrl: './documento-resolutivo.component.html',
  styleUrls: ['./documento-resolutivo.component.scss']
})
export class DocumentoResolutivoComponent implements OnInit {
  //dataTipoDocumento: TipoDocumento[];

  @Input() listaTipoDocumento: TipoDocumento[];
  @Input() titulo: string;
  @Input() editar: boolean=false;
 //@Input() documentoResolutivo: Documento;

  @ViewChild("uploadFile") uploadFile;

  selectedTipoDocumento: TipoDocumento;

  fechaDocumento = new FormControl('', [Validators.required]);
  fechaPublicacion = new FormControl('', [Validators.required]);
  nroDoc = new FormControl('',[Validators.required]);
  tipoDocumentoControl = new FormControl('',[Validators.required]);

  minDateFechaDoc: Date;
  maxDateFechaDoc: Date;
  minDateFechaPub: Date;
  maxDateFechaPub: Date;
  
  nroDocumento: string ="";

  disablePub: boolean = false;
  //editar: boolean= false;
  documentoResolutivoEditar: Documento;
  
  //constructor(private opcionesDocumentoResolutivoService: OpcionesDocumentoResolutivoService) {
  constructor(private dataService: DataInternaService, private comunService: ComunService) {
    console.log("this.editar");
    console.log(this.editar);
    this.editar = dataService.editar;
    if ((this.dataService.registroBandejaRequest != null) && this.editar){
      this.documentoResolutivoEditar = this.dataService.registroBandejaRequest.DocumentoResolutivo;
      this.nroDocumento = this.documentoResolutivoEditar.NroDocumento.toString();
      //this.editar = true;
      
      //this.fechaDocumento.setValue(this.dataService.registroBandejaRequest.DocumentoResolutivo.FechaEmision);
      //this.fechaPublicacion.setValue(this.dataService.registroBandejaRequest.DocumentoResolutivo.FechaPublicacion); 
      }

    const currenDate = new Date();
    const currentYear = new Date().getFullYear();

    this.minDateFechaDoc = new Date(currentYear - 20, 0, 1);
    this.maxDateFechaDoc = currenDate; //new Date(currentYear + 1, 11, 31);
    this.minDateFechaPub = new Date(currentYear - 20, 0, 1);
    this.maxDateFechaPub = currenDate; //new Date(currentYear + 1, 11, 31);
    
  }

  onFileComplete(data: any) {
    console.log(data);
  }

  ngOnInit(): void {
  }

  getFechaDocumento(date: Date){
    console.log(date);
    this.minDateFechaPub = date;  
    
    if(date != null){
      this.disablePub = true;
      //console.log(this.nroDoc.invalid);
    }
  }

  downloadResolucion(){
    //const documento: Documento= null;
    this.comunService.getPDF(this.documentoResolutivoEditar)
      .subscribe((data) => {
                let blob = new Blob([data], {type: 'application/pdf'});
              
                var downloadURL = window.URL.createObjectURL(blob);
                window.open(downloadURL);    

                setTimeout(function () {
                  // For Firefox it is necessary to delay revoking the ObjectURL
                  window.URL.revokeObjectURL(downloadURL);                  
              }, 100);
    });
  }

  /*getDataServicio(): void {
    this.opcionesDocumentoResolutivoService.getDataServicio()
        .subscribe(dataTipoDocumento => this.dataTipoDocumento = dataTipoDocumento);
  }*/

}
