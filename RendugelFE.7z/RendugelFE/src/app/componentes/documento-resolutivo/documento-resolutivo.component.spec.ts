import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentoResolutivoComponent } from './documento-resolutivo.component';

describe('DocumentoResolutivoComponent', () => {
  let component: DocumentoResolutivoComponent;
  let fixture: ComponentFixture<DocumentoResolutivoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentoResolutivoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentoResolutivoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
