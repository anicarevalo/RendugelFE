import {Component, OnInit, ViewChild, Input} from '@angular/core';
import {animate, state, style, transition, trigger} from '@angular/animations';
import {MatPaginator} from '@angular/material/paginator';
import {MatSort} from '@angular/material/sort';
import {MatTableDataSource} from '@angular/material/table';
import {ItemBandejaRegistros} from '../../interfaces/itemBandejaRegistros';
import {RegistroBandeja} from '../../interfaces/registro-bandeja';
import {IgedRegistroDetalle} from '../../interfaces/iged-registro-detalle';
import {SeleccionOpcionesRegistro} from '../../interfaces/seleccion-Opciones-Registro';
import {Documento} from '../../interfaces/documento';
import {BandejaRegistroService} from '../../servicios/bandeja-registro.service';
import {DataInternaService} from '../../servicios/data-interna.service';
import {ComunService} from '../../servicios/comun.service';
import {Router} from '@angular/router';

/**
 * @title Data table with sorting, pagination, and filtering.
 */

@Component({
  selector: 'app-grilla-bandeja',
  templateUrl: './grilla-bandeja.component.html',
  styleUrls: ['./grilla-bandeja.component.scss'],
  animations: [
    trigger('detailExpand', [
      state('collapsed', style({height: '0px', minHeight: '0'})),
      state('expanded', style({height: '*'})),
      transition('expanded <=> collapsed', animate('225ms cubic-bezier(0.4, 0.0, 0.2, 1)')),
    ]),
  ],
})
export class GrillaBandejaComponent implements OnInit {
  @Input() dataBandeja : RegistroBandeja[];

  //displayedColumns: string[] = [ 'Detalle', 'Item','CodRegistro', 'Estado', 'CodTipoRegistro', 'UsuCreacion', 'Acciones' ];
  displayedColumns: string[] = [ 'Detalle', 'CodRegistro', 'Estado', 'CodTipoRegistro', 'Documento', 'UsuCreacion', 'Acciones' ];
  dataSource: MatTableDataSource<RegistroBandeja>;
  //expandedElement: RegistroBandeja | null;
  isTableExpanded = false;
  iconDetalleCollapsed:string = "folder";
  iconDetalleExpanded:string="unarchive";
  iconDetalle: string = this.iconDetalleCollapsed;

  displayedColumnsDetalle: string[] = ['Item', 'CodUgel', 'Ugel', 'EventoRegistral', 'EventoOrigen' ];
  registroDetalle:IgedRegistroDetalle[]; 

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;
  @ViewChild("objTabla") objTabla;

 constructor(private bandejaRegistroService: BandejaRegistroService, 
                     private dataService: DataInternaService,
                     private comunService: ComunService,
                     private router: Router) { 
    //this.getDataBandeja();    
    this.dataSource = new MatTableDataSource(this.dataBandeja); 
    console.log(this.dataBandeja);
  }

  ngAfterViewInit() {
    
  }

  ngOnInit(): void {
    //this.getDataBandeja();
    console.log('oninit');
    console.log(this.dataBandeja);
    this.dataSource.paginator = this.paginator;
    this.dataSource.sort = this.sort;        
  }

  toggleTableRows() {
    this.isTableExpanded = !this.isTableExpanded;

    this.dataSource.data.forEach((row: any) => {
      row.isExpanded = this.isTableExpanded;
    })
  }

  toggleRows(row:any) {
      /*this.dataSource.data.forEach((row: any) => {
      row.isExpanded = false;
    })*/
    //this.iconDetalle= this.iconDetalleExpanded;
    //console.log(row);
    const j= this.dataSource.data.findIndex(obj => obj.IdRegistro === row.IdRegistro)
    console.log("Indice");
    console.log(j);
    console.log("IdRegistro");
    console.log(row.IdRegistro);

    let idRegistro: number = row.IdRegistro;
    this.comunService.obtenerRegistroDetallePorIdRegistro(idRegistro)
    .subscribe(res => { 
      console.log(res)
      if (res!= undefined && res!=null){
        //this.registroDetalle = res;
        row.ListaDetalle=res;
        console.log(this.registroDetalle);
      }
    });

    row.isExpanded = !row.isExpanded; 
  }

  eliminarRegistro(item: RegistroBandeja){
    if (confirm("¿Desea eliminar el registro " + item.CodRegistro + "?")) {   
      let idRegistro :number = item.IdRegistro;
      console.log(this.dataSource); 
      this.comunService.ElimarRegistro(idRegistro)
      .subscribe(res => {
          console.log(res);          

          if(res != undefined && res['ResultValid']){
            const _idRegistro = res['idRegistro'];
            this.dataBandeja = this.dataSource.data;
            const indice = this.dataBandeja.findIndex(e => e.IdRegistro==_idRegistro);
            this.dataBandeja.splice(indice,1);            
            this.dataSource = new MatTableDataSource(this.dataBandeja); 
            this.dataSource.paginator = this.paginator;
            this.dataSource.sort = this.sort; 
            this.objTabla.renderRows();
          }
      });
    }
  }

  downloadResolucion(documento: Documento){
    this.comunService.getPDF(documento)
    .subscribe((data) => {
              let blob = new Blob([data], {type: 'application/pdf'});
            
              var downloadURL = window.URL.createObjectURL(blob);
              window.open(downloadURL);    

              setTimeout(function () {
                // For Firefox it is necessary to delay revoking the ObjectURL
                window.URL.revokeObjectURL(downloadURL);                  
            }, 100);
    });
  }
  
  editarRegistro(item: RegistroBandeja){
    this.dataService.registroBandejaRequest = item;
    this.dataService.editar = true;
    let idRegistro :number = item.IdRegistro;
    this.dataService.opcionesRegistro={
      Dre: null,
      EventoRegistral: null,
      TipoRegistro: null,
      Tipoiged: null,
      Naturaleza: null,
      Ugel: null  
    }

    this.comunService.obtenerRegistroDetallePorIdRegistro(idRegistro)
    .subscribe(res => { 
      //console.log("res");
      //console.log(res);    
      if (res!= undefined && res!=null){
        this.dataService.detalleRegistroRequest = res;

        this.dataService.opcionesRegistro.Dre=this.dataService.detalleRegistroRequest[0].Dre;
        this.dataService.opcionesRegistro.EventoRegistral = this.dataService.detalleRegistroRequest[0].EventoRegistral;
        this.dataService.opcionesRegistro.TipoRegistro = this.dataService.registroBandejaRequest.TipoRegistro;
        this.dataService.opcionesRegistro.Tipoiged = this.dataService.detalleRegistroRequest[0].TipoIged;
        this.dataService.opcionesRegistro.Naturaleza = this.dataService.detalleRegistroRequest[0].EventoRegistral.Naturaleza;
        this.dataService.opcionesRegistro.Ugel = {
            CodIged:this.dataService.detalleRegistroRequest[0].Ugel.CodIged,
            CodTipoIged:this.dataService.detalleRegistroRequest[0].TipoIged.CodTipoIged,
            DescTipoIged:this.dataService.detalleRegistroRequest[0].TipoIged.DescTipoIged,
            IdIged:this.dataService.detalleRegistroRequest[0].Ugel.IdIged,
            IdTipoIged:this.dataService.detalleRegistroRequest[0].TipoIged.IdTipoIged,
            NomIged:this.dataService.detalleRegistroRequest[0].Ugel.NomIged
        }

        this.router.navigate(['/NuevoRegistroProvisional']);
      }
      });
  }

  pasarDefinitivo(item: RegistroBandeja){
      this.dataService.registroBandejaRequest = item;
      this.dataService.editar = false;
      let idRegistro: number = item.IdRegistro;
      this.dataService.opcionesRegistro={
        Dre: null,
        EventoRegistral: null,
        TipoRegistro: null,
        Tipoiged: null,
        Naturaleza: null,
        Ugel: null  
      }
      this.comunService.obtenerRegistroDetallePorIdRegistro(idRegistro)
    .subscribe(res => { 
      //console.log("res");
      //console.log(res);    
      if (res!= undefined && res!=null){
        this.dataService.detalleRegistroRequest = res;

        this.dataService.opcionesRegistro.Dre=this.dataService.detalleRegistroRequest[0].Dre;
        this.dataService.opcionesRegistro.EventoRegistral = this.dataService.detalleRegistroRequest[0].EventoRegistral;
        this.dataService.opcionesRegistro.TipoRegistro = this.dataService.registroBandejaRequest.TipoRegistro;
        this.dataService.opcionesRegistro.Tipoiged = this.dataService.detalleRegistroRequest[0].TipoIged;
        this.dataService.opcionesRegistro.Naturaleza = this.dataService.detalleRegistroRequest[0].EventoRegistral.Naturaleza;
        this.dataService.opcionesRegistro.Ugel = {
            CodIged:this.dataService.detalleRegistroRequest[0].Ugel.CodIged,
            CodTipoIged:this.dataService.detalleRegistroRequest[0].TipoIged.CodTipoIged,
            DescTipoIged:this.dataService.detalleRegistroRequest[0].TipoIged.DescTipoIged,
            IdIged:this.dataService.detalleRegistroRequest[0].Ugel.IdIged,
            IdTipoIged:this.dataService.detalleRegistroRequest[0].TipoIged.IdTipoIged,
            NomIged:this.dataService.detalleRegistroRequest[0].Ugel.NomIged
        }

        this.router.navigate(['/NuevoRegistroDefinitivo']);
      }
      });
    }     

  suspender(item: RegistroBandeja){
      this.dataService.registroBandejaRequest = item;
      let idRegistro: number = item.IdRegistro;
      this.dataService.opcionesRegistro={
        Dre: null,
        EventoRegistral: null,
        TipoRegistro: null,
        Tipoiged: null,
        Naturaleza: null,
        Ugel: null  
      }
      this.comunService.obtenerRegistroDetallePorIdRegistro(idRegistro)
    .subscribe(res => { 
      //console.log("res");
      //console.log(res);    
      if (res!= undefined && res!=null){
        this.dataService.detalleRegistroRequest = res;

        this.dataService.opcionesRegistro.Dre=this.dataService.detalleRegistroRequest[0].Dre;
        this.dataService.opcionesRegistro.EventoRegistral = this.dataService.detalleRegistroRequest[0].EventoRegistral;
        this.dataService.opcionesRegistro.TipoRegistro = this.dataService.registroBandejaRequest.TipoRegistro;
        this.dataService.opcionesRegistro.Tipoiged = this.dataService.detalleRegistroRequest[0].TipoIged;
        this.dataService.opcionesRegistro.Naturaleza = this.dataService.detalleRegistroRequest[0].EventoRegistral.Naturaleza;
        this.dataService.opcionesRegistro.Ugel = {
            CodIged:this.dataService.detalleRegistroRequest[0].Ugel.CodIged,
            CodTipoIged:this.dataService.detalleRegistroRequest[0].TipoIged.CodTipoIged,
            DescTipoIged:this.dataService.detalleRegistroRequest[0].TipoIged.DescTipoIged,
            IdIged:this.dataService.detalleRegistroRequest[0].Ugel.IdIged,
            IdTipoIged:this.dataService.detalleRegistroRequest[0].TipoIged.IdTipoIged,
            NomIged:this.dataService.detalleRegistroRequest[0].Ugel.NomIged
        }
        this.router.navigate(['/SuspensionRegistro']);
      }
      });
    }

    cancelar(item: RegistroBandeja){
      this.dataService.registroBandejaRequest = item;
      let idRegistro: number = item.IdRegistro;
      this.dataService.opcionesRegistro={
        Dre: null,
        EventoRegistral: null,
        TipoRegistro: null,
        Tipoiged: null,
        Naturaleza: null,
        Ugel: null  
      }
      this.comunService.obtenerRegistroDetallePorIdRegistro(idRegistro)
    .subscribe(res => { 
      //console.log("res");
      //console.log(res);    
      if (res!= undefined && res!=null){
        this.dataService.detalleRegistroRequest = res;

        this.dataService.opcionesRegistro.Dre=this.dataService.detalleRegistroRequest[0].Dre;
        this.dataService.opcionesRegistro.EventoRegistral = this.dataService.detalleRegistroRequest[0].EventoRegistral;
        this.dataService.opcionesRegistro.TipoRegistro = this.dataService.registroBandejaRequest.TipoRegistro;
        this.dataService.opcionesRegistro.Tipoiged = this.dataService.detalleRegistroRequest[0].TipoIged;
        this.dataService.opcionesRegistro.Naturaleza = this.dataService.detalleRegistroRequest[0].EventoRegistral.Naturaleza;
        this.dataService.opcionesRegistro.Ugel = {
            CodIged:this.dataService.detalleRegistroRequest[0].Ugel.CodIged,
            CodTipoIged:this.dataService.detalleRegistroRequest[0].TipoIged.CodTipoIged,
            DescTipoIged:this.dataService.detalleRegistroRequest[0].TipoIged.DescTipoIged,
            IdIged:this.dataService.detalleRegistroRequest[0].Ugel.IdIged,
            IdTipoIged:this.dataService.detalleRegistroRequest[0].TipoIged.IdTipoIged,
            NomIged:this.dataService.detalleRegistroRequest[0].Ugel.NomIged
        }
        this.router.navigate(['/CancelarRegistros']);
      } 
      });
    }

      //this.dataService.opcionesRegistro = seleccionOpcionesRegistro;
      //console.log(this.dataService.registroBandejaRequest);
      //console.log(item);item
      //this.router.navigate(['/NuevoRegistroDefinitivo']);
  //}

  /*getDataBandeja(): void {
    this.bandejaRegistroService.getDataBandeja()
        .subscribe(dataBandeja => this.dataBandeja = dataBandeja);
  }*/

  applyFilter(event: Event) {
    const filterValue = (event.target as HTMLInputElement).value;
    this.dataSource.filter = filterValue.trim().toLowerCase();

    if (this.dataSource.paginator) {
      this.dataSource.paginator.firstPage();
    }
  }

}

