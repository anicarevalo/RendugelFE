import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GrillaBandejaComponent } from './grilla-bandeja.component';

describe('GrillaBandejaComponent', () => {
  let component: GrillaBandejaComponent;
  let fixture: ComponentFixture<GrillaBandejaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GrillaBandejaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GrillaBandejaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
