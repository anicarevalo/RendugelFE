import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { FileUploadSelfComponent } from './file-upload-self.component';

describe('FileUploadSelfComponent', () => {
  let component: FileUploadSelfComponent;
  let fixture: ComponentFixture<FileUploadSelfComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ FileUploadSelfComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(FileUploadSelfComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
