import {Component, Inject, OnInit, Input, Output, ViewChild, EventEmitter} from '@angular/core';
import {FormControl, Validators, FormBuilder, FormGroup} from '@angular/forms';
import {TipoMedioContacto} from '../../interfaces/tipo-medio-contacto';
import {PersonalMedioContacto} from '../../interfaces/personal-medio-contacto';
//import {tiposPersonal} from '../../mock/DataTipoPersonal';
import {TipoPersonal} from '../../interfaces/tipo-personal';
import {Personal} from '../../interfaces/personal';

@Component({
  selector: 'app-personal-responsable-iged',
  templateUrl: './personal-responsable-iged.component.html',
  styleUrls: ['./personal-responsable-iged.component.scss']
})
export class PersonalResponsableIgedComponent implements OnInit {
  // para los datos personal
  cont: number = 0;
  selectedTipoPersonal: TipoPersonal;
  @Input() listaTipoPersonal: TipoPersonal[]; //=tiposPersonal;   
  dniPersonal: string;
  nombrePersonal: string;
  apePatPersonal: string;
  apeMatPersonal: string;
  telefonoPersonal: string;
  celularPersonal: string;
  emailPersonal: string;
  personal: Personal = 
    { IdPersonal: 0,  
      NomPersona:  "",  
      AppPersona: "", 
      ApmPersona: "",
      DniPersona: "", 
      TipoPersonal: null,
      Celular: {  IdMedioContactoPersonal : 0,
                  IdIGEDRegistro: 0,
                  Medio: "",
                  Descripcion: "",
                  TipoMedioContacto: {IdTipoMedioContacto: 1, CodTipoMedio: 1, DescTipoMedio: "Celular"}
                },
      Telefono: { IdMedioContactoPersonal : 0,
                  IdIGEDRegistro: 0,
                  Medio: "",
                  Descripcion: "",
                  TipoMedioContacto: {IdTipoMedioContacto: 2, CodTipoMedio: 2, DescTipoMedio: "Telefono"}
                },
      Email: { IdMedioContactoPersonal : 0,
                  IdIGEDRegistro: 0,
                  Medio: "",
                  Descripcion: "",
                  TipoMedioContacto: {IdTipoMedioContacto: 3, CodTipoMedio: 3, DescTipoMedio: "Email"}
                },  
      Iged : null       
    }

  tipoPersonalControl = new FormControl('', [Validators.required]);
  dniP = new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]);
  nombreP = new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]);
  apePatP = new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]);
  apeMatP = new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]);
  telefonoP = new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]);
  celularP = new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]);
  emailP = new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]);

  //Para la tabla
  @ViewChild("tablaPersonal") tablaPersonal;
  @ViewChild("objTipoPersonal") objTipoPersonal;
  
  //tiposPersonal: TipoPersonal[] = tiposPersonal;

  //Para la tabla
  public datosTabla: Personal[]=[];
     /* { IdPersonal: 0,  NomPersona:  "Ricardo",  AppPersona: "Izquierdo", ApmPersona: "Soran",
        DniPersona: '06874512', 
        TipoPersonal: { CodTipoPersonal: 2,
                        DescTipoPersonal: "Asistente",
                        IdTipoPersonal: 2
                    },
        Celular: { IdMedioContactoPersonal : 0,
                    IdIGEDRegistro: 0,
                    Medio: "945177589",
                    Descripcion: "",
                    TipoMedioContacto: {IdTipoMedioContacto: 0, CodTipoMedio: 0, DescTipoMedio: ""}
                  },
        Telefono: { IdMedioContactoPersonal : 0,
                    IdIGEDRegistro: 0,
                    Medio: "945177589",
                    Descripcion: "",
                    TipoMedioContacto: {IdTipoMedioContacto: 0, CodTipoMedio: 0, DescTipoMedio: ""}
                  },
        Email: { IdMedioContactoPersonal : 0,
                    IdIGEDRegistro: 0,
                    Medio: "945177589",
                    Descripcion: "",
                    TipoMedioContacto: {IdTipoMedioContacto: 0, CodTipoMedio: 0, DescTipoMedio: ""}
                  },  
        Iged : null       
        },
    ];*/

  //displayedColumns: string[] =['Medio', 'Descripcion'];
  columnsToDisplay: string[] =['Item','Cargo', 'DNI', 'NombreApellidos', 'Telefono','Celular', 'Email', 'Accion'];

  constructor() {
    //this.VerificarItemTipoPersonal();
   }

  ngOnInit(): void {
  }

  addItemTabla(){
    /*this.personal.NomPersona = "";
    this.personal.AppPersona = "";
    this.personal.ApmPersona = "";
    this.personal.TipoPersonal = null;
    this.personal.Celular.Descripcion = "";
    this.personal.Telefono.Descripcion = "";
    this.personal.Email.Descripcion = "";*/
    this.cont++;
    console.log("contador");
    console.log(this.cont);
    console.log("ver personal");
    console.log(this.tipoPersonalControl.value);

    let indiceItemTabla = this.datosTabla.findIndex(element => 
                                                          (element.TipoPersonal !=null 
                                                          && element.TipoPersonal!= undefined 
                                                          && element.TipoPersonal.CodTipoPersonal == this.tipoPersonalControl.value.CodTipoPersonal
                                                          )
                                                          );
    
    if(indiceItemTabla!= undefined && indiceItemTabla != null && indiceItemTabla != -1)
    {
      alert("Ya existe una persona asignada a ese cargo")
    }                                                      
    else{
        var itemPersonal: Personal ={
                        IdPersonal:0,  
                        DniPersona : this.dniP.value,
                        NomPersona : this.nombreP.value,
                        AppPersona : this.apePatP.value,
                        ApmPersona : this.apeMatP.value,
                        TipoPersonal : this.tipoPersonalControl.value,
                        Celular : {IdMedioContactoPersonal : 0,
                                                IdIGEDRegistro: 0,
                                                Medio: this.celularP.value,
                                                Descripcion: "",
                                                TipoMedioContacto: {IdTipoMedioContacto: 1, CodTipoMedio: 1, DescTipoMedio: "Celular"}
                                              },   
                        Telefono : {IdMedioContactoPersonal : 0,
                                                IdIGEDRegistro: 0,
                                                Medio: this.telefonoP.value,
                                                Descripcion: "",
                                                TipoMedioContacto: {IdTipoMedioContacto: 0, CodTipoMedio: 0, DescTipoMedio: "",}
                                              },                      
                        Email : {IdMedioContactoPersonal : 0,
                                              IdIGEDRegistro: 0,
                                              Medio: this.emailP.value,
                                              Descripcion: "",
                                              TipoMedioContacto: {IdTipoMedioContacto: 0, CodTipoMedio: 0, DescTipoMedio: ""}
                                            },
                        Iged : null               
                        }

        this.datosTabla.push(itemPersonal);
        console.log('datos de tabla despues de agregar, antes de renderizar');
        console.log(this.datosTabla);
        this.tablaPersonal.renderRows();
        //console.log('datos de tabla despues de agregar, despues de renderizar');
        //console.log(this.datosTabla);    
        this.retirarItemTipoPersonal(itemPersonal.TipoPersonal);
        this.limpiarValores();           
    }
  }

  deleteItemTabla(indice:number){     
    if (confirm("¿Desea quitarlo de la lista?")) {   
      let item = this.datosTabla[indice].TipoPersonal
      console.log(this.datosTabla[indice].TipoPersonal);
      this.datosTabla.splice(indice,1);
      this.tablaPersonal.renderRows();    
      this.AgregarItemTipoPersonal(item); 
    }     
  }

  limpiarValores(){    
    this.dniP.reset();
    this.nombreP.reset();
    this.apePatP.reset();
    this.apeMatP.reset();
    this.tipoPersonalControl.reset();
    this.celularP.reset();
    this.telefonoP.reset();
    this.emailP.reset();
  }

  cancel(){
    console.log("cancelar")
   }

   retirarItemTipoPersonal(tipoPersonal: TipoPersonal){
     //console.log(tiposPersonal);     
     //let i = this.listaTipoPersonal.indexOf(tipoPersonal);
     let indice = this.listaTipoPersonal.findIndex(element => element.CodTipoPersonal == tipoPersonal.CodTipoPersonal);
       console.log("indice:" + indice);

     console.log(indice);
      if (indice!= undefined && indice!= null )
        {
          this.listaTipoPersonal.splice(indice,1);          
        }
    }

   AgregarItemTipoPersonal(tipoPersonal: TipoPersonal){
    let indice = this.listaTipoPersonal.findIndex(element => element.CodTipoPersonal == tipoPersonal.CodTipoPersonal);
    console.log("indice agregar");
    console.log(indice);

    if (indice == undefined || indice== null || indice == -1)
        {
          //this.listaTipoPersonal.splice(1,0,tipoPersonal);
          this.listaTipoPersonal.push(tipoPersonal)
          //this.objTipoPersonal.render();
        }
   }

   VerificarItemTipoPersonal(){
     for(let item of this.datosTabla){
       this.retirarItemTipoPersonal(item.TipoPersonal);
       console.log("TipoPersonal");
       console.log(item.TipoPersonal);       
     }
   }

}