import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PersonalResponsableIgedComponent } from './personal-responsable-iged.component';

describe('PersonalResponsableIgedComponent', () => {
  let component: PersonalResponsableIgedComponent;
  let fixture: ComponentFixture<PersonalResponsableIgedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PersonalResponsableIgedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PersonalResponsableIgedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
