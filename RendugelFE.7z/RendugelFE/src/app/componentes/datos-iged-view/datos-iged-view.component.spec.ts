import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatosIgedViewComponent } from './datos-iged-view.component';

describe('DatosIgedViewComponent', () => {
  let component: DatosIgedViewComponent;
  let fixture: ComponentFixture<DatosIgedViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatosIgedViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatosIgedViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
