import { Component, OnInit, Input} from '@angular/core';
import {Region} from '../../interfaces/region';
import {Provincia} from '../../interfaces/provincia';
import {Distrito} from '../../interfaces/distrito';
import {OpcionesUbigeo} from '../../interfaces/opciones-ubigeo';


@Component({
  selector: 'app-datos-iged-view',
  templateUrl: './datos-iged-view.component.html',
  styleUrls: ['./datos-iged-view.component.scss']
})
export class DatosIgedViewComponent implements OnInit {

  dataOpcionesUbigeo : OpcionesUbigeo;

  @Input() nombreUgel: string;
  @Input() codigoUgel: string;
  @Input() region: Region;
  @Input() provincia: Provincia;
  @Input() distrito: Distrito;
  

  constructor() { 
    }
  ngOnInit(): void {     
  }
}
  