import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { GrillaJurisdiccionEnunciadosComponent } from './grilla-jurisdiccion-enunciados.component';

describe('GrillaJurisdiccionEnunciadosComponent', () => {
  let component: GrillaJurisdiccionEnunciadosComponent;
  let fixture: ComponentFixture<GrillaJurisdiccionEnunciadosComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ GrillaJurisdiccionEnunciadosComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(GrillaJurisdiccionEnunciadosComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
