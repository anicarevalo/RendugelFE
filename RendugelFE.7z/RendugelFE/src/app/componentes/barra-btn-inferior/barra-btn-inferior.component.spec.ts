import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BarraBtnInferiorComponent } from './barra-btn-inferior.component';

describe('BarraBtnInferiorComponent', () => {
  let component: BarraBtnInferiorComponent;
  let fixture: ComponentFixture<BarraBtnInferiorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BarraBtnInferiorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BarraBtnInferiorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
