import { Component, OnInit, Output, EventEmitter} from '@angular/core';

@Component({
  selector: 'app-barra-btn-inferior',
  templateUrl: './barra-btn-inferior.component.html',
  styleUrls: ['./barra-btn-inferior.component.scss']
})
export class BarraBtnInferiorComponent implements OnInit {
  @Output() cancelevent = new EventEmitter<string>();
  @Output() okevent = new EventEmitter<string>();

  constructor() { }

  ngOnInit(): void {
  }

  Aceptar(val:string):void{
    this.okevent.emit(val);
  }

  Cancelar(val:string):void{
    this.cancelevent.emit(val);
  }

}
