import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SeleccionBandejaComponent } from './seleccion-bandeja.component';

describe('SeleccionBandejaComponent', () => {
  let component: SeleccionBandejaComponent;
  let fixture: ComponentFixture<SeleccionBandejaComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SeleccionBandejaComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SeleccionBandejaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
