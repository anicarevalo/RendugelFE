import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import {TipoRegistro} from '../../interfaces/tipo-registro';
import {EstadoRegistro} from '../../interfaces/estado-registro';

export interface Seleccion{
  provisionales: boolean,
  suspendidos: boolean,
  cancelado: boolean,
  definitivo: boolean,
}

@Component({
  selector: 'app-seleccion-bandeja',
  templateUrl: './seleccion-bandeja.component.html',
  styleUrls: ['./seleccion-bandeja.component.scss']
})
export class SeleccionBandejaComponent implements OnInit {  

  seleccion : Seleccion = {
  provisionales:false,
  suspendidos:false,
  cancelado: false,
  definitivo: false
  };  
  @Output() SeleccionarBandejaEvent = new EventEmitter<Seleccion>();

  constructor() { }

  ngOnInit(): void {
  }

  onClickProvisional(){
    this.seleccion.provisionales = !this.seleccion.provisionales;
    this.SeleccionarBandejaEvent.emit(this.seleccion);
  };

  onClickDefinitivo(){
    this.seleccion.definitivo = !this.seleccion.definitivo
    this.SeleccionarBandejaEvent.emit(this.seleccion);
  };

  onClickSuspendido(){
    this.seleccion.suspendidos = !this.seleccion.suspendidos
    this.SeleccionarBandejaEvent.emit(this.seleccion);
  };

  onClickCancelado(){
    this.seleccion.cancelado = !this.seleccion.cancelado
    this.SeleccionarBandejaEvent.emit(this.seleccion);
  };


}
