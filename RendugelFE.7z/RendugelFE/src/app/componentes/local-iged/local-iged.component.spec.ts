import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { LocalIgedComponent } from './local-iged.component';

describe('LocalIgedComponent', () => {
  let component: LocalIgedComponent;
  let fixture: ComponentFixture<LocalIgedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ LocalIgedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(LocalIgedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
