import {Component, Inject, OnInit, Input, Output, ViewChild, EventEmitter} from '@angular/core';
import {FormControl, Validators, FormBuilder, FormGroup} from '@angular/forms';
import {TipoLocal} from '../../interfaces/tipo-local';
import {TipoPropiedad} from '../../interfaces/tipo-propiedad';
import {LocalIged} from '../../interfaces/local-iged'

@Component({
  selector: 'app-local-iged',
  templateUrl: './local-iged.component.html',
  styleUrls: ['./local-iged.component.scss']
})
export class LocalIgedComponent implements OnInit {

  // para los datos personal
  cont: number = 0;
  selectedTipoPropiedad: TipoPropiedad;
  selectedTipoLocal: TipoLocal;
  
  @Input() listaTipoPropiedad: TipoPropiedad[]; //tiposPersonal;  
  @Input() listaTipoLocal: TipoLocal[]; //tiposPersonal; 
  direccionLocal: string;

  tipoPropiedadControl = new FormControl('', [Validators.required]);
  tipoLocalControl = new FormControl('', [Validators.required]);
  direccionControl = new FormControl('', [Validators.required, Validators.minLength(3), Validators.maxLength(50)]);
  
  //Para la tabla
  @ViewChild("tablaLocal") tablaLocal;
  @ViewChild("objTipoPropiedad") objTipoPropiedad;
  @ViewChild("objTipoLocal") objTipoLocal;
  
  //tiposPersonal: TipoPersonal[] = tiposPersonal;

  //Para la tabla
  public datosTabla: LocalIged[]=[]; 
  //displayedColumns: string[] =['Medio', 'Descripcion'];
  columnsToDisplay: string[] =['Item','TipoLocal', 'Direccion', 'TipoPropiedad', 'Accion'];

  constructor() {
    //this.VerificarItemTipoPersonal();
   }

  ngOnInit(): void {
  }

  addItemTabla(){
    this.cont++;
    console.log("contador");
    console.log(this.cont);
    console.log("ver tipo propiedad");
    console.log(this.tipoPropiedadControl.value);
 
        var itemLocal: LocalIged ={
                        IdLocalIGED:0,  
                        DireccionLocal : this.direccionControl.value,
                        TipoLocal : this.tipoLocalControl.value,
                        TipoPropiedad : this.tipoPropiedadControl.value,
                        Iged : null                          
                        }

        this.datosTabla.push(itemLocal);

        console.log('datos de tabla despues de agregar, antes de renderizar');
        console.log(this.datosTabla);
        this.tablaLocal.renderRows();
        this.limpiarValores();         
  }

  deleteItemTabla(indice:number){     
    if (confirm("¿Desea quitarlo de la lista?")) {   
      this.datosTabla.splice(indice,1);
      this.tablaLocal.renderRows();    
    }     
  }

  limpiarValores(){    
    this.direccionControl.reset();
    this.tipoLocalControl.reset();
    this.tipoPropiedadControl.reset();
  }

  cancel(){
    console.log("cancelar")
   }

}
