import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SelectorOpcionesRegistroComponent } from './selector-opciones-registro.component';

describe('SelectorOpcionesRegistroComponent', () => {
  let component: SelectorOpcionesRegistroComponent;
  let fixture: ComponentFixture<SelectorOpcionesRegistroComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SelectorOpcionesRegistroComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SelectorOpcionesRegistroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
