import { Component, OnInit, Output, Input, EventEmitter, ViewChild } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import {SeleccionOpcionesRegistro} from '../../interfaces/seleccion-Opciones-Registro';
import {OpcionesRegistroRequest} from '../../interfaces/opciones-registro-request';
import {Naturaleza} from '../../interfaces/naturaleza';
import {EventoRegistral} from '../../interfaces/evento-registral';
import {Tipoiged} from '../../interfaces/tipo-Iged';
import {TipoRegistro} from '../../interfaces/tipo-registro';
import {Iged} from '../../interfaces/iged';
import {ConfiguracionOpcionesRegistro} from '../../interfaces/configuracion-opciones-registro';
import {configuracion} from '../../interfaces/configuracion';
import {DataInternaService} from '../../servicios/data-interna.service';
import {ComunService} from '../../servicios/comun.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-selector-opciones-registro',
  templateUrl: './selector-opciones-registro.component.html',
  styleUrls: ['./selector-opciones-registro.component.scss']
})
export class SelectorOpcionesRegistroComponent implements OnInit {
  
    @Input() listaDRE: Iged[];
    @Input() listaUGEL: Iged[];
    @Input() listaTipoIged: Tipoiged[];
    @Input() listaNaturaleza: Naturaleza[];
    @Input() listaEventoRegistral: EventoRegistral[];
    @Input() listaTipoRegistro: TipoRegistro[];
    //@Input() configuracionOpcionesRegistro: ConfiguracionOpcionesRegistro;

    @Input() configDre: configuracion;
    @Input() configEventoRegistral: configuracion;
    @Input() configNaturaleza: configuracion;
    @Input() configTipoRegistro: configuracion;
    @Input() configTipoiged: configuracion;
    @Input() configUgel: configuracion;

    @ViewChild("optionNaturaleza") optionNaturaleza;
    @ViewChild("texto") texto;

    listaEventoPorNaturaleza: EventoRegistral[];
    listaUgelPorDre: Iged[];

  selectedTipoIged : Tipoiged;
  selectedNaturaleza : Naturaleza;
  selectedDre : Iged;
  selectedEventoRegistral : EventoRegistral;
  selectedUgel : Iged;
  selectedTipoRegistro : TipoRegistro;

  selectFormTipoIged = new FormControl('', Validators.required);
  selectFormNaturaleza = new FormControl('', Validators.required);
  selectFormDre = new FormControl('', Validators.required);
  selectFormEvento = new FormControl('', Validators.required);
  selectFormUgel = new FormControl('', Validators.required);
  selectFormTipoRegistro = new FormControl('', Validators.required);

  //seleccionOpcionesRegistro : SeleccionOpcionesRegistro;
  valPrueba: string;

  constructor(private dataService: DataInternaService,               
              private router: Router,
              private comunService: ComunService) {       
  }

  ngOnInit(): void {
    /*
    if(this.configTipoiged.default!=-1){
      this.selectedTipoIged = this.configTipoiged.default;
    }

    if(this.configTipoRegistro.default!=-1){
      this.selectedTipoRegistro = this.configTipoRegistro.default;
    }

    if(this.configNaturaleza.default!=-1){
      this.selectedNaturaleza = this.configNaturaleza.default;
    }

    if(this.configEventoRegistral.default!=-1){
      this.selectedEventoRegistral = this.configEventoRegistral.default;
    }*/
  }

  onSelectedNaturaleza(naturaleza: Naturaleza){
    console.log(naturaleza);
    //this.selectedNaturaleza = naturaleza;
    console.log(this.texto);
    this.filtrarEventoRegistral(naturaleza);
    if ((naturaleza.CodNaturaleza != undefined && naturaleza.CodNaturaleza!=1)
        && (this.selectedDre != undefined && this.selectedDre.CodIged!= null))
    {
      console.log("solicitar lista de ugel");
      this.ObtenerListaUgelesPorDre(this.selectedDre.CodIged);
      this.configUgel.visible=true;
    } 
    else{
      this.listaUgelPorDre=[];
      this.configUgel.visible=false;
    }
    
  }

  onSelectedDre(dre: Iged){
    //console.log(dre)
    if ((this.selectedNaturaleza != undefined && this.selectedNaturaleza.CodNaturaleza!=1)
        && (dre.CodIged != undefined && dre.CodIged!= null))
    {
      console.log("solicitar lista de ugel");
      this.ObtenerListaUgelesPorDre(dre.CodIged);
      this.configUgel.visible=true;
    }
    else{
      this.listaUgelPorDre=[];
      this.configUgel.visible=false;
    }   
  }

  private filtrarEventoRegistral(naturaleza: Naturaleza): EventoRegistral[] {
    this.listaEventoPorNaturaleza= this.listaEventoRegistral.filter(option => option.Naturaleza.CodNaturaleza==naturaleza.CodNaturaleza);
    return this.listaEventoPorNaturaleza;
  }

  //private filtrarUgel(dre: Iged): Iged[] {
    //this.listaUgelPorDre= this.listaUGEL.filter(option => option.CodIged==dre.CodIged);
  //  return this.listaUgelPorDre;
  //}

  ObtenerListaUgelesPorDre(codDre:string):void{    
    this.comunService.ObtenerListaUgelesPorDre(codDre)
    .subscribe(res => this.listaUgelPorDre = res);
  }

  obtenerOpcionesRegistro(val:string):void{
      if (val="OK")
      {
        this.dataService.detalleRegistroRequest = null;
        this.dataService.registroBandejaRequest = null;

        if(this.selectedTipoRegistro.CodTipoRegistro==1){
          //this.valPrueba="Ok prueba"
          const seleccionOpcionesRegistro: SeleccionOpcionesRegistro = { 
                                  Dre : this.selectedDre,
                                  Tipoiged:this.selectedTipoIged,
                                  EventoRegistral: this.selectedEventoRegistral, 
                                  Naturaleza:  this.selectedNaturaleza,
                                  TipoRegistro: this.selectedTipoRegistro, 
                                  Ugel: null}
           
          this.dataService.opcionesRegistro = seleccionOpcionesRegistro;

        this.router.navigate(['/NuevoRegistroProvisional']);
      }
      else{
        if(this.selectedTipoRegistro.CodTipoRegistro==2) 
        {           
          switch(this.selectedNaturaleza.CodNaturaleza) { 
            case 2: { 
              const seleccionOpcionesRegistro: SeleccionOpcionesRegistro = { 
                Dre : this.selectedDre,
                Tipoiged:this.selectedTipoIged,
                EventoRegistral: null, 
                Naturaleza:  this.selectedNaturaleza,
                TipoRegistro: this.selectedTipoRegistro, 
                Ugel: this.selectedUgel}
    
              this.dataService.opcionesRegistro = seleccionOpcionesRegistro;
              this.dataService.eventosRegistrales = this.listaEventoPorNaturaleza;
              this.router.navigate(['/ModificacionSigniticativa']);
              break; 
            } 
            case 3: {
              const seleccionOpcionesRegistro: SeleccionOpcionesRegistro = { 
                Dre : this.selectedDre,
                Tipoiged:this.selectedTipoIged,
                EventoRegistral: this.listaEventoPorNaturaleza[0],
                Naturaleza:  this.selectedNaturaleza,
                TipoRegistro: this.selectedTipoRegistro, 
                Ugel: this.selectedUgel}
    
              this.dataService.opcionesRegistro = seleccionOpcionesRegistro;
              this.dataService.eventosRegistrales = this.listaEventoPorNaturaleza;

              this.router.navigate(['/ModificacionComplementaria']); 
               break; 
            } 
            case 4: { 
              const seleccionOpcionesRegistro: SeleccionOpcionesRegistro = { 
                Dre : this.selectedDre,
                Tipoiged:this.selectedTipoIged,
                EventoRegistral: this.listaEventoPorNaturaleza[0], //this.selectedEventoRegistral, 
                Naturaleza:  this.selectedNaturaleza,
                TipoRegistro: this.selectedTipoRegistro, 
                Ugel: this.selectedUgel}
    
              this.dataService.opcionesRegistro = seleccionOpcionesRegistro;
              this.dataService.eventosRegistrales = this.listaEventoPorNaturaleza;
              this.router.navigate(['/CierreDefinitivo']);
              break;  
           }
         }          
        }      
      } 
    }
  }
}
