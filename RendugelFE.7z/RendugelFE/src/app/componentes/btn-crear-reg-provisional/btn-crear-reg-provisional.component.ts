import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-btn-crear-reg-provisional',
  templateUrl: './btn-crear-reg-provisional.component.html',
  styleUrls: ['./btn-crear-reg-provisional.component.scss']
})
export class BtnCrearRegProvisionalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
