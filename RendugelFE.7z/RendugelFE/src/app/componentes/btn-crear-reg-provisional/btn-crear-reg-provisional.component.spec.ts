import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BtnCrearRegProvisionalComponent } from './btn-crear-reg-provisional.component';

describe('BtnCrearRegProvisionalComponent', () => {
  let component: BtnCrearRegProvisionalComponent;
  let fixture: ComponentFixture<BtnCrearRegProvisionalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BtnCrearRegProvisionalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BtnCrearRegProvisionalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
