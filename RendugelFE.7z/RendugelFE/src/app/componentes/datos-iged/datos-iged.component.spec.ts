import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DatosIgedComponent } from './datos-iged.component';

describe('DatosIgedComponent', () => {
  let component: DatosIgedComponent;
  let fixture: ComponentFixture<DatosIgedComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DatosIgedComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DatosIgedComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
