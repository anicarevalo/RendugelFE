import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CabeceraRegistroComponent } from './cabecera-registro.component';

describe('CabeceraRegistroComponent', () => {
  let component: CabeceraRegistroComponent;
  let fixture: ComponentFixture<CabeceraRegistroComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CabeceraRegistroComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CabeceraRegistroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
