import { Component, OnInit, Input, Output } from '@angular/core';
import {Tipoiged} from '../../interfaces/tipo-Iged';
import {Iged} from '../../interfaces/iged';
import {Naturaleza} from '../../interfaces/naturaleza';
import {EventoRegistral} from '../../interfaces/evento-registral';
import {TipoRegistro} from '../../interfaces/tipo-registro';
import {SeleccionOpcionesRegistro} from '../../interfaces/seleccion-Opciones-Registro';

@Component({
  selector: 'app-cabecera-registro',
  templateUrl: './cabecera-registro.component.html',
  styleUrls: ['./cabecera-registro.component.scss']
})
export class CabeceraRegistroComponent implements OnInit {

  @Input() seleccionOpcionesRegistro: SeleccionOpcionesRegistro;

  constructor() { }

  ngOnInit(): void {
  }

}
