import { ComponentFixture, TestBed } from '@angular/core/testing';

import { GrillaJurisdiccionOrigenComponent } from './grilla-jurisdiccion-origen.component';

describe('GrillaJurisdiccionOrigenComponent', () => {
  let component: GrillaJurisdiccionOrigenComponent;
  let fixture: ComponentFixture<GrillaJurisdiccionOrigenComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ GrillaJurisdiccionOrigenComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(GrillaJurisdiccionOrigenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
