import { Component, OnInit, Input, Output, EventEmitter, ViewChild } from '@angular/core';
import {MatDialog, MatDialogRef, MAT_DIALOG_DATA, MatDialogConfig} from '@angular/material/dialog';
import {ModalComprendeComponent} from '../modal/modal-comprende/modal-comprende.component';
import {ModalExcluyeComponent} from '../modal/modal-excluye/modal-excluye.component';
import {ModalIncluyeComponent} from '../modal/modal-incluye/modal-incluye.component';
import {DataInternaService} from '../../servicios/data-interna.service';
import {Iged} from '../../interfaces/iged';
import {Jurisdiccion} from '../../interfaces/jurisdiccion';
import {Region} from '../../interfaces/region';
import {Provincia} from '../../interfaces/provincia';
import {Distrito} from '../../interfaces/distrito';
import {EventoRegistral} from '../../interfaces/evento-registral';
import {CentroPoblado} from '../../interfaces/centro-poblado';
//import {RegistroDefinitivoRequest} from '../../interfaces/registro-definitivo-request';
import {IgedRegistroDefinitivoDetalle} from '../../interfaces/iged-registro-definitivo-detalle';

export interface DatosModel{
  region: Region,
  listaProvincia: Provincia[],
  listaDistrito:  Distrito[],
  jurisdiccionUgel: Jurisdiccion
}

@Component({
  selector: 'app-grilla-jurisdiccion-origen',
  templateUrl: './grilla-jurisdiccion-origen.component.html',
  styleUrls: ['./grilla-jurisdiccion-origen.component.scss']
})
export class GrillaJurisdiccionOrigenComponent implements OnInit {
  @Input() dataSource: Jurisdiccion[]; //EntidadJurisdiccion[];
  @Input() displayedColumns: string[];
  @Input() ugel: Iged;
  @Input() visible: boolean = true;

  @Input() region: Region;
  @Input() listaDistrito : Distrito[];
  @Input() listaProvincias : Provincia[];

  @Output() eliminarGrilla = new EventEmitter<Iged>();
  @ViewChild("tablaJurisdiccionOrigen") tablaJurisdiccionOrigen;

  jurisdiccionUgel: Jurisdiccion;
  datosModel: DatosModel;  
  datosModelExcluye: DatosModel;  
  datosModelIncluye: DatosModel;  

  definitivoDetalle: IgedRegistroDefinitivoDetalle[]=[];
  //registroDefinitivoRequest:RegistroDefinitivoRequest;

  //ELEMENT_DATA: EntidadJurisdiccion[] = DATA_JURISDICCION;
  //displayedColumns:  string[] = cdisplayedColumns;
  //dataSource: any;

  constructor(private dataInternaService: DataInternaService, public dialog: MatDialog) {     
    this.visible= true;   
    
    //console.log("ver dataSource de grillas jurisdicción");
    //console.log(this.dataSource)
    console.log("ver lista de distritos");
    console.log(this.listaDistrito);
    console.log("ver la lista de provincia");
    console.log(this.listaProvincias);
  }
  ngOnInit(): void {    
  }

  openDialogIncluye(val:string): void {
    if (val="OK")
    {
      this.jurisdiccionUgel = 
    {
      IdJurisdiccion: 0,
      Ubigeo: null,
      CodTerminoCantidad: 0,
      CodTerminoPertenencia: 0,
      TerminoCantidadJurisdiccion: null,
      TerminoPertenenciaJurisdiccion: null,
      nivel: 0, 
      terminoPertenencia: "",
      enCCPP: "",
      enDistrito: "",
      enProvincia: "",
      enRegion: "",
      enunciado: ""
    };

      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose= true;
      dialogConfig.autoFocus = true;
      dialogConfig.hasBackdrop =true;
      dialogConfig.data = this.datosModelIncluye =
                      { region: this.region,
                        listaDistrito:this.listaDistrito, 
                        listaProvincia:this.listaProvincias,
                        jurisdiccionUgel:this.jurisdiccionUgel}

      const dialogRef = this.dialog.open(ModalIncluyeComponent, dialogConfig);    

      dialogRef.afterClosed().subscribe(
        res => {         
          if (res!= undefined){
            console.log("res.jurisdiccionUgel");
            console.log(res.jurisdiccionUgel);
            this.addItemTabla(res.jurisdiccionUgel, 3);
          }            
        });
      //this.datosTabla.push(this.medioContacto)
    }
  };
  openDialogExcluye(val:string): void {
    if (val="OK")
    {
      this.jurisdiccionUgel = 
    {
      IdJurisdiccion: 0,
      Ubigeo: null,
      CodTerminoCantidad: 0,
      CodTerminoPertenencia: 0,
      TerminoCantidadJurisdiccion: null,
      TerminoPertenenciaJurisdiccion: null,
      nivel: 0, 
      terminoPertenencia: "",
      enCCPP: "",
      enDistrito: "",
      enProvincia: "",
      enRegion: "",
      enunciado: ""
    };

      const dialogConfig = new MatDialogConfig();
      dialogConfig.disableClose= true;
      dialogConfig.autoFocus = true;
      dialogConfig.hasBackdrop =true;
      dialogConfig.data = this.datosModelExcluye =
                      { region: this.region,
                        listaDistrito:this.listaDistrito, 
                        listaProvincia:this.listaProvincias,
                        jurisdiccionUgel:this.jurisdiccionUgel}

      const dialogRef = this.dialog.open(ModalExcluyeComponent, dialogConfig);    

      dialogRef.afterClosed().subscribe(
        res => {         
          if (res!= undefined){
            console.log("res.jurisdiccionUgel");
            console.log(res.jurisdiccionUgel);
            this.addItemTabla(res.jurisdiccionUgel, 3);
          }            
        });
      //this.datosTabla.push(this.medioContacto)
    }
  };

  openDialogComprende(val:string):void{  
      if (val="OK")
      {
        this.jurisdiccionUgel = 
      {
        IdJurisdiccion: 0,
        Ubigeo: null,
        CodTerminoCantidad: 0,
        CodTerminoPertenencia: 0,
        TerminoCantidadJurisdiccion: null,
        TerminoPertenenciaJurisdiccion: null,
        nivel: 0, 
        terminoPertenencia: "",
        enCCPP: "",
        enDistrito: "",
        enProvincia: "",
        enRegion: "",
        enunciado: ""
      };

        const dialogConfig = new MatDialogConfig();
        dialogConfig.disableClose= true;
        dialogConfig.autoFocus = true;
        dialogConfig.hasBackdrop =true;
        dialogConfig.data = this.datosModel =
                        { region: this.region,
                          listaDistrito:this.listaDistrito, 
                          listaProvincia:this.listaProvincias,
                          jurisdiccionUgel:this.jurisdiccionUgel}

        const dialogRef = this.dialog.open(ModalComprendeComponent, dialogConfig);    

        dialogRef.afterClosed().subscribe(
          res => {         
            if (res!= undefined){
              console.log("res.jurisdiccionUgel");
              console.log(res.jurisdiccionUgel);
              this.addItemTabla(res.jurisdiccionUgel, 1);
            }            
          });
        //this.datosTabla.push(this.medioContacto)
      }
    }
    
  addItemTabla(item:Jurisdiccion, codPertenencia: number){
      console.log("item en additemtabla")
      console.log(item);
      console.log("this.dataSource")
      console.log(this.dataSource )
      if (this.dataSource != undefined){
        this.dataSource.push(item);
        this.tablaJurisdiccionOrigen.renderRows();
      } else {
        const _dataSource: Jurisdiccion[] =[];
        this.dataSource = _dataSource;
        this.dataSource.push(item);
        this.tablaJurisdiccionOrigen.renderRows();
        console.log("this.dataSource")
        console.log(this.dataSource )
      }
            
     /*const _eventoRegistral: EventoRegistral= {
        IdEventoRegistral: 1,
        CodEvento: 1,
        DescEvento: "Creacion",
        Naturaleza: {
          IdNaturaleza:1,
          CodNaturaleza: 1,
          DescNaturaleza: "Creacion"
        }
      };*/

      //this.dataInternaService.guardarTempDefinitivoDetalle(this.ugel,this.dataSource, _eventoRegistral, true )       
    }

  deleteItemTabla(indice:number){     
      if (confirm("¿Desea quitarlo de la lista?")) {   
        this.dataSource.splice(indice,1);
        this.tablaJurisdiccionOrigen.renderRows();

        /*const _eventoRegistral: EventoRegistral= {
          IdEventoRegistral: 1,
          CodEvento: 1,
          DescEvento: "Creacion",
          Naturaleza: {
              IdNaturaleza:1,
              CodNaturaleza: 1,
              DescNaturaleza: "Creacion"
            }
        }; 
        console.log("Ver si data source es nullo o indefinido");
        console.log(this.dataSource);*/
        //this.dataInternaService.guardarTempDefinitivoDetalle(this.ugel,this.dataSource, _eventoRegistral, true ) 
      }
    }

  
  eliminar(ugel){
    this.visible=false;
    this.eliminarGrilla.emit(ugel);
  }

}

