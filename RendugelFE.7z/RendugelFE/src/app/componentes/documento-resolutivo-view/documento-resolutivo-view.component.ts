import {Component, OnInit, Input } from '@angular/core';
import {Documento} from '../../interfaces/documento';
import {ComunService} from '../../servicios/comun.service';

@Component({
  selector: 'app-documento-resolutivo-view',
  templateUrl: './documento-resolutivo-view.component.html',
  styleUrls: ['./documento-resolutivo-view.component.scss']
})
export class DocumentoResolutivoViewComponent implements OnInit {
  @Input() documentoResolutivo: Documento;
  @Input() titulo: string;
  constructor(private comunService: ComunService) { 
  };
  ngOnInit(): void {
  };

  downloadResolucion(){
    //const documento: Documento= null;
    this.comunService.getPDF(this.documentoResolutivo)
      .subscribe((data) => {
                let blob = new Blob([data], {type: 'application/pdf'});
              
                var downloadURL = window.URL.createObjectURL(blob);
                window.open(downloadURL);    

                setTimeout(function () {
                  // For Firefox it is necessary to delay revoking the ObjectURL
                  window.URL.revokeObjectURL(downloadURL);                  
              }, 100);
    });
  }

  

}
