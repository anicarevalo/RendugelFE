import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { DocumentoResolutivoViewComponent } from './documento-resolutivo-view.component';

describe('DocumentoResolutivoViewComponent', () => {
  let component: DocumentoResolutivoViewComponent;
  let fixture: ComponentFixture<DocumentoResolutivoViewComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ DocumentoResolutivoViewComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(DocumentoResolutivoViewComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
