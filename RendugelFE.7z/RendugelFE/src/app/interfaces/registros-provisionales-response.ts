import {RegistroBandeja} from './registro-bandeja'
export interface RegistrosProvisionalesResponse {
    ListaRegistroBandeja: RegistroBandeja[];
  }