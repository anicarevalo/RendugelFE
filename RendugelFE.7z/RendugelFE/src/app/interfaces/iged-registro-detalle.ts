import {Ugel} from './ugel';
import {Ubigeo} from './ubigeo';
import {Region} from './region';
import {Provincia} from './provincia';
import {Distrito} from './distrito';
import {Iged} from './iged';
import {Tipoiged } from './tipo-Iged';
import {EventoRegistral} from './evento-registral';

export interface IgedRegistroDetalle {
    IdIgedRegistro: number;
    EsOrigen: boolean;  
    NomIged: string;
    Ugel: Ugel; 
    Ubigeo: Ubigeo;  
    region: Region;
    provincia: Provincia;
    distrito: Distrito;
    TipoIged: Tipoiged;
    Dre:Iged;
    EventoRegistral: EventoRegistral
  }  