import {configuracion} from './configuracion';

export interface ConfiguracionOpcionesRegistro {
    configDre: configuracion;     
    configEventoRegistral: configuracion;
    configNaturaleza: configuracion;
    configTipoiged: configuracion;
    configTipoRegistro: configuracion;
    configUgel: configuracion;
  }