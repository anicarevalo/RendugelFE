import {Naturaleza} from './naturaleza';
import {EventoRegistral} from './evento-registral';
import {Tipoiged} from './tipo-Iged';
import {TipoRegistro} from './tipo-registro';
import {Iged} from './iged';
export interface EntidadOpcionesRegistro {
    ListaDRE: Iged[];     
    ListaEventoRegistral: EventoRegistral[];
    ListaNaturaleza: Naturaleza[];
    ListaTipoIged: Tipoiged[];
    ListaTipoRegistro: TipoRegistro[];
    //ListaUGEL: Iged[];
  }