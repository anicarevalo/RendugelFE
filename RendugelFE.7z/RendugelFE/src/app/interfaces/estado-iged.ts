export interface EstadoIged {
    IdEstadoIged: number;
    DescEstadoIged: string;
    CodEstadoIged: number;  
  }