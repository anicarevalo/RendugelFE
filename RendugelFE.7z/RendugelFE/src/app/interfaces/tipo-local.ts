export interface TipoLocal {
    CodTipoLocal: number;
    DescTipoLocal: string;
    IdTipoLocal: number;   
  }