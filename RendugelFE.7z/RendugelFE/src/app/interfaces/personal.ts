import {TipoPersonal} from './tipo-personal';
import {Iged} from './iged';
import {PersonalMedioContacto} from './personal-medio-contacto';
export interface Personal {
    IdPersonal: number;
    NomPersona: string;
    AppPersona: string;
    ApmPersona: string;
    DniPersona: string;
    TipoPersonal: TipoPersonal;
    Celular: PersonalMedioContacto;
    Telefono: PersonalMedioContacto;
    Email: PersonalMedioContacto;
    Iged: Iged
  }