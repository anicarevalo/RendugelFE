export interface TipoRegistro {
    CodTipoRegistro: number;
    DescTipoRegistro: string;
    IdTipoRegistro: number;   
  }