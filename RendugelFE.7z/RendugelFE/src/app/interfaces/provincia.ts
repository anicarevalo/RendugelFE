import {Region} from './region';
export interface Provincia {
    IdUbigeo: number;
    CodUbigeo: string;
    Nombre: string;
    Region: Region
  }