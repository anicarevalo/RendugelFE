export interface Tipoiged {
    CodTipoIged: number;
    DescTipoIged: string;
    IdTipoIged: number;
  }