export interface TerminoPertenenciaJurisdiccion {
    IdTerminoPertenencia: number;
    CodTerminoPertenencia: number;
    DescTerminoPertenencia: string;
  }