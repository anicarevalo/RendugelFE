import {Region} from './region';
import {Provincia} from './provincia';
import {Distrito} from './distrito';
export interface OpcionesUbigeo {
    Region : Region;
    ListaProvincias: Provincia[];
    ListaDistrito: Distrito[];
  }