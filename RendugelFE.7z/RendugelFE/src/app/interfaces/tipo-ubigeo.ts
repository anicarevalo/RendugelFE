export interface TipoUbigeo {
    CodTipoUbigeo: number;
    DescTipoUbigeo: string;
    IdTipoUbigeo: number;   
  }
