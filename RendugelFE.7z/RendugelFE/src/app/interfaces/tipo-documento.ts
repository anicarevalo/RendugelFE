export interface TipoDocumento {
    IdTipoDoc: number;
    CodTipoDoc: number;
    DescTipoDoc: string;
  }