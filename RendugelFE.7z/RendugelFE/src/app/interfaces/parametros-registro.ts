import {Naturaleza} from './naturaleza';
import {EventoRegistral} from './evento-registral';
import {Tipoiged} from './tipo-Iged';
import {TipoRegistro} from './tipo-registro';
import {Iged} from './iged';
export interface ParametrosRegistro {
    dre: Iged;     
    eventoRegistral: EventoRegistral;
    tipoIged: Tipoiged;
    tipoRegistro: TipoRegistro;
    ugel: Iged;
  }