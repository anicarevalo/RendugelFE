import {PliegoUnidadEjecutora} from './pliego-unidad-ejecutora';
export interface UnidadEjecutora {
    IdUnidadEjecutora: number;
    CodUnidadEjecutora: string;
    DescUnidadEjecutora: string;
    PliegoUnidadEjecutora: PliegoUnidadEjecutora;
  }