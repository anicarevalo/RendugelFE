export interface ResponseService {
    ResultValid: boolean;
    MensajePrincipal: string;
    Mensajes: string[];
    idRegistro: number;
    Llave: string;   
  }