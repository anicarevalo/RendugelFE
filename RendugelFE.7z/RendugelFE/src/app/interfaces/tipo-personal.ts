export interface TipoPersonal {
    CodTipoPersonal: number;
    DescTipoPersonal: string;
    IdTipoPersonal: number;   
  }