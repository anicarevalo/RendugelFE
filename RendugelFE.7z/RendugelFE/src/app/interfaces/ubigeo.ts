export interface Ubigeo {
    IdUbigeo: number;
    CodUbigeo: string;
    Nombre: string;
    IdTipoUbigeo: number;    
    CodTipoUbigeo: number;
  }