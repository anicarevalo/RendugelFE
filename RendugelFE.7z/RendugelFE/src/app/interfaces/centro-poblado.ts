import {Distrito} from './distrito';
export interface CentroPoblado {
    IdUbigeo: number;
    CodUbigeo: string;
    Nombre: string;
    Distrito: Distrito 
  }