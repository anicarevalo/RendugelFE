import {Jurisdiccion} from './jurisdiccion';
//import {Ugel} from './ugel';
import {Iged} from './iged'

export interface IgedJurisdiccionResponse {
    //Ugel: Ugel;
    Ugel: Iged;
    JurisdiccionUgel: Jurisdiccion[];
  }