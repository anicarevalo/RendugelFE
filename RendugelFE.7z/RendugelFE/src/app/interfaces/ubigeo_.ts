import {TipoUbigeo} from './tipo-ubigeo';
export interface Ubigeo_ {
    IdUbigeo: number;
    CodUbigeo: string;
    Nombre: string;
    TipoUbigeo: TipoUbigeo;
    CodRegion: string;    
    NomRegion: string;
    CodProvincia: string;    
    NomProvincia: string;
    CodDistrito: string;    
    NomDistrito: string;
    CodCcpp: string;    
    NomCcpp: string;
  }