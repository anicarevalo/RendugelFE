export interface ItemBandejaRegistros {
    item: string;
    codRegion: string;
    region: string;
    estado: string;
    fechaRegistro: string;
    fechaActualizacion: string;
    fechaSuspension: string;
    fechaCancelacion: string;
    fechaVencimiento: string;
    docResolutivo: string;
    fechaDocumento: string;
    fechaPublicacion: string;
    acciones: string;
  }

  