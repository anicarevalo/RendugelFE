export interface TipoMedioContacto {
    IdTipoMedioContacto: number;
    CodTipo: number;
    DescTipo: string;
    icono: string;
    labelIconbtn: string;
    labelMedio: string;
  }