import {Ubigeo_} from './ubigeo_';
import {TerminoCantidadJurisdiccion} from './termino-cantidad-jurisdiccion';
import {TerminoPertenenciaJurisdiccion} from './termino-pertenencia-jurisdiccion';
export interface Jurisdiccion {
    IdJurisdiccion: number;
    Ubigeo: Ubigeo_;
    CodTerminoCantidad: number;
    CodTerminoPertenencia: number;
    TerminoCantidadJurisdiccion: TerminoCantidadJurisdiccion;
    TerminoPertenenciaJurisdiccion: TerminoPertenenciaJurisdiccion;
    nivel: number;  
    terminoPertenencia: string;
    enCCPP: string;
    enDistrito: string;
    enProvincia: string;
    enRegion: string;
    enunciado: string;
  }