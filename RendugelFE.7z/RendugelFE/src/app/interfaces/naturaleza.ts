export interface Naturaleza {
    CodNaturaleza: number;
    DescNaturaleza: string;
    IdNaturaleza: number;  
  }