export interface Iged {
    CodIged: string;
    CodTipoIged: number;
    DescTipoIged: string;
    IdIged: number;
    IdTipoIged: number;
    NomIged: string;  
  }