//import {TipoMedioContacto} from './tipo-medio-contacto'
import {TipoMedioContactoB} from './tipo-medio-contacto-b'
import {Iged} from './iged'

export interface PersonalMedioContacto {
    IdMedioContactoPersonal: number;  
    IdIGEDRegistro: number;  
    Medio: string;
    Descripcion: string; 
    TipoMedioContacto: TipoMedioContactoB;
  }