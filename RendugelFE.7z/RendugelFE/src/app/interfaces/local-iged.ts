import {TipoLocal} from './tipo-local';
import {TipoPropiedad} from './tipo-propiedad';
import {Iged} from './iged';
export interface LocalIged {
    IdLocalIGED: number;    
    DireccionLocal: string;
    TipoLocal: TipoLocal;
    TipoPropiedad: TipoPropiedad;
    Iged: Iged;
  }