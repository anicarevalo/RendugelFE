export interface TipoPropiedad {
    CodTipoPropiedad: number;
    DescTipoPropiedad: string;
    IdTipoPropiedad: number;   
  }