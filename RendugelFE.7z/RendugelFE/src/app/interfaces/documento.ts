import {TipoDocumento} from './tipo-documento';
import {ClasificacionDocumento} from './clasificacion-documento';

export interface Documento {
    IdDocumento: number;
    NroDocumento: number;
    NombreArchivo: string;
    FechaEmision: Date;
    FechaPublicacion: Date;
    Temporal: boolean;
    Ruta: string;
    ClasificacionDocumento: ClasificacionDocumento;
    TipoDocumento: TipoDocumento
  }