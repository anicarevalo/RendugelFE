export interface configuracion {
    visible: boolean;
    habilitado: boolean;
    requerido: boolean;
    default: any;
  }