import {Provincia} from './provincia';
export interface Distrito {
    IdUbigeo: number;
    CodUbigeo: string;
    Nombre: string;
    Provincia: Provincia
  }