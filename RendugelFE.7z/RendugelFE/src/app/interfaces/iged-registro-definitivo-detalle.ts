import {Ugel} from './ugel';
import {Ubigeo} from './ubigeo';
import {Region} from './region';
import {Provincia} from './provincia';
import {Distrito} from './distrito';
import {Iged} from './iged';
import {Tipoiged } from './tipo-Iged';
import {EventoRegistral} from './evento-registral';
import { Jurisdiccion } from './jurisdiccion';

export interface IgedRegistroDefinitivoDetalle {
    IdIgedRegistro: number;
    EsOrigen: boolean;
    EventoRegistral: EventoRegistral;
    Ugel: Iged;
    JurisdiccionIged: Jurisdiccion[];
  }  