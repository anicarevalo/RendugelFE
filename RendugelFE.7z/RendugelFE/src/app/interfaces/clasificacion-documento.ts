export interface ClasificacionDocumento {
    IdClasificacionDoc: number;
    CodClasificacionDoc: number;
    DescClasificacionDoc: string
  }