import {Naturaleza} from './naturaleza'

export interface EventoRegistral {
    CodEvento: number;
    DescEvento: string;
    IdEventoRegistral: number;  
    Naturaleza: Naturaleza;
  }