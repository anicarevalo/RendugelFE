export interface EstadoRegistro {
    IdEstadoRegistro: number;
    DescEstadoRegistro: string;
    CodEstadoRegistro: number;  
  }