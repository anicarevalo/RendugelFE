export interface Acciones {
    Editar: boolean;
    Suspender: boolean;
    Cancelar: boolean;
    PasarADefenitivo: boolean 
  }