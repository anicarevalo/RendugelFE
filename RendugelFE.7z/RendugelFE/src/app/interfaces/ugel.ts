import {Tipoiged} from './tipo-Iged';
import {EstadoIged} from './estado-iged';
export interface Ugel {
    CodIged: string;
    IdIged: number;
    NomIged: string;
    TipoIged: Tipoiged;
    EstadoIged: EstadoIged;
  }