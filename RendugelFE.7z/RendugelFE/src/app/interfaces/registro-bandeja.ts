
import {TipoRegistro} from './tipo-registro';
import {EstadoRegistro} from './estado-registro';
import {Documento} from './documento';
import {IgedRegistroDetalle} from './iged-registro-detalle';
import {Acciones} from './acciones';
import {Ugel} from './ugel';

/*const x: IgedRegistroDetalle = {IdIgedRegistro:0,
                                EsOrigen: false,
                                NomIged: "",
                                Ugel: null,
                                Ubigeo: null,
                                region: null,
                                provincia: null,
                                distrito: null,
                                TipoIged: null,
                                Dre: null,
                                EventoRegistral: null }*/

export interface RegistroBandeja {
    IdRegistro: number;
    CodRegistro: string;
    Estado: string;
    CodTipoRegistro: number;
    UsuCreacion: string;
    EstadoRegistro: EstadoRegistro;
    TipoRegistro: TipoRegistro;
    DocumentoResolutivo: Documento;
    ListaDetalle: IgedRegistroDetalle;
    Acciones: Acciones;
  }