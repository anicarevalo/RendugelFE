export interface PliegoUnidadEjecutora {
    CodPliegoUnidadEjecutora: string;
    DescPliegoUnidadEjecutora: string;
    IdPliegoUnidadEjecutora: number;   
  }