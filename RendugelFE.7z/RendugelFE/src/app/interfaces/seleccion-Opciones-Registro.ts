import {Naturaleza} from './naturaleza';
import {EventoRegistral} from './evento-registral';
import {Tipoiged} from './tipo-Iged';
import {TipoRegistro} from './tipo-registro';
import {Iged} from './iged';
export interface SeleccionOpcionesRegistro {
    Dre: Iged;     
    EventoRegistral: EventoRegistral;
    Naturaleza: Naturaleza;
    Tipoiged: Tipoiged;
    TipoRegistro: TipoRegistro;
    Ugel: Iged;
  }