import {TipoMedioContacto} from './tipo-medio-contacto';
import {Iged} from './iged';

export interface IgedMedioContacto {
    IdMedioContactoIGED: number;  
    IdIGEDRegistro: number;
    Medio: string;
    Descripcion: string; //Agregar esto en la tabla de la Base de datos (figura en el prototipo pero olvidé colocarlo en la BD)
    TipoMedioContacto: TipoMedioContacto;  
    Iged: Iged;
  }