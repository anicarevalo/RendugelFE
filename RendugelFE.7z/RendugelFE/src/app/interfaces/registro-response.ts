 import {Iged} from './iged';
import {Tipoiged} from './tipo-Iged';
import {EventoRegistral} from './evento-registral';
import {TipoRegistro} from './tipo-registro';
import {Ubigeo} from './ubigeo';
import {Documento} from './documento'

export interface RegistroResponse {
    NombreUgel: string;
    CodUgel: string;
    Dre: Iged;
    TipoIged: Tipoiged;
    EventoRegistral: EventoRegistral;
    TipoRegistro: TipoRegistro;
    Ubigeo: Ubigeo;
    DocumentoResolutivo: Documento
  }