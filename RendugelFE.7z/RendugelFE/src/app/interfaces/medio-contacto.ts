import {TipoMedioContactoB} from './tipo-medio-contacto-b'
//import {TipoMedioContacto} from './tipo-medio-contacto'
export interface MedioContacto {
    IdMedioContactoIGED: number,  
    IdIGEDRegistro: number,  
    Medio: string;
    Descripcion: string; //Agregar esto en la tabla de la Base de datos (figura en el prototipo pero olvidé colocarlo en la BD)
    TipoMedioContacto: TipoMedioContactoB;  
    //TipoMedioContacto: TipoMedioContacto;  
  }