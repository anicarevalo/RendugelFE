export interface Region {
    IdUbigeo: number;
    CodUbigeo: string;
    Nombre: string;
  }