import {IgedRegistroDefinitivoDetalle} from './iged-registro-definitivo-detalle';
import {MedioContacto} from './medio-contacto';
import {Personal} from './personal';
import {LocalIged} from './local-iged';
import {UnidadEjecutora} from './unidad-ejecutora';
import {Jurisdiccion} from './jurisdiccion';
import {Documento} from './documento';

export interface RegistroDefinitivoResponse {
    IdRegistro: number;
    DetalleDerivados: IgedRegistroDefinitivoDetalle[];
    MediosContactoIged: MedioContacto[];
    PersonalIged: Personal[];
    localesIged: LocalIged[];
    UnidadEjecutoraIged: UnidadEjecutora;
    JurisdiccionUgel: Jurisdiccion[];
    DocumentoResolutivoDirector: Documento;
    EsUEAutonoma:boolean;
  }