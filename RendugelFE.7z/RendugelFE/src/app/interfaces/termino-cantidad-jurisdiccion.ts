export interface TerminoCantidadJurisdiccion {
    IdTerminoCantidad: number;
    CodTerminoCantidad: number;
    DescTerminoCantidad: string;
  }