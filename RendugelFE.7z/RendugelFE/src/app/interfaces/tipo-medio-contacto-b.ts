export interface TipoMedioContactoB {
  IdTipoMedioContacto: number;
  CodTipoMedio: number;
  DescTipoMedio: string
  }