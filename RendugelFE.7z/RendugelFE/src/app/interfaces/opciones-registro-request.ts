export interface OpcionesRegistroRequest {
    codTipoIgedRegistrar: number;
    codTipoRegistro: number;
  }