import {TipoRegistro} from './tipo-registro';
import {EstadoRegistro} from './estado-registro';

export interface OpcionesBandejaRequest {
    listaTipoRegistro : TipoRegistro[];
    listaEstadoRegistro: EstadoRegistro[];
  }