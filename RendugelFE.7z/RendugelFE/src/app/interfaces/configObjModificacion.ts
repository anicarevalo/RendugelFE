export interface configObjModificacion{
    denominacion: boolean;
    director: boolean;
    jurisdiccion: boolean;
    sede: boolean;
    ejecutora: boolean;
  }