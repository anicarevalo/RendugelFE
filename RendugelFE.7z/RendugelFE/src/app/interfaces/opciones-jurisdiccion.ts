import {Iged} from './iged';
import {EventoRegistral} from './evento-registral';
import {Naturaleza} from './naturaleza';

export interface OpcionesJurisdiccion {
    ListaUgel : Iged[];
    ListaEventoRegistralC: EventoRegistral[];
    ListaNaturalezaC: Naturaleza[];
  }
