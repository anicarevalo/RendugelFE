import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

//componentes propios
import {BandejasComponent} from './paginas/bandejas/bandejas.component';
import {OpcionesRegistroComponent} from './paginas/opciones-registro/opciones-registro.component';
import {ContenidoComponent} from './componentes/contenido/contenido.component';
import {NuevoRegistroProvisionalComponent} from './paginas/nuevo-registro-provisional/nuevo-registro-provisional.component';
import {NuevoRegistroDefinitivoComponent} from './paginas/nuevo-registro-definitivo/nuevo-registro-definitivo.component';
import {ModificacionSignificativaComponent} from './paginas/modificacion-significativa/modificacion-significativa.component';
import {ModificacionComplementariaComponent} from './paginas/modificacion-complementaria/modificacion-complementaria.component';
import {CierreDefinitivoComponent} from './paginas/cierre-definitivo/cierre-definitivo.component';
import {SuspensionRegistroComponent} from './paginas/suspension-registro/suspension-registro.component';
import {CancelacionRegistroComponent} from './paginas/cancelacion-registro/cancelacion-registro.component';

const routes: Routes = [
  {path: 'contenido', component: ContenidoComponent},
  {path: 'registro', component: OpcionesRegistroComponent},
  {path: 'NuevoRegistroProvisional', component: NuevoRegistroProvisionalComponent},
  {path: 'NuevoRegistroDefinitivo', component: NuevoRegistroDefinitivoComponent},
  {path: 'ModificacionSigniticativa', component: ModificacionSignificativaComponent},
  {path: 'ModificacionComplementaria', component: ModificacionComplementariaComponent},
  {path: 'CierreDefinitivo', component: CierreDefinitivoComponent},
  {path: 'SuspensionRegistro', component: SuspensionRegistroComponent},
  {path: 'CancelarRegistros', component: CancelacionRegistroComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }

