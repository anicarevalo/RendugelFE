import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import {ItemBandejaRegistros} from '../interfaces/itemBandejaRegistros';
import {DataBandeja} from '../mock/DataBandeja'

@Injectable({
  providedIn: 'root'
})
export class BandejaRegistroService {

  constructor() { }

  getDataBandeja(): Observable<ItemBandejaRegistros[]> {
    return of(DataBandeja);
  }
}
