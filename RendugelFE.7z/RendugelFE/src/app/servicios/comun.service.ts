import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import {EntidadOpcionesRegistro} from '../interfaces/entidad-opciones-registro';
import {OpcionesRegistroRequest} from '../interfaces/opciones-registro-request';
import {SeleccionOpcionesRegistro} from '../interfaces/seleccion-Opciones-Registro';
import {OpcionesUbigeo} from '../interfaces/opciones-ubigeo';
import {TipoDocumento} from '../interfaces/tipo-documento';
import {OpcionesJurisdiccion}  from '../interfaces/opciones-jurisdiccion';
import {ConfiguracionOpcionesRegistro} from '../interfaces/configuracion-opciones-registro';
import {Distrito} from '../interfaces/distrito';
import {RegistroResponse} from '../interfaces/registro-response';
import {ResponseService} from '../interfaces/response-service'
import {RegistroBandeja} from '../interfaces/registro-bandeja';
import {IgedRegistroDetalle} from '../interfaces/iged-registro-detalle';
import {ParametrosRegistro} from '../interfaces/parametros-registro';
import {IgedJurisdiccionResponse} from '../interfaces/iged-jurisdiccion-response';
import {DataOpcionesRegistro} from '../mock/DataOpcionesRegistro';
import {DataConfiguracionOpcionesRegistro} from '../mock/DataConfiguracionOpcionesRegistro';
import {Iged} from '../interfaces/iged';
import {tokenName} from '@angular/compiler';
import {AuthService} from './auth.service';
import {map} from 'rxjs/operators'
import {CentroPoblado} from '../interfaces/centro-poblado';
import {RegistrosProvisionalesResponse} from '../interfaces/registros-provisionales-response';
import {RegistroDefinitivoResponse} from '../interfaces/registro-definitivo-response';
import {Documento} from '../interfaces/documento';
import { TipoRegistro } from '../interfaces/tipo-registro';
import { EstadoRegistro } from '../interfaces/estado-registro';
import {OpcionesBandejaRequest} from '../interfaces/opciones-bandeja-request';

@Injectable({
  providedIn: 'root'
})
export class ComunService {
  private registroUrl = '';
  configuracionOpcionesRegistro: ConfiguracionOpcionesRegistro;
  //private registroUrl = '/restComun/listaDre'
  //'api/listaDre';  // URL to web api
  
  constructor(private http: HttpClient, private authService:AuthService) { }
  
  headers : HttpHeaders = new HttpHeaders(
    {
      "Conten-Type": "application/json",
      //Authorization: this.authService.getToken();
    }
  )
  //getDataServicio() {
  //   return this.http.get<Iged[]>(this.registroUrl);
    //return of(DataOpcionesRegistro);
  //}

 //getDataServicio(): Observable<Iged[]> {
  //  return this.http.get<Iged[]>(this.registroUrl);
  //  //return of(DataOpcionesRegistro);
 // }

 /* obtenerOpcionesRegistro(opcionesRegistroRequest: OpcionesRegistroRequest): Observable<EntidadOpcionesRegistro> {
    let token = this.authService.getToken;

    return this.http.post<EntidadOpcionesRegistro>(this.registroUrl, opcionesRegistroRequest, {headers: this.headers})
    . pipe(map(data=> data));
    //return this.http.post<EntidadOpcionesRegistro>(this.registroUrl, opcionesRegistroRequest);
    //return of(DataOpcionesRegistro);
  }
  */
  obtenerListasComponentes():  Observable<any> {
  this.registroUrl = '/restComun/ObtenerListasComponentes';
  return this.http.get<any>(this.registroUrl,{headers: this.headers});
  }

  obtenerListaTipoDocumento():  Observable<TipoDocumento[]> {
    this.registroUrl = '/restComun/ObtenerListaCDTipoDocumento';
    return this.http.get<TipoDocumento[]>(this.registroUrl,{headers: this.headers});
  }

  obtenerOpcionesUbigeo(IdDre:string):  Observable<OpcionesUbigeo> {
    this.registroUrl = '/restComun/OpcionesUbigeo/' + IdDre;
    return this.http.get<OpcionesUbigeo>(this.registroUrl,{headers: this.headers});
  }

  ObtenerListaUgelesPorDre(codDre:string):  Observable<Iged[]> {
    this.registroUrl = '/restComun/ObtenerListaUgelesPorDre/' + codDre;
    return this.http.get<Iged[]>(this.registroUrl,{headers: this.headers});
  }

  ObtenerListaUgelesInvolucradasPorUgel(ugel:Iged):  Observable<Iged[]> {
    this.registroUrl = '/restComun/ObtenerListaUgelesInvolucradasPorUgel';
    return this.http.post<Iged[]>(this.registroUrl,ugel,{headers: this.headers});
  }

  obtenerOpcionesRegistro(opcionesRegistroRequest: OpcionesRegistroRequest): Observable<EntidadOpcionesRegistro> {
    this.registroUrl = '/restComun/OpcionesRegistro';
    return this.http.post<EntidadOpcionesRegistro>(this.registroUrl, opcionesRegistroRequest, {headers: this.headers});
  }

  ObtenerConfiguracionOpcionesRegistro(opcionesRegistroRequest: OpcionesRegistroRequest): Observable<ConfiguracionOpcionesRegistro> {
     if(opcionesRegistroRequest.codTipoRegistro==1){
      this.configuracionOpcionesRegistro = DataConfiguracionOpcionesRegistro.provicionalCreacion;
     }  
     else{
       if(opcionesRegistroRequest.codTipoRegistro==2){
        this.configuracionOpcionesRegistro = DataConfiguracionOpcionesRegistro.definitivoModificacion;
       }
     }      
      return of(this.configuracionOpcionesRegistro);
  }

  obtenerOpcionesJurisdiccion(parametrosRegistro: ParametrosRegistro): Observable<OpcionesJurisdiccion> {
    this.registroUrl = '/restComun/OpcionesJurisdiccionInvolucradas';
    return this.http.post<OpcionesJurisdiccion>(this.registroUrl, parametrosRegistro, {headers: this.headers});
  }

  obtenerCCPPPorDistrito(distrito: Distrito): Observable<CentroPoblado[]> {
    this.registroUrl = '/restComun/ObtenerCCPPPorDistrito';
    return this.http.post<CentroPoblado[]>(this.registroUrl, distrito, {headers: this.headers});
  }

  SaveRegistroProvisional(registroResponse: RegistroResponse): Observable<ResponseService> {
    this.registroUrl = '/restComun/SaveRegistroProvisional';
    return this.http.post<ResponseService>(this.registroUrl, registroResponse, {headers: this.headers});
  }

  PasarADefinitivo(registroResponse: RegistroDefinitivoResponse): Observable<ResponseService> {
    this.registroUrl = '/restComun/PasarADefinitivo';
    return this.http.post<ResponseService>(this.registroUrl, registroResponse, {headers: this.headers});
  }

  ObtenerRegistrosProvisionales():  Observable<RegistroBandeja[]> {
    this.registroUrl = '/restComun/ObtenerRegistrosProvisionales';
    return this.http.get<RegistroBandeja[]>(this.registroUrl,{headers: this.headers});
  }

  ObtenerRegistrosProvisionales2():  Observable<RegistrosProvisionalesResponse> {
    this.registroUrl = '/restComun/ObtenerRegistrosProvisionales2';
    return this.http.get<RegistrosProvisionalesResponse>(this.registroUrl,{headers: this.headers});
  }

  ObtenerRegistrosProvisionalesPoTipoEstado(listaTipoRegistro: TipoRegistro[], listaEstadoregistro: EstadoRegistro[]):  Observable<RegistroBandeja[]> {
    this.registroUrl = '/restComun/ObtenerRegistrosProvisionalesPoTipoEstado';
    let opcionesBandejaRequest: OpcionesBandejaRequest = {
      listaTipoRegistro: listaTipoRegistro,
      listaEstadoRegistro: listaEstadoregistro
    }
    return this.http.post<RegistroBandeja[]>(this.registroUrl, opcionesBandejaRequest ,{headers: this.headers});
  }

  ElimarRegistro(IdRegistro: number): Observable<ResponseService> {
    this.registroUrl = '/restComun/ElimarRegistro';
    return this.http.post<ResponseService>(this.registroUrl, IdRegistro, {headers: this.headers});
  }

  obtenerRegistroDetallePorIdRegistro(IdRegistro: number):  Observable<IgedRegistroDetalle[]> {
    this.registroUrl = '/restComun/obtenerRegistroDetallePorIdRegistro';
    return this.http.post<IgedRegistroDetalle[]>(this.registroUrl, IdRegistro, {headers: this.headers});
  }

  ObtenerJurisdiccionUgelPorListaUgeles(listaUgel: Iged[]):  Observable<IgedJurisdiccionResponse[]> {
    this.registroUrl = '/restComun/obtenerJurisdiccionUgelPorListaUgeles';
    return this.http.post<IgedJurisdiccionResponse[]>(this.registroUrl, listaUgel, {headers: this.headers});
  }

  public getPDF(documento: Documento): Observable<Blob> {   
    //const options = { responseType: 'blob' }; there is no use of this
    this.registroUrl =  '/restStream/Download';
    const headers = new HttpHeaders({ 'Content-Type': 'application/json',
                                       responseType : 'blob'});
        // this.http refers to HttpClient. Note here that you cannot use the generic get<Blob> as it does not compile: instead you "choose" the appropriate API in this way.
    return this.http.post(this.registroUrl, documento, {headers: headers, responseType: 'blob'});
    }

    //download.service.ts
/*getPdf() {

  this.authKey = localStorage.getItem('jwt_token');

  const httpOptions = {
    responseType: 'blob' as 'json',
    headers: new HttpHeaders({
      'Authorization': this.authKey,
    })
  };

  return this.http.get(`${this.BASE_URL}/help/pdf`, httpOptions);
}*/
  
}