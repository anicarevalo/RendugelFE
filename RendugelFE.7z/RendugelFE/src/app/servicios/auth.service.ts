import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {Observable} from 'rxjs/internal/observable';
import {map} from 'rxjs/operators';
//import {isNullOrUndeFined} from 'util';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  constructor(private http: HttpClient) { }

  headers: HttpHeaders = new HttpHeaders({
    "Content-Type": "application/json"
  });

  registerUser(name: string, email: string, password: string){
    const url_api = "http://aaaa/users";
    return this.http.post(
      url_api,
      { name:name,
        email: email,
        password: password
      },
      {headers: this.headers}
    ).pipe(map(data=>data));
  }

  loginUser(email: string, password: string):Observable<any>{
    const url_api = "http://aaaa/users/loguin?include=user";
    return this.http.post(
      url_api, 
      {email, password},
      {headers: this.headers}
    ).pipe(map(data=>data));
  }

  setUser(user){
    let user_string = JSON.stringify(user);
    localStorage.setItem("currentUser", user_string);
  }

  setToken(token){
    localStorage.setItem("accessToken", token);
  }

  getToken(){
    return localStorage.getItem("accessToken");
  }

  getCurrentUser(){
    let user_string = localStorage.getItem("currentUser");
    //if(isNullOrUndeFined(user_string)){
    //  let user = JSON.parse(user_string);
    //  return user;
    //}else{
      return null;
    //}
  }

  logoutUser(){
    let accessToken = localStorage.getItem("accessToken");
    const url_api = 'http://aaaa/users/logout?ccess_token=$(accessToken)';
    localStorage.removeItem("accessToken");
    localStorage.removeItem("currentUser");

    return this.http.post(url_api, {headers: this.headers});
  }

}
