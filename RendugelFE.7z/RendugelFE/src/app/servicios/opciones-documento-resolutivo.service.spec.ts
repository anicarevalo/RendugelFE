import { TestBed } from '@angular/core/testing';

import { OpcionesDocumentoResolutivoService } from './opciones-documento-resolutivo.service';

describe('OpcionesDocumentoResolutivoService', () => {
  let service: OpcionesDocumentoResolutivoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OpcionesDocumentoResolutivoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
