import { TestBed } from '@angular/core/testing';

import { OpcionesUbigeoService } from './opciones-ubigeo.service';

describe('OpcionesUbigeoService', () => {
  let service: OpcionesUbigeoService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OpcionesUbigeoService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
