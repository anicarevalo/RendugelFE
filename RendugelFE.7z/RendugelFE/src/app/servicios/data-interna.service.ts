import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';
import {SeleccionOpcionesRegistro} from '../interfaces/seleccion-Opciones-Registro';
import {OpcionesRegistroRequest} from '../interfaces/opciones-registro-request';
import {RegistroBandeja} from '../interfaces/registro-bandeja';
import {IgedRegistroDetalle } from '../interfaces/iged-registro-detalle';
//import {RegistroDefinitivoRequest } from '../interfaces/registro-definitivo-request';
import {Iged } from '../interfaces/iged';
import {Jurisdiccion} from '../interfaces/jurisdiccion';
import {IgedRegistroDefinitivoDetalle} from '../interfaces/iged-registro-definitivo-detalle';
import {EventoRegistral} from '../interfaces/evento-registral';

@Injectable({
  providedIn: 'root'
})
export class DataInternaService {

    opcionesRegistro: SeleccionOpcionesRegistro;
    opcionesRegistroRequest: OpcionesRegistroRequest;
    registroBandejaRequest: RegistroBandeja;
    detalleRegistroRequest: IgedRegistroDetalle[];
    eventosRegistrales: EventoRegistral[];
    editar:boolean;
    //registroDefinitivoRequest: RegistroDefinitivoRequest;
    subject: Subject<Object>;

  constructor() { }


guardarTempDefinitivoDetalle(_ugel: Iged, JurisdiccionIged: Jurisdiccion[], _eventoRegistral:EventoRegistral, _esOrigen: boolean){
  let  _definitivoDetalle: IgedRegistroDefinitivoDetalle[]=[];

  const _IgedRegistroDefinitivoDetalle: IgedRegistroDefinitivoDetalle=
      {
        IdIgedRegistro: 0,
        EsOrigen: _esOrigen,
        Ugel: _ugel,
        EventoRegistral: _eventoRegistral,
        JurisdiccionIged: JurisdiccionIged//this.dataSource
      }     
      if (localStorage.getItem('definitivoDetalle')===null){
        _definitivoDetalle.push(_IgedRegistroDefinitivoDetalle)
        localStorage.setItem('definitivoDetalle', JSON.stringify(_definitivoDetalle));
      }
      else{
        //let _IgedRegistroDefinitivoDetalle1: IgedRegistroDefinitivoDetalle;
        _definitivoDetalle = JSON.parse(localStorage.getItem('definitivoDetalle'));        
        const indice:number =  _definitivoDetalle.findIndex(e => (e.Ugel.CodIged== _ugel.CodIged 
                                                                  && e.EventoRegistral.CodEvento== _eventoRegistral.CodEvento))

        if (indice != undefined && indice >=0){
         _definitivoDetalle[indice].JurisdiccionIged = JurisdiccionIged //this.dataSource
          localStorage.setItem('definitivoDetalle', JSON.stringify(_definitivoDetalle));
        }
        else{
          _definitivoDetalle.push(_IgedRegistroDefinitivoDetalle)
          localStorage.setItem('definitivoDetalle', JSON.stringify(_definitivoDetalle));
        }        
      } 
  }

}