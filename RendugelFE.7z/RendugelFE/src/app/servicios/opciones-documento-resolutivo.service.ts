import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import {TipoDocumento} from '../interfaces/tipo-documento';
import {DataTipoDocumento} from '../mock/DataTipoDocumento';

@Injectable({
  providedIn: 'root'
})
export class OpcionesDocumentoResolutivoService {

  constructor() { }

  getDataServicio(): Observable<TipoDocumento[]> {
    return of(DataTipoDocumento);
  }
}
