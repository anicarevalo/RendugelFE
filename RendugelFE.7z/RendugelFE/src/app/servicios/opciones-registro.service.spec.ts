import { TestBed } from '@angular/core/testing';

import { OpcionesRegistroService } from './opciones-registro.service';

describe('OpcionesRegistroService', () => {
  let service: OpcionesRegistroService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OpcionesRegistroService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
