import { TestBed } from '@angular/core/testing';

import { DataInternaService } from './data-interna.service';

describe('DataInternaService', () => {
  let service: DataInternaService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(DataInternaService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
