import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Observable, of } from 'rxjs';
import {EntidadOpcionesRegistro} from '../interfaces/entidad-opciones-registro';
import {OpcionesRegistroRequest} from '../interfaces/opciones-registro-request';
import {DataOpcionesRegistro} from '../mock/DataOpcionesRegistro';
import {Iged} from '../interfaces/iged';
import { tokenName } from '@angular/compiler';
import {AuthService} from './auth.service';
import {map} from 'rxjs/operators'

@Injectable({
  providedIn: 'root'
})
export class OpcionesRegistroService {
  private registroUrl = '';
  
  //private registroUrl = '/restComun/listaDre'
  //'api/listaDre';  // URL to web api
  
  constructor(private http: HttpClient, private authService:AuthService) { }
  headers : HttpHeaders = new HttpHeaders(
    {
      "Conten-Type": "application/json",
      //Authorization: this.authService.getToken();
    }
  )
  //getDataServicio() {
  //   return this.http.get<Iged[]>(this.registroUrl);
    //return of(DataOpcionesRegistro);
  //}

 //getDataServicio(): Observable<Iged[]> {
  //  return this.http.get<Iged[]>(this.registroUrl);
  //  //return of(DataOpcionesRegistro);
 // }

 /* obtenerOpcionesRegistro(opcionesRegistroRequest: OpcionesRegistroRequest): Observable<EntidadOpcionesRegistro> {
    let token = this.authService.getToken;

    return this.http.post<EntidadOpcionesRegistro>(this.registroUrl, opcionesRegistroRequest, {headers: this.headers})
    . pipe(map(data=> data));
    //return this.http.post<EntidadOpcionesRegistro>(this.registroUrl, opcionesRegistroRequest);
    //return of(DataOpcionesRegistro);
  }
*/
  obtenerOpcionesRegistro(opcionesRegistroRequest: OpcionesRegistroRequest): Observable<EntidadOpcionesRegistro> {
    //let token = this.authService.getToken;
    this.registroUrl = '/restComun/OpcionesRegistro';
    //return this.http.post<EntidadOpcionesRegistro>(registroUrl, opcionesRegistroRequest, {headers: this.headers});
    return this.http.post<EntidadOpcionesRegistro>(this.registroUrl, opcionesRegistroRequest, {headers: this.headers});
    //. pipe(map(data=> data));
    //return this.http.post<EntidadOpcionesRegistro>(this.registroUrl, opcionesRegistroRequest);
    //return of(DataOpcionesRegistro);
  }

}