import { TestBed } from '@angular/core/testing';

import { BandejaRegistroService } from './bandeja-registro.service';

describe('BandejaRegistroService', () => {
  let service: BandejaRegistroService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(BandejaRegistroService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
