import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NuevoRegistroDefinitivoComponent } from './nuevo-registro-definitivo.component';

describe('NuevoRegistroDefinitivoComponent', () => {
  let component: NuevoRegistroDefinitivoComponent;
  let fixture: ComponentFixture<NuevoRegistroDefinitivoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NuevoRegistroDefinitivoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NuevoRegistroDefinitivoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
