import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CancelacionRegistroComponent } from './cancelacion-registro.component';

describe('CancelacionRegistroComponent', () => {
  let component: CancelacionRegistroComponent;
  let fixture: ComponentFixture<CancelacionRegistroComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CancelacionRegistroComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CancelacionRegistroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
