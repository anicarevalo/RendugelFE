import { Component, OnInit,ViewChild} from '@angular/core';
import { Subject, Observable } from 'rxjs';
import {DataInternaService} from '../../servicios/data-interna.service';
import {ParametrosRegistro} from '../../interfaces/parametros-registro';
import {ComunService} from '../../servicios/comun.service';
import {OpcionesUbigeo} from '../../interfaces/opciones-ubigeo';
import {Region} from '../../interfaces/region';
import {Naturaleza } from '../../interfaces/naturaleza';
import {EventoRegistral } from '../../interfaces/evento-registral';
import {Iged } from '../../interfaces/iged';
import {TipoDocumento } from '../../interfaces/tipo-documento';
import {IgedRegistroDetalle} from '../../interfaces/iged-registro-detalle';
import {RegistroBandeja} from '../../interfaces/registro-bandeja';
import {SeleccionOpcionesRegistro} from '../../interfaces/seleccion-Opciones-Registro';
import {ClasificacionDocumento} from '../../interfaces/clasificacion-documento';
import {Documento} from '../../interfaces/documento';
import {RegistroResponse} from '../../interfaces/registro-response';
import {IgedRegistroDefinitivoDetalle} from '../../interfaces/iged-registro-definitivo-detalle';
import {RegistroDefinitivoResponse} from '../../interfaces/registro-definitivo-response'; 
import { Router } from '@angular/router';

@Component({
  selector: 'app-suspension-registro',
  templateUrl: './suspension-registro.component.html',
  styleUrls: ['./suspension-registro.component.scss']
})
export class SuspensionRegistroComponent implements OnInit {

  step = -1;
  idDRE: string;
  prefijoCodigo: string;
  seleccionOpcionesRegistro: SeleccionOpcionesRegistro;
  registroBandejaRequest: RegistroBandeja;
  detalleRegistroRequest: IgedRegistroDetalle[];
  parametrosRegistro: ParametrosRegistro;

  //listaDistrito : Distrito[];
  //listaProvincias : Provincia[];
  //listaRegion : Region[];
  region : Region;

  listaNaturaleza: Naturaleza[];
  listaEventoRegistral: EventoRegistral[];
  listaUgel: Iged[];

  listaTipoDocumento: TipoDocumento[];
  
  public opcionesUbigeo: OpcionesUbigeo;
  RegistroResponse: RegistroResponse;

  @ViewChild("datosIged") datosIged;
  @ViewChild("documentoResolutivo") documentoResolutivo;
  
  constructor(private dataService: DataInternaService, 
              private comunService: ComunService,
              private router: Router) {
    localStorage.clear();
    this.registroBandejaRequest =  dataService.registroBandejaRequest;
    this.detalleRegistroRequest = dataService.detalleRegistroRequest;
    
    this.seleccionOpcionesRegistro = dataService.opcionesRegistro;
    
    //console.log("detalleRegistro");
    console.log('registroBandejaRequest');
    console.log(this.registroBandejaRequest);
    console.log('DocumentoResolutivo');
    console.log(this.registroBandejaRequest.DocumentoResolutivo);
    
    this.idDRE = this.detalleRegistroRequest[0].Dre.IdIged.toString();  //dataService.opcionesRegistro.Dre.NomIged;
    this.prefijoCodigo = this.detalleRegistroRequest[0].Dre.CodIged.substring(1,4);

    this.obtenerListasComponentes();
    //console.log(this.opcionesUbigeo.Region.Nombre);
    
    this.parametrosRegistro = {
      dre : this.detalleRegistroRequest[0].Dre,
      eventoRegistral: this.detalleRegistroRequest[0].EventoRegistral,
      tipoIged: this.detalleRegistroRequest[0].TipoIged,
      tipoRegistro: this.registroBandejaRequest.TipoRegistro,
      ugel: {
              CodIged:this.detalleRegistroRequest[0].Ugel.CodIged,
              CodTipoIged:this.detalleRegistroRequest[0].TipoIged.CodTipoIged,
              DescTipoIged:this.detalleRegistroRequest[0].TipoIged.DescTipoIged,
              IdIged:this.detalleRegistroRequest[0].Ugel.IdIged,
              IdTipoIged:this.detalleRegistroRequest[0].TipoIged.IdTipoIged,
              NomIged:this.detalleRegistroRequest[0].Ugel.NomIged
            }
      };   
  }

  ngOnInit(): void {    
  }

  /*obtenerListaTipoDocumento():void{
    this.comunService.obtenerListaTipoDocumento()
    .subscribe(res => {this.listaTipoDocumento = res});
  }*/

  obtenerListasComponentes():void{
    this.comunService.obtenerListasComponentes()
    .subscribe(res => {
          this.listaTipoDocumento = res['TiposDocumento'] ,  
          
          console.log("lista componentes: res")  
          console.log(res);

          console.log("lista componentes: listaTipoDocumento")  
          console.log(this.listaTipoDocumento)

          /*this.listaTiposMedioGeneralesB = res['TiposMedioDatosGenerales'],
          this.listaTipoMediosDirectorB = res['TiposMedioDatosDirector'],
          this.listaTiposPersonal = res['TiposPersonalDatosPersonal'],
          this.listaTiposLocal = res['TiposLocal'],
          this.listaTiposPropiedad=res['TiposPropiedad'];
          this.listaPliegoUE = res['PliegosUnidadEjecutora'];          

          console.log("lista componentes: listaTiposLocal")  
          console.log(this.listaTiposLocal)

          console.log("lista componentes: listaTiposPropiedad")  
          console.log(this.listaTiposPropiedad)    */    
              
        });
  }
 
  Aceptar(val:string):void{
    if (val="OK")
      {
        let DocumentoResolutivoDirector: Documento;
        
        //Recoger data y enviar al servicio
        //console.log("Recoger data y enviar al servicio");  

          //console.log("Recoger data docResolutivoDirectorChild"); 
          //console.log(this.docResolutivoDirectorChild);
        /*  DocumentoResolutivoDirector = {
            IdDocumento: 0,
            Temporal: true,
            NombreArchivo: (this.docResolutivoDirectorChild.uploadFile.files.length==0)?"":this.docResolutivoDirectorChild.uploadFile.files[0].data.name,
            NroDocumento: this.docResolutivoDirectorChild.nroDocumento,
            Ruta: null,
            FechaEmision: null, //new Date(this.documentoResolutivo.fechaDocumento.value),
            FechaPublicacion: null, //new Date(this.documentoResolutivo.fechaPublicacion.value),
            ClasificacionDocumento: {IdClasificacionDoc:1, CodClasificacionDoc: 1, DescClasificacionDoc:"Resolutivo" },
            TipoDocumento:this.docResolutivoDirectorChild.selectedTipoDocumento
          }
          console.log("DocumentoResolutivoDirector"); 
          console.log(DocumentoResolutivoDirector);
 
          let registroDefinitivoResponse: RegistroDefinitivoResponse={
                  IdRegistro: this.registroBandejaRequest.IdRegistro,
                  DetalleDerivados: definitivoDetalleDerivados,
                  MediosContactoIged: mediosContactoIged,
                  PersonalIged: personalIged,
                  localesIged: localesIged,
                  UnidadEjecutoraIged: unidadEjecutoraIged,
                  JurisdiccionUgel: JurisdiccionUgel,
                  DocumentoResolutivoDirector: DocumentoResolutivoDirector,
                  EsUEAutonoma : false
                  }

          console.log("DATOS ENVIADOS AL SERVIDOR");
          console.log(registroDefinitivoResponse);

          this.PasarADefinitivo(registroDefinitivoResponse);       
          */  
      }    
  }

  /*
  PasarADefinitivo(registroResponse: RegistroDefinitivoResponse):void{    
    this.comunService.PasarADefinitivo(registroResponse)
    .subscribe(res => {
      console.log(res);
      if (res!= undefined){
        this.redireccionarBandeja()
      }     
    });
  }  
  redireccionarBandeja(){
    console.log("");
    this.router.navigate(['/contenido']);
    }
*/

  Cancelar(val:string):void{
    if (val="CANCEL")
      {
          //Limpiar formularios
          console.log("Limpiar formularios");          
      }      
  }
}