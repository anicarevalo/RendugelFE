import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuspensionRegistroComponent } from './suspension-registro.component';

describe('SuspensionRegistroComponent', () => {
  let component: SuspensionRegistroComponent;
  let fixture: ComponentFixture<SuspensionRegistroComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SuspensionRegistroComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SuspensionRegistroComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
