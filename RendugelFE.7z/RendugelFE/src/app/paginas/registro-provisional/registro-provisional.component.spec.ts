import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistroProvisionalComponent } from './registro-provisional.component';

describe('RegistroProvisionalComponent', () => {
  let component: RegistroProvisionalComponent;
  let fixture: ComponentFixture<RegistroProvisionalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegistroProvisionalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegistroProvisionalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
