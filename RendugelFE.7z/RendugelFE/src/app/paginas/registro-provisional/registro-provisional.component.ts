import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-registro-provisional',
  templateUrl: './registro-provisional.component.html',
  styleUrls: ['./registro-provisional.component.scss']
})
export class RegistroProvisionalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
