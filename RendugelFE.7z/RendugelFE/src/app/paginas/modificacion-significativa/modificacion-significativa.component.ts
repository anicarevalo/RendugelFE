import { Component, OnInit,ViewChild, Input} from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import {MatSnackBar} from '@angular/material/snack-bar';
import {DataInternaService} from '../../servicios/data-interna.service';
import {SeleccionOpcionesRegistro} from '../../interfaces/seleccion-Opciones-Registro';
import {ParametrosRegistro} from '../../interfaces/parametros-registro';
import {ComunService} from '../../servicios/comun.service';
import {OpcionesUbigeo} from '../../interfaces/opciones-ubigeo';
import {Region} from '../../interfaces/region';
import {Provincia} from '../../interfaces/provincia';
import {Distrito} from '../../interfaces/distrito';
import {Ubigeo} from '../../interfaces/ubigeo';
import {Naturaleza} from '../../interfaces/naturaleza';
import {EventoRegistral} from '../../interfaces/evento-registral';
import {Iged} from '../../interfaces/iged';
import {TipoDocumento} from '../../interfaces/tipo-documento';
import {ClasificacionDocumento} from '../../interfaces/clasificacion-documento';
import {IgedRegistroDetalle} from '../../interfaces/iged-registro-detalle';
import {RegistroBandeja} from '../../interfaces/registro-bandeja';
import {Documento} from '../../interfaces/documento';
import {RegistroResponse} from '../../interfaces/registro-response';
import {ResponseService} from '../../interfaces/response-service';
import {Subject, Observable} from 'rxjs';
import {MatDialog, MatDialogConfig} from '@angular/material/dialog';
import {ModalMsnAceptarComponent} from '../../componentes/modal/modal-msn-aceptar/modal-msn-aceptar.component';
import {Router} from '@angular/router';
import {MedioContacto} from '../../interfaces/medio-contacto';
import {TipoMedioContacto} from '../../interfaces/tipo-medio-contacto';
import {TipoMedioContactoB} from '../../interfaces/tipo-medio-contacto-b';
import {PliegoUnidadEjecutora} from '../../interfaces/pliego-unidad-ejecutora';
import {TipoPropiedad} from '../../interfaces/tipo-propiedad';
import {TipoLocal} from '../../interfaces/tipo-local';
import {configObjModificacion} from '../../interfaces/configObjModificacion';
import {tiposMedioContacto} from '../../mock/DataTipoMedioContacto';

export interface ResDatosModel{
  titulo: string,
  mensaje: string,
}

@Component({
  selector: 'app-modificacion-significativa',
  templateUrl: './modificacion-significativa.component.html',
  styleUrls: ['./modificacion-significativa.component.scss']
})
export class ModificacionSignificativaComponent implements OnInit {
    seleccionOpcionesRegistro: SeleccionOpcionesRegistro;
    eventosRegistrales: EventoRegistral[];

    listaDistrito: Distrito[];
    listaDistritoPorProvincia: Distrito[];
    listaProvincia: Provincia[];
    listaProvinciaPorRegion: Provincia[];
    listaRegion: Region[];

    listaTipoDocumento: TipoDocumento[];
    prefijoCodigo: string;
    region: Region;
    provincia: Provincia;
    distrito: Distrito;

    listaTipoMediosDirector: TipoMedioContacto[]=[];
    listaTipoMediosDirectorB: TipoMedioContactoB[];
    listaTiposMedioGenerales: TipoMedioContacto[]=[];
    listaTiposMedioGeneralesB: TipoMedioContactoB[];

    step = -1;

    listaPliegoUE: PliegoUnidadEjecutora[];
    listaTiposPropiedad: TipoPropiedad[];
    listaTiposLocal: TipoLocal[];
    listaTiposLocalT: TipoLocal[];

    parametrosRegistro: ParametrosRegistro;    

    configObj: configObjModificacion = 
    {
      denominacion: false,
      director: false,
      jurisdiccion: false,
      sede: false,
      ejecutora: false
    }

    idDRE: string;

    @ViewChild("sedeChild") sedeChild;

    constructor(private dataService: DataInternaService, 
              private comunService: ComunService) {
    this.seleccionOpcionesRegistro =  dataService.opcionesRegistro;
    this.eventosRegistrales = this.dataService.eventosRegistrales;    
    this.obtenerListasComponentes();

    this.idDRE = this.seleccionOpcionesRegistro.Dre.IdIged.toString();
    this.obtenerOpcionesUbigeo(this.idDRE);

    this.parametrosRegistro = {
      dre : dataService.opcionesRegistro.Dre,
      eventoRegistral: dataService.opcionesRegistro.EventoRegistral,
      tipoIged: dataService.opcionesRegistro.Tipoiged,
      tipoRegistro: dataService.opcionesRegistro.TipoRegistro,
      ugel: dataService.opcionesRegistro.Ugel            
      };
    }

    ngOnInit(): void {}

    obtenerListasComponentes():void{
      this.comunService.obtenerListasComponentes()
      .subscribe(res => {
            this.listaTipoDocumento = res['TiposDocumento'] ,      
            this.listaTiposMedioGeneralesB = res['TiposMedioDatosGenerales'],
            this.listaTipoMediosDirectorB = res['TiposMedioDatosDirector'],
            //this.listaTiposPersonal = res['TiposPersonalDatosPersonal'],
            this.listaTiposLocalT = res['TiposLocal'],
            this.listaTiposPropiedad=res['TiposPropiedad'];
            this.listaPliegoUE = res['PliegosUnidadEjecutora'];
  
            this.listaTiposLocal= this.listaTiposLocalT.filter(option => option.CodTipoLocal==1);

            console.log("lista componentes: res")  
            console.log(res);
            //console.log("lista componentes: listaTiposMedioGeneralesB")  
            //console.log(this.listaTiposMedioGeneralesB);*/  
            console.log("lista componentes: listaTiposLocal")  
            console.log(this.listaTiposLocal)
  
            console.log("lista componentes: listaTiposPropiedad")  
            console.log(this.listaTiposPropiedad)
  
            console.log("lista componentes: listaTipoDocumento")  
            console.log(this.listaTipoDocumento)
  
            for (let tipoMedio of this.listaTiposMedioGeneralesB){
  
               const _tipoMedioContacto: TipoMedioContacto =  tiposMedioContacto.find(tipo=>tipo.CodTipo==tipoMedio.CodTipoMedio);
  
               const tipoMedioContacto: TipoMedioContacto = {
                IdTipoMedioContacto: tipoMedio.IdTipoMedioContacto,
                CodTipo: tipoMedio.CodTipoMedio,
                DescTipo: tipoMedio.DescTipoMedio,
                icono: _tipoMedioContacto.icono,
                labelIconbtn: _tipoMedioContacto.labelIconbtn,
                labelMedio: _tipoMedioContacto.labelMedio,
               } 
               this.listaTiposMedioGenerales.push(tipoMedioContacto)
               //console.log(tipoMedioContacto);
            }
  
            for (let tipoMedio of this.listaTipoMediosDirectorB){
  
              const _tipoMedioContacto: TipoMedioContacto =  tiposMedioContacto.find(tipo=>tipo.CodTipo==tipoMedio.CodTipoMedio);
  
              const tipoMedioContacto: TipoMedioContacto = {
               IdTipoMedioContacto: tipoMedio.IdTipoMedioContacto,
               CodTipo: tipoMedio.CodTipoMedio,
               DescTipo: tipoMedio.DescTipoMedio,
               icono: _tipoMedioContacto.icono,
               labelIconbtn: _tipoMedioContacto.labelIconbtn,
               labelMedio: _tipoMedioContacto.labelMedio,
              } 
              this.listaTipoMediosDirector.push(tipoMedioContacto)
              //console.log(tipoMedioContacto);
            }
            console.log("this.listaTipoMediosDirector");
            console.log(this.listaTipoMediosDirector);
                
          });
    }

    obtenerOpcionesUbigeo(IdDre:string):void{
    
      this.comunService.obtenerOpcionesUbigeo(IdDre)
      .subscribe(res => {
        this.listaDistrito = res['ListaDistritos'],
        this.listaProvincia = res['ListaProvincias'];
        this.region  = res['Region'];
        this.listaRegion= [this.region];      
  
        this.listaProvinciaPorRegion= this.listaProvincia.filter(option => option.Region.CodUbigeo==this.region.CodUbigeo);
        this.listaDistritoPorProvincia= this.listaDistrito.filter(option => option.Provincia.CodUbigeo==this.provincia.CodUbigeo);
  
        this.provincia = this.listaProvinciaPorRegion.find(x=> x.CodUbigeo == this.provincia.CodUbigeo);
        this.distrito = this.listaDistritoPorProvincia.find(x=> x.CodUbigeo == this.distrito.CodUbigeo);
  
        this.provincia.Region = this.region;  
        
        const options= {onlySelf: true, emitEvent: true, emitModelToViewChange: true, emitViewToModelChange:true}
  
        this.sedeChild.regionControl.setValue(this.region);       
        this.sedeChild.provinciaControl.setValue(this.provincia, options);    
        this.sedeChild.distritoControl.setValue(this.distrito, options);  
      });
     }

    habilitarObjetos(_configObj: configObjModificacion):void{
      this.configObj = _configObj;
    }

    setStep(index: number) {
      this.step = index;
    }
  
    nextStep() {
      this.step++;
    }
  
    prevStep() { 
      this.step--;
    }

    Cancelar(val:string):void{
      if (val="CANCEL") {console.log("Limpiar formularios"); }      
    }    
    Aceptar(val:string):void{}
}
  
/*
  step = 0;
  resDatosModel: ResDatosModel={titulo:"", mensaje:""};
  idDRE: string;
  prefijoCodigo: string;
  seleccionOpcionesRegistro: SeleccionOpcionesRegistro;
  detalleRegistroRequest: IgedRegistroDetalle[];
  registroBandejaRequest: RegistroBandeja;
  listaDistrito : Distrito[];
  listaDistritoPorProvincia: Distrito[]
  listaProvincia : Provincia[];
  listaProvinciaPorRegion: Provincia[];
  listaRegion : Region[];
  region : Region;
  provincia: Provincia;
  distrito: Distrito;
  documento: Documento;
  valid: boolean = true;

  listaNaturaleza: Naturaleza[];
  listaEventoRegistral: EventoRegistral[];
  listaUgel: Iged[];

  mensajesValidacion: string[] = [];

  listaTipoDocumento: TipoDocumento[];
  public opcionesUbigeo: OpcionesUbigeo;
  registroResponse: RegistroResponse;
  responseService: ResponseService;

  mensajePrincipal: string="";
  mensajes: string[]=[];
  resultValid: boolean = false;
  @Input() idRegistro: number= 0;

  @ViewChild("datosIged") datosIged;
  @ViewChild("documentoResolutivo") documentoResolutivo;
  @ViewChild("jurisdiccion") jurisdiccion;
  @ViewChild("accordionRegistro") accordionRegistro;  

  ubigeoUgel : Ubigeo;  
  
  constructor(private dataService: DataInternaService, 
              private comunService: ComunService,
              private _snackBar: MatSnackBar,
              public dialog: MatDialog,
              private router: Router) {
  
    this.registroBandejaRequest =  dataService.registroBandejaRequest;
    this.detalleRegistroRequest = dataService.detalleRegistroRequest;
    this.seleccionOpcionesRegistro =  dataService.opcionesRegistro;

    console.log("registro bandeja request");
    console.log(this.registroBandejaRequest);
    console.log("detalle registro request");
    console.log(this.detalleRegistroRequest);

    if (this.registroBandejaRequest != undefined && this.registroBandejaRequest != null){
      this.documento = this.registroBandejaRequest.DocumentoResolutivo;
    }
    else{
      this.documento = null;
    }

    if(this.detalleRegistroRequest != undefined && this.detalleRegistroRequest != null
      && this.detalleRegistroRequest.length > 0)
      {        
        this.idDRE = this.detalleRegistroRequest[0].Dre.IdIged.toString();
        this.prefijoCodigo = this.detalleRegistroRequest[0].Dre.CodIged.substring(0,4);
        this.provincia = this.detalleRegistroRequest[0].provincia;
        this.distrito = this.detalleRegistroRequest[0].distrito;        
        console.log("IDDRE");
        console.log(this.idDRE);
      }
    else {      
      this.idDRE = this.seleccionOpcionesRegistro.Dre.IdIged.toString(); 
      this.prefijoCodigo = this.seleccionOpcionesRegistro.Dre.CodIged.substring(0,4);
    } 

    this.obtenerOpcionesUbigeo(this.idDRE);
    this.obtenerListaTipoDocumento();
  }

  openDialog(resDatosModel: ResDatosModel): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose= true;
    dialogConfig.autoFocus = true;
    dialogConfig.hasBackdrop =true;
    dialogConfig.data = this.resDatosModel;

    const dialogRef = this.dialog.open(ModalMsnAceptarComponent, dialogConfig);    

    dialogRef.afterClosed().subscribe(
      res => {
                if (res!= undefined && res=="OK"){
                  this.redireccionarBandeja()
                }          
        });
    }  

  ngOnInit(): void {
  }

  redireccionarBandeja(){
    console.log("");
    this.router.navigate(['/contenido']);
    }

  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  prevStep() { 
    this.step--;
  }

  saveRegistroProvisional(registroResponse:RegistroResponse):void{    
    this.comunService.SaveRegistroProvisional(registroResponse)
    .subscribe(res => {
      this.mensajePrincipal = res["MensajePrincipal"]
 
    });
  }

  obtenerListaTipoDocumento():void{
    this.comunService.obtenerListaTipoDocumento()
    .subscribe(res => {
      console.log(res), 
      this.listaTipoDocumento = res;
      console.log("*** this.documento");
      console.log(this.documento);

      let tipoDocumento: TipoDocumento = this.listaTipoDocumento.find(x=> x.IdTipoDoc==this.documento.TipoDocumento.IdTipoDoc)

      console.log("*** let tipoDocumento");
      console.log(tipoDocumento);
      
      this.documentoResolutivo.tipoDocumentoControl.setValue(tipoDocumento); 
    });
  }

  obtenerOpcionesUbigeo(IdDre:string):void{
    
    this.comunService.obtenerOpcionesUbigeo(IdDre)
    .subscribe(res => {
      this.listaDistrito = res['ListaDistritos'],
      this.listaProvincia = res['ListaProvincias'];
      this.region  = res['Region'];
      this.listaRegion= [this.region];      

      this.listaProvinciaPorRegion= this.listaProvincia.filter(option => option.Region.CodUbigeo==this.region.CodUbigeo);
      this.listaDistritoPorProvincia= this.listaDistrito.filter(option => option.Provincia.CodUbigeo==this.provincia.CodUbigeo);

      this.provincia = this.listaProvinciaPorRegion.find(x=> x.CodUbigeo == this.provincia.CodUbigeo);
      this.distrito = this.listaDistritoPorProvincia.find(x=> x.CodUbigeo == this.distrito.CodUbigeo);

      this.provincia.Region = this.region;  
      
      const options= {onlySelf: true, emitEvent: true, emitModelToViewChange: true, emitViewToModelChange:true}

      this.datosIged.regionControl.setValue(this.region);       
      this.datosIged.provinciaControl.setValue(this.provincia, options);    
      this.datosIged.distritoControl.setValue(this.distrito, options);

    });
   }

  Aceptar(val:string):void{
    if (val="OK")
      {
        let _documento:Documento;
        this.mensajesValidacion=[];
        this.ubigeoUgel = null;

        this.valid = ((this.datosIged.distritoControl.status=="INVALID") ||
        (this.datosIged.provinciaControl.status=="INVALID") ||
        (this.datosIged.regionControl.status=="INVALID") ||
        (this.datosIged.nombre.status=="INVALID") ||
        (this.datosIged.codigo.status=="INVALID") ||
        (this.documentoResolutivo.uploadFile.files.length==0)
        )?false:true;

        if(this.documentoResolutivo.uploadFile.documento!= undefined 
            && this.documentoResolutivo.uploadFile.documento != null)
        {
          if(this.documentoResolutivo.uploadFile.documento.IdDocumento> 0)
          {
              _documento=this.documentoResolutivo.uploadFile.documento;
          }
          else{
            this.valid = false;
          }
        }

        console.log("valido?:");
        console.log(this.valid);

        console.log("Documento Resolutivo");
        console.log(this.documentoResolutivo);

      if (this.valid)
        {
              if(this.datosIged.selectedDistrito !=undefined && this.datosIged.selectedDistrito != null){
                this.ubigeoUgel = {
                    IdUbigeo: this.datosIged.selectedDistrito.IdUbigeo,
                    CodUbigeo: this.datosIged.selectedDistrito.CodUbigeo,
                    Nombre: this.datosIged.selectedDistrito.Nombre,
                    IdTipoUbigeo: 0,
                    CodTipoUbigeo: 0
                  }
                }
            
            this.registroResponse =
            {
              NombreUgel : this.datosIged.nombreUgel,
              CodUgel : this.prefijoCodigo.concat(this.datosIged.codigoUgel),
              Dre: this.seleccionOpcionesRegistro.Dre,         
              TipoIged: this.seleccionOpcionesRegistro.Tipoiged,
              EventoRegistral:this.seleccionOpcionesRegistro.EventoRegistral,
              TipoRegistro: this.seleccionOpcionesRegistro.TipoRegistro,
              Ubigeo: this.ubigeoUgel,

              DocumentoResolutivo: {
                IdDocumento: _documento.IdDocumento,
                Temporal: true,
                NombreArchivo: _documento.NombreArchivo, 
                NroDocumento: this.documentoResolutivo.nroDocumento,
                Ruta: null,
                FechaEmision: null, 
                FechaPublicacion: null, 
                ClasificacionDocumento: {IdClasificacionDoc:1, CodClasificacionDoc: 1, DescClasificacionDoc:"Resolutivo" },
                TipoDocumento:this.documentoResolutivo.selectedTipoDocumento
              }
            }

            console.log(this.registroResponse);
            this.saveRegistroProvisional(this.registroResponse);
            this.resDatosModel.titulo="Nuevo registro provisional";
            this.openDialog(this.resDatosModel);            
            console.log(this.mensajePrincipal);
          }
          else {
            this.openSnackBar("Ingrese todos los campos requerido", "X")
          }
      }      
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 2000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
    });
  }

  validarDataEnvio(registroResponse: RegistroResponse){
  }

  ValidarNombre(nombre:string){
    nombre.length<3
  }

  Cancelar(val:string):void{
    if (val="CANCEL")
      {
          console.log("Limpiar formularios");
          
      }      
  } 
}
*/
