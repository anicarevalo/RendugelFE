import { Component, OnInit, EventEmitter, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import {DataInternaService} from '../../servicios/data-interna.service';
import {SeleccionOpcionesRegistro} from '../../interfaces/seleccion-Opciones-Registro';
import {OpcionesRegistroRequest} from '../../interfaces/opciones-registro-request';
import {RegistroBandeja} from '../../interfaces/registro-bandeja'
import {ComunService} from '../../servicios/comun.service';
import { EstadoRegistro } from 'src/app/interfaces/estado-registro';
import { TipoRegistro } from 'src/app/interfaces/tipo-registro';
import { Documento } from 'src/app/interfaces/documento';

export interface Seleccion{
  provisionales: boolean,
  suspendidos: boolean,
  cancelado: boolean,
  definitivo: boolean,
}

@Component({
  selector: 'app-bandejas',
  templateUrl: './bandejas.component.html',
  styleUrls: ['./bandejas.component.scss']
})
export class BandejasComponent implements OnInit {
  //opcionesRegistroRequest: OpcionesRegistroRequest;
  public ListaRegistroBandeja: RegistroBandeja[];
  IdRegistro: number;
  CodRegistro: string;
  Estado: string;
  CodTipoRegistro: number;
  UsuCreacion: string;
  EstadoRegistro: EstadoRegistro;
  TipoRegistro: TipoRegistro;
  DocumentoResolutivo: Documento;
  listaTipoRegistro: TipoRegistro[];
  listaEstadoRegistro: EstadoRegistro[];

  @ViewChild("objGrillaBandeja") objGrillaBandeja;
  
  constructor(private dataService: DataInternaService, 
              private router: Router,
              private comunService: ComunService) {
                
                this.listaEstadoRegistro = [];
                
                this.listaTipoRegistro =[];
                  let estadoRegistro: EstadoRegistro={
                    CodEstadoRegistro: 1,
                    DescEstadoRegistro: "",
                    IdEstadoRegistro: 0
                  }            
                  let tipoRegistro: TipoRegistro = {
                    CodTipoRegistro: 1,
                    DescTipoRegistro:"",
                    IdTipoRegistro:0
                  }
                  this.listaEstadoRegistro.push(estadoRegistro)
                  this.listaTipoRegistro.push(tipoRegistro)               
                 this.ObtenerRegistrosProvisionalesPoTipoEstado(this.listaTipoRegistro,this.listaEstadoRegistro);

    //this.ObtenerRegistrosProvisionales();
    console.log("ListaRegistroBandeja");
    console.log(this.ListaRegistroBandeja);

    console.log("obj grila")
    console.log(this.objGrillaBandeja);

    }

  ngOnInit(): void {
    
  }

  ObtenerRegistrosProvisionales(){
    this.comunService.ObtenerRegistrosProvisionales()
    .subscribe(res => {
      this.ListaRegistroBandeja = res;
      console.log("directo a log ListaRegistroBandeja");
      console.log(this.ListaRegistroBandeja);
      /*console.log(this.objGrillaBandeja);
      console.log("ver");
      console.log(this.objGrillaBandeja.objTabla);
      console.log("ver datasource");
      console.log(this.objGrillaBandeja.objTabla.dataSource);
      console.log("ver data");
      console.log(this.objGrillaBandeja.objTabla.dataSource.data);*/

      this.objGrillaBandeja.objTabla.dataSource.data = this.ListaRegistroBandeja;
      console.log("Ver datasource");
      console.log(this.objGrillaBandeja.objTabla.dataSource.data);
      //this.objGrillaBandeja.objTabla.renderRows();
      //this.listaDistrito = res['ListaDistritos'],
      //this.listaProvincias = res['ListaProvincias'],           
      //this.listaRegion= [this.region  = res['Region']]
    });
  }

  ObtenerRegistrosProvisionalesPoTipoEstado(listaTipoRegistro: TipoRegistro[], listaEstadoregistro: EstadoRegistro[]){
    this.comunService.ObtenerRegistrosProvisionalesPoTipoEstado(listaTipoRegistro,listaEstadoregistro)
    .subscribe(res => {
      this.ListaRegistroBandeja = res;
      console.log("directo a log ListaRegistroBandeja");
      console.log(this.ListaRegistroBandeja);

      this.objGrillaBandeja.objTabla.dataSource.data = this.ListaRegistroBandeja;
      console.log("Ver datasource");
      console.log(this.objGrillaBandeja.objTabla.dataSource.data);
    });
  }

  opcionesRegistroProvisional(val:string):void{
    const opcionesRegistroRequest: OpcionesRegistroRequest = {
      codTipoIgedRegistrar : 2,
      codTipoRegistro: 1
    }    
    this.dataService.opcionesRegistroRequest = opcionesRegistroRequest;    
    this.router.navigate(['/registro']);
  }

  opcionesRegistroDefinitivo(val:string):void{
    const opcionesRegistroRequest: OpcionesRegistroRequest = {
      codTipoIgedRegistrar : 2,
      codTipoRegistro: 2
    }    
    this.dataService.opcionesRegistroRequest = opcionesRegistroRequest;    
    this.router.navigate(['/registro']);
  }

  SeleccionarBandeja(seleccion: Seleccion){
    this.listaEstadoRegistro = [];
    this.listaTipoRegistro =[];

    if (seleccion.provisionales){
      let estadoRegistro: EstadoRegistro={
        CodEstadoRegistro: 1,
        DescEstadoRegistro: "",
        IdEstadoRegistro: 0
      }

      let tipoRegistro: TipoRegistro = {
        CodTipoRegistro: 1,
        DescTipoRegistro:"",
        IdTipoRegistro:0
      }
      this.listaEstadoRegistro.push(estadoRegistro)
      this.listaTipoRegistro.push(tipoRegistro)
    }

    if (seleccion.definitivo){
      let estadoRegistro: EstadoRegistro={
        CodEstadoRegistro: 5,
        DescEstadoRegistro: "",
        IdEstadoRegistro: 0
      }

      let tipoRegistro: TipoRegistro = {
        CodTipoRegistro: 2,
        DescTipoRegistro:"",
        IdTipoRegistro:0
      }
      this.listaEstadoRegistro.push(estadoRegistro)
      this.listaTipoRegistro.push(tipoRegistro)
    }  
    this.ObtenerRegistrosProvisionalesPoTipoEstado(this.listaTipoRegistro,this.listaEstadoRegistro);
  }

}
