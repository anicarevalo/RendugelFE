import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { BandejasComponent } from './bandejas.component';

describe('BandejasComponent', () => {
  let component: BandejasComponent;
  let fixture: ComponentFixture<BandejasComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ BandejasComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(BandejasComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
