import { ComponentFixture, TestBed } from '@angular/core/testing';

import { CierreDefinitivoComponent } from './cierre-definitivo.component';

describe('CierreDefinitivoComponent', () => {
  let component: CierreDefinitivoComponent;
  let fixture: ComponentFixture<CierreDefinitivoComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ CierreDefinitivoComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(CierreDefinitivoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
