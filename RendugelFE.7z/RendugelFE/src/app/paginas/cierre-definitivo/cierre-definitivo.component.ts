import { Component, OnInit,ViewChild, Input} from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import {DataInternaService} from '../../servicios/data-interna.service';
import {SeleccionOpcionesRegistro} from '../../interfaces/seleccion-Opciones-Registro';
import {ComunService} from '../../servicios/comun.service';
import {Naturaleza} from '../../interfaces/naturaleza';
import {EventoRegistral} from '../../interfaces/evento-registral';
import {Iged} from '../../interfaces/iged';
import {TipoDocumento} from '../../interfaces/tipo-documento';
import {configObjModificacion} from '../../interfaces/configObjModificacion';

export interface ResDatosModel{
  titulo: string,
  mensaje: string,
}

@Component({
  selector: 'app-cierre-definitivo',
  templateUrl: './cierre-definitivo.component.html',
  styleUrls: ['./cierre-definitivo.component.scss']
})
export class CierreDefinitivoComponent implements OnInit {
  seleccionOpcionesRegistro: SeleccionOpcionesRegistro;
  eventosRegistrales: EventoRegistral[];

  listaTipoDocumento: TipoDocumento[];

  configObj: configObjModificacion = 
  {
    denominacion: false,
    director: false,
    jurisdiccion: false,
    sede: false,
    ejecutora: false
  }

  idDRE: string;

  @ViewChild("sedeChild") sedeChild;

  constructor(private dataService: DataInternaService, 
            private comunService: ComunService) {
  this.seleccionOpcionesRegistro =  dataService.opcionesRegistro;
  this.eventosRegistrales = this.dataService.eventosRegistrales;    
  //this.idDRE = this.seleccionOpcionesRegistro.Dre.IdIged.toString();
  }

  ngOnInit(): void {
  }


  habilitarObjetos(_configObj: configObjModificacion):void{
    this.configObj = _configObj;
  }

  Cancelar(val:string):void{
    if (val="CANCEL") {console.log("Limpiar formularios"); }      
  }    
  Aceptar(val:string):void{}
}

