import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { NuevoRegistroProvisionalComponent } from './nuevo-registro-provisional.component';

describe('NuevoRegistroProvisionalComponent', () => {
  let component: NuevoRegistroProvisionalComponent;
  let fixture: ComponentFixture<NuevoRegistroProvisionalComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ NuevoRegistroProvisionalComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(NuevoRegistroProvisionalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
