import { Component, OnInit,ViewChild, Input} from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import {MatSnackBar} from '@angular/material/snack-bar';
import {DataInternaService} from '../../servicios/data-interna.service';
import {SeleccionOpcionesRegistro} from '../../interfaces/seleccion-Opciones-Registro';
import {ParametrosRegistro} from '../../interfaces/parametros-registro';
import {ComunService} from '../../servicios/comun.service';
import {OpcionesUbigeo} from '../../interfaces/opciones-ubigeo';
import {Region} from '../../interfaces/region';
import {Provincia} from '../../interfaces/provincia';
import {Distrito} from '../../interfaces/distrito';
import {Ubigeo} from '../../interfaces/ubigeo';
import {Naturaleza} from '../../interfaces/naturaleza';
import {EventoRegistral} from '../../interfaces/evento-registral';
import {Iged} from '../../interfaces/iged';
import {TipoDocumento} from '../../interfaces/tipo-documento';
import {ClasificacionDocumento} from '../../interfaces/clasificacion-documento';
import {IgedRegistroDetalle} from '../../interfaces/iged-registro-detalle';
import {RegistroBandeja} from '../../interfaces/registro-bandeja';
import {Documento} from '../../interfaces/documento';
import {RegistroResponse} from '../../interfaces/registro-response';
import {ResponseService} from '../../interfaces/response-service';
import {Subject, Observable} from 'rxjs';
import {MatDialog, MatDialogConfig} from '@angular/material/dialog';
import {ModalMsnAceptarComponent} from '../../componentes/modal/modal-msn-aceptar/modal-msn-aceptar.component';
import {Router} from '@angular/router';

export interface ResDatosModel{
  titulo: string,
  mensaje: string,
}

@Component({
  selector: 'app-nuevo-registro-provisional',
  templateUrl: './nuevo-registro-provisional.component.html',
  styleUrls: ['./nuevo-registro-provisional.component.scss']
})
export class NuevoRegistroProvisionalComponent implements OnInit {
  step = 0;
  resDatosModel: ResDatosModel={titulo:"", mensaje:""};
  idDRE: string;
  prefijoCodigo: string;
  seleccionOpcionesRegistro: SeleccionOpcionesRegistro;
  detalleRegistroRequest: IgedRegistroDetalle[];
  registroBandejaRequest: RegistroBandeja;
  listaDistrito : Distrito[];
  listaDistritoPorProvincia: Distrito[]
  listaProvincia : Provincia[];
  listaProvinciaPorRegion: Provincia[];
  listaRegion : Region[];
  region : Region;
  provincia: Provincia;
  distrito: Distrito;
  documento: Documento;
  valid: boolean = true;

  listaNaturaleza: Naturaleza[];
  listaEventoRegistral: EventoRegistral[];
  listaUgel: Iged[];

  mensajesValidacion: string[] = [];

  listaTipoDocumento: TipoDocumento[];
  public opcionesUbigeo: OpcionesUbigeo;
  registroResponse: RegistroResponse;
  responseService: ResponseService;

  mensajePrincipal: string="";
  mensajes: string[]=[];
  resultValid: boolean = false;
  @Input() idRegistro: number= 0;

  @ViewChild("datosIged") datosIged;
  @ViewChild("documentoResolutivo") documentoResolutivo;
  @ViewChild("jurisdiccion") jurisdiccion;
  @ViewChild("accordionRegistro") accordionRegistro;  

  //Objeto para enviar a grabar
  ubigeoUgel : Ubigeo;  

  editar: boolean = false;
  
  constructor(private dataService: DataInternaService, 
              private comunService: ComunService,
              private _snackBar: MatSnackBar,
              public dialog: MatDialog,
              private router: Router) {
    /****/
    this.registroBandejaRequest =  dataService.registroBandejaRequest;
    this.detalleRegistroRequest = dataService.detalleRegistroRequest;
    this.seleccionOpcionesRegistro =  dataService.opcionesRegistro;
    console.log("dataService.editar");
    console.log(dataService.editar);
    this.editar = dataService.editar;

    console.log("registro bandeja request");
    console.log(this.registroBandejaRequest);
    console.log("detalle registro request");
    console.log(this.detalleRegistroRequest);

    if (this.registroBandejaRequest != undefined && this.registroBandejaRequest != null){
      this.documento = this.registroBandejaRequest.DocumentoResolutivo;
    }
    else{
      this.documento = null;
    }

    if(this.detalleRegistroRequest != undefined && this.detalleRegistroRequest != null
      && this.detalleRegistroRequest.length > 0)
      {        
        this.idDRE = this.detalleRegistroRequest[0].Dre.IdIged.toString();
        this.prefijoCodigo = this.detalleRegistroRequest[0].Dre.CodIged.substring(0,4);
        this.provincia = this.detalleRegistroRequest[0].provincia;
        this.distrito = this.detalleRegistroRequest[0].distrito;        
        console.log("IDDRE");
        console.log(this.idDRE);
      }
    else {      
      this.idDRE = this.seleccionOpcionesRegistro.Dre.IdIged.toString();  //dataService.opcionesRegistro.Dre.NomIged;
      this.prefijoCodigo = this.seleccionOpcionesRegistro.Dre.CodIged.substring(0,4);
    }
    /****/     

    this.obtenerOpcionesUbigeo(this.idDRE);
    this.obtenerListaTipoDocumento();
    //    
  }

  openDialog(resDatosModel: ResDatosModel): void {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.disableClose= true;
    dialogConfig.autoFocus = true;
    dialogConfig.hasBackdrop =true;
    dialogConfig.data = this.resDatosModel;

    const dialogRef = this.dialog.open(ModalMsnAceptarComponent, dialogConfig);    

    dialogRef.afterClosed().subscribe(
      res => {
                if (res!= undefined && res=="OK"){
                  this.redireccionarBandeja()
                }          
        });
    }  

  ngOnInit(): void {
  }

  redireccionarBandeja(){
    console.log("");
    this.router.navigate(['/contenido']);
    }

  setStep(index: number) {
    this.step = index;
  }

  nextStep() {
    this.step++;
  }

  prevStep() { 
    this.step--;
  }

  saveRegistroProvisional(registroResponse:RegistroResponse):void{    
    this.comunService.SaveRegistroProvisional(registroResponse)
    .subscribe(res => {
      this.mensajePrincipal = res["MensajePrincipal"]
      //console.log(res);
      //this.mensajes = res["Mensajes"],
      //this.resultValid = res["ResultValid"],
      //this.idRegistro = res["idRegistro"]    
    });
  }

  obtenerListaTipoDocumento():void{
    this.comunService.obtenerListaTipoDocumento()
    .subscribe(res => {
      console.log(res), 
      this.listaTipoDocumento = res;
      console.log("*** this.documento");
      console.log(this.documento);

      let tipoDocumento: TipoDocumento = this.listaTipoDocumento.find(x=> x.IdTipoDoc==this.documento.TipoDocumento.IdTipoDoc)

      console.log("*** let tipoDocumento");
      console.log(tipoDocumento);
      
      this.documentoResolutivo.tipoDocumentoControl.setValue(tipoDocumento); 
    });
  }

  obtenerOpcionesUbigeo(IdDre:string):void{
    
    this.comunService.obtenerOpcionesUbigeo(IdDre)
    .subscribe(res => {
      this.listaDistrito = res['ListaDistritos'],
      this.listaProvincia = res['ListaProvincias'];
      this.region  = res['Region'];
      this.listaRegion= [this.region];      

      /*console.log("*** this.listaDistrito");
      console.log(this.listaDistrito);
      console.log("*** this.listaProvincias");
      console.log(this.listaProvincia);
      console.log("*** this.listaRegion");       
      console.log(this.listaRegion);     */ 

      this.listaProvinciaPorRegion= this.listaProvincia.filter(option => option.Region.CodUbigeo==this.region.CodUbigeo);
      this.listaDistritoPorProvincia= this.listaDistrito.filter(option => option.Provincia.CodUbigeo==this.provincia.CodUbigeo);

      this.provincia = this.listaProvinciaPorRegion.find(x=> x.CodUbigeo == this.provincia.CodUbigeo);
      this.distrito = this.listaDistritoPorProvincia.find(x=> x.CodUbigeo == this.distrito.CodUbigeo);

      /*console.log("*** this.listaProvinciaPorRegion");
      console.log(this.listaProvinciaPorRegion);
      console.log("*** this.listaDistritoPorProvincia");
      console.log(this.listaDistritoPorProvincia);      

      console.log("this.provincia");
      console.log(this.provincia);*/

      this.provincia.Region = this.region;  
      
      /*console.log("this.distrito");
      console.log(this.distrito);*/

      const options= {onlySelf: true, emitEvent: true, emitModelToViewChange: true, emitViewToModelChange:true}

      this.datosIged.regionControl.setValue(this.region);       
      this.datosIged.provinciaControl.setValue(this.provincia, options);    
      //this.datosIged.provinciaControl.setValue(this.listaProvinciaPorRegion[2], options);    
      this.datosIged.distritoControl.setValue(this.distrito, options);

      /*console.log("Datos Iged");
      console.log(this.datosIged);
      console.log("Region control");
      console.log(this.datosIged.regionControl);
      console.log("this.datosIged.provinciaControl");
      console.log(this.datosIged.provinciaControl);
      console.log("this.datosIged.distritoControl");
      console.log(this.datosIged.distritoControl);      
      
      console.log("this.datosIged.regionChild");
      console.log(this.datosIged.regionChild);

      console.log("this.datosIged.regionChild._selectionModel");
      console.log(this.datosIged.regionChild._selectionModel);

      console.log("this.datosIged.provinciaChild");
      console.log(this.datosIged.provinciaChild);

      console.log("this.datosIged.provinciaChild._selectionModel");
      console.log(this.datosIged.provinciaChild._selectionModel);*/
      
      //setValue
      //emitModelToViewChange?: boolean;
      //emitViewToModelChange?: boolean;
    });
   }

  /*obtenerOpcionesJurisdiccion (parametrosRegistro: ParametrosRegistro):void {
    this.comunService.obtenerOpcionesJurisdiccion(parametrosRegistro)
    .subscribe(res => {
      console.log(res),
      this.listaUgel = res['ListaUgel'],
      this.listaEventoRegistral = res['ListaEventoRegistralC'],
      this.listaNaturaleza = res['ListaNaturalezaC']
      });
  }*/
 
  Aceptar(val:string):void{
    if (val="OK")
      {
        //this.dataService.subject.next(val);
        //Recoger data y enviar al servicio
        let _documento:Documento;
        this.mensajesValidacion=[];
        this.ubigeoUgel = null;

        this.valid = ((this.datosIged.distritoControl.status=="INVALID") ||
        (this.datosIged.provinciaControl.status=="INVALID") ||
        (this.datosIged.regionControl.status=="INVALID") ||
        (this.datosIged.nombre.status=="INVALID") ||
        (this.datosIged.codigo.status=="INVALID") ||
        (this.documentoResolutivo.uploadFile.files.length==0)
        )?false:true;

        if(this.documentoResolutivo.uploadFile.documento!= undefined 
            && this.documentoResolutivo.uploadFile.documento != null)
        {
          if(this.documentoResolutivo.uploadFile.documento.IdDocumento> 0)
          {
              _documento=this.documentoResolutivo.uploadFile.documento;
          }
          else{
            this.valid = false;
          }
        }

        console.log("valido?:");
        console.log(this.valid);

        console.log("Documento Resolutivo");
        console.log(this.documentoResolutivo);

        //this.valid = false; //borrar esto!!!
      if (this.valid)
        {
          /*if(this.datosIged.disabled){
              if(this.datosIged.selectedCCPP !=undefined && this.datosIged.selectedCCPP != null){
                this.ubigeoUgel = {
                    IdUbigeo: this.datosIged.selectedCCPP.IdUbigeo,
                    CodUbigeo: this.datosIged.selectedCCPP.CodUbigeo,
                    Nombre: this.datosIged.selectedCCPP.Nombre,
                    IdTipoUbigeo: null,
                    CodTipoUbigeo: null         
                  }
                }
              else{
                const constUbigeo: Ubigeo = null;
                //this.mensajesValidacion.push("El centro poblado es requerido al marcar la casilla Centro poblado")            
              }          
              }
              else{
                if(this.datosIged.selectedDistrito !=undefined && this.datosIged.selectedDistrito != null){
                  this.ubigeoUgel = {
                      IdUbigeo: this.datosIged.selectedDistrito.IdUbigeo,
                      CodUbigeo: this.datosIged.selectedDistrito.CodUbigeo,
                      Nombre: this.datosIged.selectedDistrito.Nombre,
                      IdTipoUbigeo: null,
                      CodTipoUbigeo: null
                    }
                  }
                else{
                  const constUbigeo: Ubigeo = null;
                  //this.mensajesValidacion.push("El distrito es requerido")            
                } 
              }*/
              
              if(this.datosIged.selectedDistrito !=undefined && this.datosIged.selectedDistrito != null){
                this.ubigeoUgel = {
                    IdUbigeo: this.datosIged.selectedDistrito.IdUbigeo,
                    CodUbigeo: this.datosIged.selectedDistrito.CodUbigeo,
                    Nombre: this.datosIged.selectedDistrito.Nombre,
                    IdTipoUbigeo: 0,
                    CodTipoUbigeo: 0
                  }
                }
            
            this.registroResponse =
            {
              NombreUgel : this.datosIged.nombreUgel,
              CodUgel : this.prefijoCodigo.concat(this.datosIged.codigoUgel),
              Dre: this.seleccionOpcionesRegistro.Dre,         
              TipoIged: this.seleccionOpcionesRegistro.Tipoiged,
              EventoRegistral:this.seleccionOpcionesRegistro.EventoRegistral,
              TipoRegistro: this.seleccionOpcionesRegistro.TipoRegistro,
              Ubigeo: this.ubigeoUgel,
              //{
              // IdUbigeo: this.datosIged.selectedDistrito.IdUbigeo,
              // CodUbigeo: this.datosIged.selectedDistrito.CodUbigeo,
              // Nombre: this.datosIged.selectedDistrito.Nombre         
              //},
              DocumentoResolutivo: {
                IdDocumento: _documento.IdDocumento,
                Temporal: true,
                NombreArchivo: _documento.NombreArchivo, //(this.documentoResolutivo.uploadFile.files.length==0)?"":this.documentoResolutivo.uploadFile.files[0].data.name,
                NroDocumento: this.documentoResolutivo.nroDocumento,
                Ruta: null,
                FechaEmision: null, //new Date(this.documentoResolutivo.fechaDocumento.value),
                FechaPublicacion: null, //new Date(this.documentoResolutivo.fechaPublicacion.value),
                ClasificacionDocumento: {IdClasificacionDoc:1, CodClasificacionDoc: 1, DescClasificacionDoc:"Resolutivo" },
                TipoDocumento:this.documentoResolutivo.selectedTipoDocumento
              }
            }

            console.log(this.registroResponse);
            this.saveRegistroProvisional(this.registroResponse);
            this.resDatosModel.titulo="Nuevo registro provisional";
            //this.resDatosModel.mensaje="Los datos se guardaron correctamente";
            this.openDialog(this.resDatosModel);            
            console.log(this.mensajePrincipal);
          }
          else {
            this.openSnackBar("Ingrese todos los campos requerido", "X")
          }
        //console.log(this.valid);
        //console.log(this.datosIged);
        //console.log(this.datosIged.distritoControl.errors);
        //console.log(this.registroResponse);
        //console.log(this.documentoResolutivo);


        /*
          console.log("Recoger data y enviar al servicio"); 
          console.log(this.datosIged);   
          console.log(this.datosIged.selectedDistrito);   
          console.log(this.documentoResolutivo);  
          console.log("jurisdiccion:", this.jurisdiccion);
          console.log(this.accordionRegistro);
          */
      }      
  }

  openSnackBar(message: string, action: string) {
    this._snackBar.open(message, action, {
      duration: 2000,
      horizontalPosition: 'center',
      verticalPosition: 'top',
    });
  }

  validarDataEnvio(registroResponse: RegistroResponse){
  }

  ValidarNombre(nombre:string){
    nombre.length<3
  }

  Cancelar(val:string):void{
    if (val="CANCEL")
      {
          //Limpiar formularios
          console.log("Limpiar formularios");
          
      }      
  } 
}

