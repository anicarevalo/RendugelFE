import { Component, OnInit } from '@angular/core';
import {FormControl, Validators} from '@angular/forms';
import {OpcionesRegistroService} from '../../servicios/opciones-registro.service';
import {EntidadOpcionesRegistro} from '../../interfaces/entidad-opciones-registro';
import {OpcionesRegistroRequest} from '../../interfaces/opciones-registro-request';
import {DataInternaService} from '../../servicios/data-interna.service';
import {ComunService} from '../../servicios/comun.service';
import {Naturaleza} from '../../interfaces/naturaleza';
import {EventoRegistral} from '../../interfaces/evento-registral';
import {Tipoiged} from '../../interfaces/tipo-Iged';
import {TipoRegistro} from '../../interfaces/tipo-registro';
import {Iged} from '../../interfaces/iged';
import {ConfiguracionOpcionesRegistro} from '../../interfaces/configuracion-opciones-registro';
import {configuracion} from '../../interfaces/configuracion';
import {DataOpcionesRegistro} from '../../mock/DataOpcionesRegistro';

@Component({
  selector: 'app-opciones-registro',
  templateUrl: './opciones-registro.component.html',
  styleUrls: ['./opciones-registro.component.scss']
})
export class OpcionesRegistroComponent  {

  public entidadOpcionesRegistro: EntidadOpcionesRegistro;
  opcionesRegistroRequest: OpcionesRegistroRequest;

    listaDRE: Iged[];
    //listaUGEL: Iged[];
    listaTipoIged: Tipoiged[];
    listaNaturaleza: Naturaleza[];
    listaEventoRegistral: EventoRegistral[];
    listaTipoRegistro: TipoRegistro[];
    //configuracionOpcionesRegistro: ConfiguracionOpcionesRegistro;

    configDre: configuracion;
    configEventoRegistral: configuracion;
    configNaturaleza: configuracion;
    configTipoRegistro: configuracion;
    configTipoiged: configuracion;
    configUgel: configuracion;

    selected1 : Tipoiged;
    selected2 : Naturaleza;
    selected3 : Iged;
    selected4 : EventoRegistral;
    //selected5 : Iged;
    selected6 : TipoRegistro;


  selectFormControl1 = new FormControl('', Validators.required);
  selectFormControl2 = new FormControl('', Validators.required);
  selectFormControl3 = new FormControl('', Validators.required);
  selectFormControl4 = new FormControl('', Validators.required);
  //selectFormControl5 = new FormControl('', Validators.required);
  selectFormControl6 = new FormControl('', Validators.required);


  constructor(private opcionesRegistroService: OpcionesRegistroService, 
              private dataService: DataInternaService,
              private comunService: ComunService ) { 
    //this.getDataServicio();    
    this.opcionesRegistroRequest = dataService.opcionesRegistroRequest;

    /*{
      codTipoIgedRegistrar : 2,
      codTipoRegistro: 1
    };   */
         
    this.obtenerOpcionesRegistro(this.opcionesRegistroRequest);
    this.ObtenerConfiguracionOpcionesRegistro(this.opcionesRegistroRequest);

    console.log(this.configEventoRegistral);
    /*this.configuracionOpcionesRegistro.configDre;
    this.configuracionOpcionesRegistro.configEventoRegistral;
    this.configuracionOpcionesRegistro.configNaturaleza;
    this.configuracionOpcionesRegistro.configTipoRegistro;
    this.configuracionOpcionesRegistro.configTipoiged;
    this.configuracionOpcionesRegistro.configUgel;*/

  }

  ngOnInit() {
   // console.log(this.entidadOpcionesRegistro);
  }
 
  //getDataServicio(): void {
  //  this.opcionesRegistroService.getDataServicio()
  //      .subscribe(entidadOpcionesRegistro => this.entidadOpcionesRegistro = entidadOpcionesRegistro);
  //}
  //getDataServicio(): void {
  //  this.opcionesRegistroService.getDataServicio()
  //      .subscribe(listaDRE => this.listaDRE = listaDRE);
  //}

 /* obtenerOpcionesRegistro(opcionesRegistroRequest: OpcionesRegistroRequest): void {  
    this.opcionesRegistroService.obtenerOpcionesRegistro(opcionesRegistroRequest)
        .subscribe(entidadOpcionesRegistro => this.entidadOpcionesRegistro = entidadOpcionesRegistro);
  }*/

  obtenerOpcionesRegistro(opcionesRegistroRequest: OpcionesRegistroRequest): void {  
    this.opcionesRegistroService.obtenerOpcionesRegistro(opcionesRegistroRequest)
        .subscribe(res => {
          //console.log(res['ListaDRE'])
          this.listaDRE = res['ListaDRE'],
          this.listaTipoIged = res['ListaTipoIged'],
          this.listaNaturaleza = res['ListaNaturaleza'],
          this.listaEventoRegistral = res['ListaEventoRegistral'],
          this.listaTipoRegistro =  res['ListaTipoRegistro']

          //this.entidadOpcionesRegistro.ListaDRE = this.listaDRE,
          //this.entidadOpcionesRegistro.ListaTipoIged = this.listaTipoIged,
          //this.entidadOpcionesRegistro.ListaNaturaleza = this.listaNaturaleza,
          //this.entidadOpcionesRegistro.ListaEventoRegistral = this.listaEventoRegistral,
          //this.entidadOpcionesRegistro.ListaTipoRegistro = this.listaTipoRegistro
        });
  }

  ObtenerConfiguracionOpcionesRegistro(opcionesRegistroRequest: OpcionesRegistroRequest):void {
    this.comunService.ObtenerConfiguracionOpcionesRegistro(opcionesRegistroRequest)
      .subscribe(res => {
        this.configDre = res['configDre'],
        this.configEventoRegistral = res['configEventoRegistral'],
        this.configNaturaleza = res['configNaturaleza'],
        this.configTipoRegistro = res['configTipoRegistro'],
        this.configTipoiged = res['configTipoiged'],
        this.configUgel = res['configUgel']
        //console.log(res)
       }
      )      
  }

  //this.configuracionOpcionesRegistro = res
  /*
  obtenerOpcionesRegistro(opcionesRegistroRequest: OpcionesRegistroRequest): void {  
    this.opcionesRegistroService.obtenerOpcionesRegistro(opcionesRegistroRequest)
        .subscribe(data => this.entidadOpcionesRegistro = data);
  }
  */

  /*
  onSelected1(tipoiged: Tipoiged) {
    this.selected1 = tipoiged;
    //this.selectIdPOut.emit(tipoiged);    
  }

  onSelected2(naturaleza: Naturaleza) {
    this.selected2 = naturaleza;
    //this.selectIdPOut.emit(tipoiged);    
  }

  onSelected3(iged: Iged) {
    this.selected3 = iged;
    //this.selectIdPOut.emit(tipoiged);    
  }

  onSelected4(eventoRegistral: EventoRegistral) {
    this.selected4 = eventoRegistral;
    //this.selectIdPOut.emit(tipoiged);    
  }

  //onSelected5(iged: Iged) {
    //this.selected5 = iged;
    //this.selectIdPOut.emit(tipoiged);    
  //}

  onSelected6(tipoRegistro: TipoRegistro) {
    this.selected6 = tipoRegistro;
    //this.selectIdPOut.emit(tipoiged);    
  }
  */

}
