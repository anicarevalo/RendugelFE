import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ModificacionComplementariaComponent } from './modificacion-complementaria.component';

describe('ModificacionComplementariaComponent', () => {
  let component: ModificacionComplementariaComponent;
  let fixture: ComponentFixture<ModificacionComplementariaComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ModificacionComplementariaComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ModificacionComplementariaComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
