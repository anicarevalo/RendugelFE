import { Component, OnInit,ViewChild} from '@angular/core';
import { Subject, Observable } from 'rxjs';
import {DataInternaService} from '../../servicios/data-interna.service';
import {ParametrosRegistro} from '../../interfaces/parametros-registro';
import {ComunService} from '../../servicios/comun.service';
import {OpcionesUbigeo} from '../../interfaces/opciones-ubigeo';
import {Region} from '../../interfaces/region';
import {Provincia} from '../../interfaces/provincia';
import {Distrito} from '../../interfaces/distrito';
import {Naturaleza } from '../../interfaces/naturaleza';
import {EventoRegistral } from '../../interfaces/evento-registral';
import {Iged } from '../../interfaces/iged';
import {TipoDocumento } from '../../interfaces/tipo-documento';
import {IgedRegistroDetalle} from '../../interfaces/iged-registro-detalle';
import {RegistroBandeja} from '../../interfaces/registro-bandeja';
import {SeleccionOpcionesRegistro} from '../../interfaces/seleccion-Opciones-Registro';
import {ClasificacionDocumento} from '../../interfaces/clasificacion-documento';
import {Documento} from '../../interfaces/documento';
import {RegistroResponse} from '../../interfaces/registro-response';
import {tiposMedioContacto} from '../../mock/DataTipoMedioContacto';
import { TipoMedioContacto } from '../../interfaces/tipo-medio-contacto';
import { TipoMedioContactoB } from '../../interfaces/tipo-medio-contacto-b';
import { MedioContacto } from '../../interfaces/medio-contacto';
import { TipoPersonal } from '../../interfaces/tipo-personal';
import { TipoLocal } from '../../interfaces/tipo-local';
import { TipoPropiedad } from '../../interfaces/tipo-propiedad';
import {PliegoUnidadEjecutora} from '../../interfaces/pliego-unidad-ejecutora';
import {Personal} from '../../interfaces/personal';
import {LocalIged} from '../../interfaces/local-iged';
import {UnidadEjecutora} from '../../interfaces/unidad-ejecutora';
import {IgedRegistroDefinitivoDetalle} from '../../interfaces/iged-registro-definitivo-detalle';
import {Jurisdiccion} from '../../interfaces/Jurisdiccion';
import {RegistroDefinitivoResponse} from '../../interfaces/registro-definitivo-response'; 
import { Router } from '@angular/router';

@Component({
  selector: 'app-modificacion-complementaria',
  templateUrl: './modificacion-complementaria.component.html',
  styleUrls: ['./modificacion-complementaria.component.scss']
})
export class ModificacionComplementariaComponent implements OnInit {
  seleccionOpcionesRegistro: SeleccionOpcionesRegistro;
  eventosRegistrales: EventoRegistral[];

  listaDistrito: Distrito[];
  listaDistritoPorProvincia: Distrito[];
  listaProvincia: Provincia[];
  listaProvinciaPorRegion: Provincia[];
  listaRegion: Region[];

  listaTipoDocumento: TipoDocumento[];
  prefijoCodigo: string;
  region: Region;
  provincia: Provincia;
  distrito: Distrito;

  listaTipoMediosDirector: TipoMedioContacto[]=[];
  listaTipoMediosDirectorB: TipoMedioContactoB[];
  listaTiposMedioGenerales: TipoMedioContacto[]=[];
  listaTiposMedioGeneralesB: TipoMedioContactoB[];

  step = -1;

  listaTiposPropiedad: TipoPropiedad[];
  listaTiposLocal: TipoLocal[];
  listaTiposLocalT: TipoLocal[];

  idDRE: string;
  registroBandejaRequest: RegistroBandeja;
  detalleRegistroRequest: IgedRegistroDetalle[];
  parametrosRegistro: ParametrosRegistro;  

  listaNaturaleza: Naturaleza[];
  listaEventoRegistral: EventoRegistral[];
  listaUgel: Iged[];

  listaTiposPersonal: TipoPersonal[];
   
  public opcionesUbigeo: OpcionesUbigeo;
  RegistroResponse: RegistroResponse;

  @ViewChild("datosIged") datosIged;
 
  @ViewChild("accordionRegistro") accordionRegistro;  
  @ViewChild("seccionPersonal") seccionPersonal; 
  @ViewChild("seccionLocales") seccionLocales; 
  
  @ViewChild("datosContactoIgedChild") datosContactoIgedChild;
  @ViewChild("personalChild") personalChild;
  @ViewChild("localIgedChild") localIgedChild;
  
  constructor(private dataService: DataInternaService, 
    private comunService: ComunService,
    private router: Router) {
      localStorage.clear();
      //this.registroBandejaRequest =  dataService.registroBandejaRequest;
      //this.detalleRegistroRequest = dataService.detalleRegistroRequest;
      
      this.seleccionOpcionesRegistro = dataService.opcionesRegistro;
      this.eventosRegistrales = this.dataService.eventosRegistrales;    

      //console.log("detalleRegistro");
      //console.log('registroBandejaRequest');
      //console.log(this.registroBandejaRequest);
      //console.log('DocumentoResolutivo');
      //console.log(this.registroBandejaRequest.DocumentoResolutivo);
      
      
      /*this.seleccionOpcionesRegistro.Dre=this.detalleRegistroRequest[0].Dre;
      this.seleccionOpcionesRegistro.EventoRegistral = this.detalleRegistroRequest[0].EventoRegistral;
      this.seleccionOpcionesRegistro.TipoRegistro = this.registroBandejaRequest.TipoRegistro;
      this.seleccionOpcionesRegistro.Tipoiged = this.detalleRegistroRequest[0].TipoIged;
      this.seleccionOpcionesRegistro.Naturaleza = this.detalleRegistroRequest[0].EventoRegistral.Naturaleza;
      this.seleccionOpcionesRegistro.Ugel = {
        CodIged:this.detalleRegistroRequest[0].Ugel.CodIged,
        CodTipoIged:this.detalleRegistroRequest[0].TipoIged.CodTipoIged,
        DescTipoIged:this.detalleRegistroRequest[0].TipoIged.DescTipoIged,
        IdIged:this.detalleRegistroRequest[0].Ugel.IdIged,
        IdTipoIged:this.detalleRegistroRequest[0].TipoIged.IdTipoIged,
        NomIged:this.detalleRegistroRequest[0].Ugel.NomIged
      }*/
  
      //this.idDRE = this.detalleRegistroRequest[0].Dre.IdIged.toString();  //dataService.opcionesRegistro.Dre.NomIged;
      //this.prefijoCodigo = this.detalleRegistroRequest[0].Dre.CodIged.substring(1,4);
  
      //this.obtenerOpcionesUbigeo(this.idDRE);
  
      this.obtenerListasComponentes();
      //console.log(this.opcionesUbigeo.Region.Nombre);
      
      /*const opt = this.parametrosRegistro = {
        dre : this.detalleRegistroRequest[0].Dre,
        eventoRegistral: this.detalleRegistroRequest[0].EventoRegistral,
        tipoIged: this.detalleRegistroRequest[0].TipoIged,
        tipoRegistro: this.registroBandejaRequest.TipoRegistro,
        ugel: {
                CodIged:this.detalleRegistroRequest[0].Ugel.CodIged,
                CodTipoIged:this.detalleRegistroRequest[0].TipoIged.CodTipoIged,
                DescTipoIged:this.detalleRegistroRequest[0].TipoIged.DescTipoIged,
                IdIged:this.detalleRegistroRequest[0].Ugel.IdIged,
                IdTipoIged:this.detalleRegistroRequest[0].TipoIged.IdTipoIged,
                NomIged:this.detalleRegistroRequest[0].Ugel.NomIged
              }
        };   
         console.log("parametros registros origen");
        console.log(this.parametrosRegistro);
      this.obtenerOpcionesJurisdiccion(opt);*/
    }
  
    ngOnInit(): void {    
    }
  
    setStep(index: number) {
      this.step = index;
    }
  
    nextStep() {
      this.step++;
    }
  
    prevStep() { 
      this.step--;
    }
  
    /*obtenerListaTipoDocumento():void{
      this.comunService.obtenerListaTipoDocumento()
      .subscribe(res => {this.listaTipoDocumento = res});
    }*/
  
    obtenerListasComponentes():void{
      this.comunService.obtenerListasComponentes()
      .subscribe(res => {
            this.listaTipoDocumento = res['TiposDocumento'] ,      
            this.listaTiposMedioGeneralesB = res['TiposMedioDatosGenerales'],
            this.listaTipoMediosDirectorB = res['TiposMedioDatosDirector'],
            this.listaTiposPersonal = res['TiposPersonalDatosPersonal'],
            this.listaTiposLocal = res['TiposLocal'],
            this.listaTiposPropiedad=res['TiposPropiedad'];
            //his.listaPliegoUE = res['PliegosUnidadEjecutora'];
  
            console.log("lista componentes: res")  
            console.log(res);
            //console.log("lista componentes: listaTiposMedioGeneralesB")  
            //console.log(this.listaTiposMedioGeneralesB);*/
  
            console.log("lista componentes: listaTiposLocal")  
            console.log(this.listaTiposLocal)
  
            console.log("lista componentes: listaTiposPropiedad")  
            console.log(this.listaTiposPropiedad)
  
            console.log("lista componentes: listaTipoDocumento")  
            console.log(this.listaTipoDocumento)
  
            for (let tipoMedio of this.listaTiposMedioGeneralesB){
  
               const _tipoMedioContacto: TipoMedioContacto =  tiposMedioContacto.find(tipo=>tipo.CodTipo==tipoMedio.CodTipoMedio);
  
               const tipoMedioContacto: TipoMedioContacto = {
                IdTipoMedioContacto: tipoMedio.IdTipoMedioContacto,
                CodTipo: tipoMedio.CodTipoMedio,
                DescTipo: tipoMedio.DescTipoMedio,
                icono: _tipoMedioContacto.icono,
                labelIconbtn: _tipoMedioContacto.labelIconbtn,
                labelMedio: _tipoMedioContacto.labelMedio,
               } 
               this.listaTiposMedioGenerales.push(tipoMedioContacto)
               //console.log(tipoMedioContacto);
            }
  
            for (let tipoMedio of this.listaTipoMediosDirectorB){
  
              const _tipoMedioContacto: TipoMedioContacto =  tiposMedioContacto.find(tipo=>tipo.CodTipo==tipoMedio.CodTipoMedio);
  
              const tipoMedioContacto: TipoMedioContacto = {
               IdTipoMedioContacto: tipoMedio.IdTipoMedioContacto,
               CodTipo: tipoMedio.CodTipoMedio,
               DescTipo: tipoMedio.DescTipoMedio,
               icono: _tipoMedioContacto.icono,
               labelIconbtn: _tipoMedioContacto.labelIconbtn,
               labelMedio: _tipoMedioContacto.labelMedio,
              } 
              this.listaTipoMediosDirector.push(tipoMedioContacto)
              //console.log(tipoMedioContacto);
            }
                
          });
    }
  
    /*obtenerOpcionesUbigeo(IdDre:string):void{
      
      this.comunService.obtenerOpcionesUbigeo(IdDre)
      .subscribe(res => {
        this.listaDistrito = res['ListaDistritos'],
        this.listaProvincias = res['ListaProvincias'],           
        this.listaRegion= [this.region  = res['Region']]
      });
  
      //.subscribe(res => console.log(res));
      //.subscribe(res => this.opcionesUbigeo = res);
    }*/
  
    obtenerOpcionesJurisdiccion (parametrosRegistro: ParametrosRegistro):void {
      this.comunService.obtenerOpcionesJurisdiccion(parametrosRegistro)
      .subscribe(res => {
        console.log(res),
        this.listaUgel = res['ListaUgel'],
        this.listaEventoRegistral = res['ListaEventoRegistralC'],
        this.listaNaturaleza = res['ListaNaturalezaC']
        });
    }
  
    //private eventsSubject: Subject<void> = new Subject<void>();
    //events: Observable<void>;
    
    Aceptar(val:string):void{
      if (val="OK")
        {
          let mediosContactoIged: MedioContacto[];
          let personalIged: Personal[];
          let localesIged: LocalIged[];
          let unidadEjecutoraIged: UnidadEjecutora;
          let definitivoDetalleDerivados: IgedRegistroDefinitivoDetalle[]=[]; //Para eventos derivados
          let JurisdiccionUgel: Jurisdiccion[];
          let DocumentoResolutivoDirector: Documento;
          
          //this.dataService.subject.next(val);
          //Recoger data y enviar al servicio
            console.log("Recoger data y enviar al servicio");  
  
            //console.log("Recoger data datosContactoIgedChild"); 
            //console.log(this.datosContactoIgedChild);
            mediosContactoIged =this.datosContactoIgedChild.datosTabla;
            console.log("mediosContactoIged"); 
            console.log(mediosContactoIged);
  
            //console.log("Recoger data docResolutivoDirectorChild"); 
            //console.log(this.docResolutivoDirectorChild);
            
            console.log("DocumentoResolutivoDirector"); 
            console.log(DocumentoResolutivoDirector);
  
            //console.log("Recoger data personalChild"); 
            //console.log(this.personalChild);
            personalIged=this.personalChild.datosTabla;
            console.log("listaPersonal"); 
            console.log(personalIged);
  
            //console.log("Recoger data localIgedChild"); 
            //console.log(this.localIgedChild);
            localesIged=this.localIgedChild.datosTabla;
            console.log("localesIged"); 
            console.log(localesIged);
  
            //console.log("Recoger data jurisdiccionChild"); 
            //console.log(this.jurisdiccionChild);  
  
            if (!(localStorage.getItem('definitivoDetalle')===null)){
              definitivoDetalleDerivados = JSON.parse(localStorage.getItem('definitivoDetalle')); 
            }
            console.log("Recoger data definitivoDetalleDerivados de localStorage"); 
            console.log(definitivoDetalleDerivados); 
                        
            /*console.log("unidadEjecutoraIged"); 
            console.log(unidadEjecutoraIged);
            console.log("Recoger data accordionRegistro"); 
            console.log(this.accordionRegistro);
            console.log("Recoger data seccionPersonal"); 
            console.log(this.seccionPersonal); 
            console.log("Recoger data seccionLocales"); 
            console.log(this.seccionLocales); 
            console.log("Recoger data seccionJurisdiccion"); 
            console.log(this.seccionJurisdiccion); */
            let registroDefinitivoResponse: RegistroDefinitivoResponse={
                    IdRegistro: this.registroBandejaRequest.IdRegistro,
                    DetalleDerivados: definitivoDetalleDerivados,
                    MediosContactoIged: mediosContactoIged,
                    PersonalIged: personalIged,
                    localesIged: localesIged,
                    UnidadEjecutoraIged: unidadEjecutoraIged,
                    JurisdiccionUgel: JurisdiccionUgel,
                    DocumentoResolutivoDirector: DocumentoResolutivoDirector,
                    EsUEAutonoma : false
                    }  
            console.log("DATOS ENVIADOS AL SERVIDOR");
            console.log(registroDefinitivoResponse);
  
            this.PasarADefinitivo(registroDefinitivoResponse);         
        }        
    }
  
    PasarADefinitivo(registroResponse: RegistroDefinitivoResponse):void{    
      this.comunService.PasarADefinitivo(registroResponse)
      .subscribe(res => {
        console.log(res);
        if (res!= undefined){
          this.redireccionarBandeja()
        }     
      });
    }
    
    redireccionarBandeja(){
      console.log("");
      this.router.navigate(['/contenido']);
      }
  
    Cancelar(val:string):void{
      if (val="CANCEL")
        {
            //Limpiar formularios
            console.log("Limpiar formularios");            
        }        
    }  
  }
